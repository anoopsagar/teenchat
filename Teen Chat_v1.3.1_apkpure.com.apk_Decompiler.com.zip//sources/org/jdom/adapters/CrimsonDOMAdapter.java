package org.jdom.adapters;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import org.jdom.JDOMException;
import org.w3c.dom.Document;
import org.xml.sax.SAXParseException;

public class CrimsonDOMAdapter extends AbstractDOMAdapter {
    private static final String CVS_ID = "@(#) $RCSfile: CrimsonDOMAdapter.java,v $ $Revision: 1.17 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";

    public Document createDocument() {
        try {
            return (Document) Class.forName("org.apache.crimson.tree.XmlDocument").newInstance();
        } catch (Exception e) {
            throw new JDOMException(new StringBuffer().append(e.getClass().getName()).append(": ").append(e.getMessage()).append(" when creating document").toString(), e);
        }
    }

    public Document getDocument(InputStream inputStream, boolean z) {
        try {
            Class[] clsArr = {Class.forName("java.io.InputStream"), Boolean.TYPE};
            return (Document) Class.forName("org.apache.crimson.tree.XmlDocument").getMethod("createXmlDocument", clsArr).invoke((Object) null, new Object[]{inputStream, new Boolean(false)});
        } catch (InvocationTargetException e) {
            Throwable targetException = e.getTargetException();
            if (targetException instanceof SAXParseException) {
                SAXParseException sAXParseException = (SAXParseException) targetException;
                throw new JDOMException(new StringBuffer().append("Error on line ").append(sAXParseException.getLineNumber()).append(" of XML document: ").append(sAXParseException.getMessage()).toString(), sAXParseException);
            } else if (targetException instanceof IOException) {
                throw ((IOException) targetException);
            } else {
                throw new JDOMException(targetException.getMessage(), targetException);
            }
        } catch (Exception e2) {
            throw new JDOMException(new StringBuffer().append(e2.getClass().getName()).append(": ").append(e2.getMessage()).toString(), e2);
        }
    }
}
