package org.jdom.adapters;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import org.jdom.JDOMException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

public class OracleV2DOMAdapter extends AbstractDOMAdapter {
    private static final String CVS_ID = "@(#) $RCSfile: OracleV2DOMAdapter.java,v $ $Revision: 1.19 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    static Class class$org$xml$sax$InputSource;

    static Class class$(String str) {
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    public Document createDocument() {
        try {
            return (Document) Class.forName("oracle.xml.parser.v2.XMLDocument").newInstance();
        } catch (Exception e) {
            throw new JDOMException(new StringBuffer().append(e.getClass().getName()).append(": ").append(e.getMessage()).append(" when creating document").toString(), e);
        }
    }

    public Document getDocument(InputStream inputStream, boolean z) {
        Class cls;
        try {
            Class<?> cls2 = Class.forName("oracle.xml.parser.v2.DOMParser");
            Object newInstance = cls2.newInstance();
            Class[] clsArr = new Class[1];
            if (class$org$xml$sax$InputSource == null) {
                cls = class$("org.xml.sax.InputSource");
                class$org$xml$sax$InputSource = cls;
            } else {
                cls = class$org$xml$sax$InputSource;
            }
            clsArr[0] = cls;
            cls2.getMethod("parse", clsArr).invoke(newInstance, new Object[]{new InputSource(inputStream)});
            return (Document) cls2.getMethod("getDocument", (Class[]) null).invoke(newInstance, (Object[]) null);
        } catch (InvocationTargetException e) {
            Throwable targetException = e.getTargetException();
            if (targetException instanceof SAXParseException) {
                SAXParseException sAXParseException = (SAXParseException) targetException;
                throw new JDOMException(new StringBuffer().append("Error on line ").append(sAXParseException.getLineNumber()).append(" of XML document: ").append(sAXParseException.getMessage()).toString(), sAXParseException);
            } else if (targetException instanceof IOException) {
                throw ((IOException) targetException);
            } else {
                throw new JDOMException(targetException.getMessage(), targetException);
            }
        } catch (Exception e2) {
            throw new JDOMException(new StringBuffer().append(e2.getClass().getName()).append(": ").append(e2.getMessage()).toString(), e2);
        }
    }
}
