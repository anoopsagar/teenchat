package org.jdom.adapters;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import org.jdom.JDOMException;
import org.jdom.input.BuilderErrorHandler;
import org.w3c.dom.Document;

public class JAXPDOMAdapter extends AbstractDOMAdapter {
    private static final String CVS_ID = "@(#) $RCSfile: JAXPDOMAdapter.java,v $ $Revision: 1.13 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    static Class class$java$io$InputStream;
    static Class class$org$xml$sax$ErrorHandler;

    static Class class$(String str) {
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    public Document createDocument() {
        try {
            Class.forName("javax.xml.transform.Transformer");
            Class<?> cls = Class.forName("javax.xml.parsers.DocumentBuilderFactory");
            Object invoke = cls.getMethod("newDocumentBuilder", (Class[]) null).invoke(cls.getMethod("newInstance", (Class[]) null).invoke((Object) null, (Object[]) null), (Object[]) null);
            return (Document) invoke.getClass().getMethod("newDocument", (Class[]) null).invoke(invoke, (Object[]) null);
        } catch (Exception e) {
            throw new JDOMException("Reflection failed while creating new JAXP document", e);
        }
    }

    public Document getDocument(InputStream inputStream, boolean z) {
        Class cls;
        Class cls2;
        try {
            Class.forName("javax.xml.transform.Transformer");
            Class<?> cls3 = Class.forName("javax.xml.parsers.DocumentBuilderFactory");
            Object invoke = cls3.getMethod("newInstance", (Class[]) null).invoke((Object) null, (Object[]) null);
            cls3.getMethod("setValidating", new Class[]{Boolean.TYPE}).invoke(invoke, new Object[]{new Boolean(z)});
            cls3.getMethod("setNamespaceAware", new Class[]{Boolean.TYPE}).invoke(invoke, new Object[]{Boolean.TRUE});
            Object invoke2 = cls3.getMethod("newDocumentBuilder", (Class[]) null).invoke(invoke, (Object[]) null);
            Class<?> cls4 = invoke2.getClass();
            Class[] clsArr = new Class[1];
            if (class$org$xml$sax$ErrorHandler == null) {
                cls = class$("org.xml.sax.ErrorHandler");
                class$org$xml$sax$ErrorHandler = cls;
            } else {
                cls = class$org$xml$sax$ErrorHandler;
            }
            clsArr[0] = cls;
            cls4.getMethod("setErrorHandler", clsArr).invoke(invoke2, new Object[]{new BuilderErrorHandler()});
            Class[] clsArr2 = new Class[1];
            if (class$java$io$InputStream == null) {
                cls2 = class$("java.io.InputStream");
                class$java$io$InputStream = cls2;
            } else {
                cls2 = class$java$io$InputStream;
            }
            clsArr2[0] = cls2;
            return (Document) cls4.getMethod("parse", clsArr2).invoke(invoke2, new Object[]{inputStream});
        } catch (InvocationTargetException e) {
            Throwable targetException = e.getTargetException();
            if (targetException instanceof IOException) {
                throw ((IOException) targetException);
            }
            throw new JDOMException(targetException.getMessage(), targetException);
        } catch (Exception e2) {
            throw new JDOMException("Reflection failed while parsing a document with JAXP", e2);
        }
    }
}
