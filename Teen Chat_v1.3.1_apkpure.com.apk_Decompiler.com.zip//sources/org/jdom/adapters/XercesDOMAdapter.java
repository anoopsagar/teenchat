package org.jdom.adapters;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.jdom.JDOMException;
import org.jdom.input.BuilderErrorHandler;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

public class XercesDOMAdapter extends AbstractDOMAdapter {
    private static final String CVS_ID = "@(#) $RCSfile: XercesDOMAdapter.java,v $ $Revision: 1.19 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    static Class class$java$lang$String;
    static Class class$org$xml$sax$ErrorHandler;
    static Class class$org$xml$sax$InputSource;

    static Class class$(String str) {
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    public Document createDocument() {
        try {
            return (Document) Class.forName("org.apache.xerces.dom.DocumentImpl").newInstance();
        } catch (Exception e) {
            throw new JDOMException(new StringBuffer().append(e.getClass().getName()).append(": ").append(e.getMessage()).append(" when creating document").toString(), e);
        }
    }

    public Document getDocument(InputStream inputStream, boolean z) {
        Class cls;
        Class cls2;
        Class cls3;
        try {
            Class<?> cls4 = Class.forName("org.apache.xerces.parsers.DOMParser");
            Object newInstance = cls4.newInstance();
            Class[] clsArr = new Class[2];
            if (class$java$lang$String == null) {
                cls = class$("java.lang.String");
                class$java$lang$String = cls;
            } else {
                cls = class$java$lang$String;
            }
            clsArr[0] = cls;
            clsArr[1] = Boolean.TYPE;
            Method method = cls4.getMethod("setFeature", clsArr);
            method.invoke(newInstance, new Object[]{"http://xml.org/sax/features/validation", new Boolean(z)});
            method.invoke(newInstance, new Object[]{"http://xml.org/sax/features/namespaces", new Boolean(true)});
            if (z) {
                Class[] clsArr2 = new Class[1];
                if (class$org$xml$sax$ErrorHandler == null) {
                    cls3 = class$("org.xml.sax.ErrorHandler");
                    class$org$xml$sax$ErrorHandler = cls3;
                } else {
                    cls3 = class$org$xml$sax$ErrorHandler;
                }
                clsArr2[0] = cls3;
                cls4.getMethod("setErrorHandler", clsArr2).invoke(newInstance, new Object[]{new BuilderErrorHandler()});
            }
            Class[] clsArr3 = new Class[1];
            if (class$org$xml$sax$InputSource == null) {
                cls2 = class$("org.xml.sax.InputSource");
                class$org$xml$sax$InputSource = cls2;
            } else {
                cls2 = class$org$xml$sax$InputSource;
            }
            clsArr3[0] = cls2;
            cls4.getMethod("parse", clsArr3).invoke(newInstance, new Object[]{new InputSource(inputStream)});
            return (Document) cls4.getMethod("getDocument", (Class[]) null).invoke(newInstance, (Object[]) null);
        } catch (InvocationTargetException e) {
            InvocationTargetException invocationTargetException = e;
            Throwable targetException = invocationTargetException.getTargetException();
            if (targetException instanceof SAXParseException) {
                SAXParseException sAXParseException = (SAXParseException) targetException;
                throw new JDOMException(new StringBuffer().append("Error on line ").append(sAXParseException.getLineNumber()).append(" of XML document: ").append(sAXParseException.getMessage()).toString(), invocationTargetException);
            } else if (targetException instanceof IOException) {
                throw ((IOException) targetException);
            } else {
                throw new JDOMException(targetException.getMessage(), invocationTargetException);
            }
        } catch (Exception e2) {
            throw new JDOMException(new StringBuffer().append(e2.getClass().getName()).append(": ").append(e2.getMessage()).toString(), e2);
        }
    }
}
