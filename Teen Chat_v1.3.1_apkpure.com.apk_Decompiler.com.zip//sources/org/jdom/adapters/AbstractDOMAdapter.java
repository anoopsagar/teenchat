package org.jdom.adapters;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import org.jdom.DocType;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;

public abstract class AbstractDOMAdapter implements DOMAdapter {
    private static final String CVS_ID = "@(#) $RCSfile: AbstractDOMAdapter.java,v $ $Revision: 1.21 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    static Class class$java$lang$String;

    static Class class$(String str) {
        try {
            return Class.forName(str);
        } catch (ClassNotFoundException e) {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }

    public abstract Document createDocument();

    public Document createDocument(DocType docType) {
        if (docType == null) {
            return createDocument();
        }
        DOMImplementation implementation = createDocument().getImplementation();
        DocumentType createDocumentType = implementation.createDocumentType(docType.getElementName(), docType.getPublicID(), docType.getSystemID());
        setInternalSubset(createDocumentType, docType.getInternalSubset());
        return implementation.createDocument("http://temporary", docType.getElementName(), createDocumentType);
    }

    public Document getDocument(File file, boolean z) {
        return getDocument((InputStream) new FileInputStream(file), z);
    }

    public abstract Document getDocument(InputStream inputStream, boolean z);

    /* access modifiers changed from: protected */
    public void setInternalSubset(DocumentType documentType, String str) {
        Class cls;
        if (documentType != null && str != null) {
            try {
                Class<?> cls2 = documentType.getClass();
                Class[] clsArr = new Class[1];
                if (class$java$lang$String == null) {
                    cls = class$("java.lang.String");
                    class$java$lang$String = cls;
                } else {
                    cls = class$java$lang$String;
                }
                clsArr[0] = cls;
                cls2.getMethod("setInternalSubset", clsArr).invoke(documentType, new Object[]{str});
            } catch (Exception e) {
            }
        }
    }
}
