package org.jdom.adapters;

import java.io.File;
import java.io.InputStream;
import org.jdom.DocType;
import org.w3c.dom.Document;

public interface DOMAdapter {
    Document createDocument();

    Document createDocument(DocType docType);

    Document getDocument(File file, boolean z);

    Document getDocument(InputStream inputStream, boolean z);
}
