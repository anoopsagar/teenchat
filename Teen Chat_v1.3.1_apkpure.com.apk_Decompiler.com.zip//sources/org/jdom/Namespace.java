package org.jdom;

import java.util.HashMap;

public final class Namespace {
    private static final String CVS_ID = "@(#) $RCSfile: Namespace.java,v $ $Revision: 1.43 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    public static final Namespace NO_NAMESPACE = new Namespace("", "");
    public static final Namespace XML_NAMESPACE = new Namespace("xml", "http://www.w3.org/XML/1998/namespace");
    private static HashMap namespaces = new HashMap(16);
    private String prefix;
    private String uri;

    static {
        namespaces.put(new NamespaceKey(NO_NAMESPACE), NO_NAMESPACE);
        namespaces.put(new NamespaceKey(XML_NAMESPACE), XML_NAMESPACE);
    }

    private Namespace(String str, String str2) {
        this.prefix = str;
        this.uri = str2;
    }

    public static Namespace getNamespace(String str) {
        return getNamespace("", str);
    }

    public static Namespace getNamespace(String str, String str2) {
        if (str == null || str.trim().equals("")) {
            if (str2 == null || str2.trim().equals("")) {
                return NO_NAMESPACE;
            }
            str = "";
        } else if (str2 == null || str2.trim().equals("")) {
            str2 = "";
        }
        NamespaceKey namespaceKey = new NamespaceKey(str, str2);
        Namespace namespace = (Namespace) namespaces.get(namespaceKey);
        if (namespace != null) {
            return namespace;
        }
        String checkNamespacePrefix = Verifier.checkNamespacePrefix(str);
        if (checkNamespacePrefix != null) {
            throw new IllegalNameException(str, "Namespace prefix", checkNamespacePrefix);
        }
        String checkNamespaceURI = Verifier.checkNamespaceURI(str2);
        if (checkNamespaceURI != null) {
            throw new IllegalNameException(str2, "Namespace URI", checkNamespaceURI);
        } else if (!str.equals("") && str2.equals("")) {
            throw new IllegalNameException("", "namespace", "Namespace URIs must be non-null and non-empty Strings");
        } else if (str.equals("xml")) {
            throw new IllegalNameException(str, "Namespace prefix", "The xml prefix can only be bound to http://www.w3.org/XML/1998/namespace");
        } else if (str2.equals("http://www.w3.org/XML/1998/namespace")) {
            throw new IllegalNameException(str2, "Namespace URI", "The http://www.w3.org/XML/1998/namespace must be bound to the xml prefix.");
        } else {
            Namespace namespace2 = new Namespace(str, str2);
            namespaces.put(namespaceKey, namespace2);
            return namespace2;
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Namespace) {
            return this.uri.equals(((Namespace) obj).uri);
        }
        return false;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public String getURI() {
        return this.uri;
    }

    public int hashCode() {
        return this.uri.hashCode();
    }

    public String toString() {
        return new StringBuffer().append("[Namespace: prefix \"").append(this.prefix).append("\" is mapped to URI \"").append(this.uri).append("\"]").toString();
    }
}
