package org.jdom;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import org.xml.sax.SAXException;

public class JDOMException extends Exception {
    private static final String CVS_ID = "@(#) $RCSfile: JDOMException.java,v $ $Revision: 1.24 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    private Throwable cause;

    public JDOMException() {
        super("Error occurred in JDOM application.");
    }

    public JDOMException(String str) {
        super(str);
    }

    public JDOMException(String str, Throwable th) {
        super(str);
        this.cause = th;
    }

    private static Throwable getNestedException(Throwable th) {
        if (th instanceof JDOMException) {
            return ((JDOMException) th).getCause();
        }
        if (th instanceof SAXException) {
            return ((SAXException) th).getException();
        }
        if (th instanceof SQLException) {
            return ((SQLException) th).getNextException();
        }
        if (th instanceof InvocationTargetException) {
            return ((InvocationTargetException) th).getTargetException();
        }
        if (th instanceof ExceptionInInitializerError) {
            return ((ExceptionInInitializerError) th).getException();
        }
        if (th instanceof RemoteException) {
            return ((RemoteException) th).detail;
        }
        Throwable nestedException = getNestedException(th, "javax.naming.NamingException", "getRootCause");
        if (nestedException != null) {
            return nestedException;
        }
        Throwable nestedException2 = getNestedException(th, "javax.servlet.ServletException", "getRootCause");
        if (nestedException2 == null) {
            return null;
        }
        return nestedException2;
    }

    private static Throwable getNestedException(Throwable th, String str, String str2) {
        try {
            Class<?> cls = Class.forName(str);
            if (cls.isAssignableFrom(th.getClass())) {
                return (Throwable) cls.getMethod(str2, new Class[0]).invoke(th, new Object[0]);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public Throwable getCause() {
        return this.cause;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v1, resolved type: org.jdom.JDOMException} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: java.lang.Throwable} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v2, resolved type: org.jdom.JDOMException} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: org.xml.sax.SAXException} */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0013, code lost:
        r0 = r1.getException();
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String getMessage() {
        /*
            r4 = this;
            java.lang.String r0 = super.getMessage()
            r2 = r0
        L_0x0005:
            java.lang.Throwable r1 = getNestedException(r4)
            if (r1 == 0) goto L_0x0050
            java.lang.String r3 = r1.getMessage()
            boolean r0 = r1 instanceof org.xml.sax.SAXException
            if (r0 == 0) goto L_0x004e
            r0 = r1
            org.xml.sax.SAXException r0 = (org.xml.sax.SAXException) r0
            java.lang.Exception r0 = r0.getException()
            if (r0 == 0) goto L_0x004e
            if (r3 == 0) goto L_0x004e
            java.lang.String r0 = r0.getMessage()
            boolean r0 = r3.equals(r0)
            if (r0 == 0) goto L_0x004e
            r0 = 0
        L_0x0029:
            if (r0 == 0) goto L_0x004c
            if (r2 == 0) goto L_0x0044
            java.lang.StringBuffer r3 = new java.lang.StringBuffer
            r3.<init>()
            java.lang.StringBuffer r2 = r3.append(r2)
            java.lang.String r3 = ": "
            java.lang.StringBuffer r2 = r2.append(r3)
            java.lang.StringBuffer r0 = r2.append(r0)
            java.lang.String r0 = r0.toString()
        L_0x0044:
            boolean r2 = r1 instanceof org.jdom.JDOMException
            if (r2 == 0) goto L_0x0049
        L_0x0048:
            return r0
        L_0x0049:
            r4 = r1
            r2 = r0
            goto L_0x0005
        L_0x004c:
            r0 = r2
            goto L_0x0044
        L_0x004e:
            r0 = r3
            goto L_0x0029
        L_0x0050:
            r0 = r2
            goto L_0x0048
        */
        throw new UnsupportedOperationException("Method not decompiled: org.jdom.JDOMException.getMessage():java.lang.String");
    }

    public Throwable initCause(Throwable th) {
        this.cause = th;
        return this;
    }

    public void printStackTrace() {
        boolean z;
        super.printStackTrace();
        this = this;
        do {
            Throwable nestedException = getNestedException(this);
            if (nestedException != null) {
                System.err.print("Caused by: ");
                nestedException.printStackTrace();
                z = nestedException instanceof JDOMException;
                this = nestedException;
            } else {
                return;
            }
        } while (!z);
    }

    public void printStackTrace(PrintStream printStream) {
        boolean z;
        super.printStackTrace(printStream);
        this = this;
        do {
            Throwable nestedException = getNestedException(this);
            if (nestedException != null) {
                printStream.print("Caused by: ");
                nestedException.printStackTrace(printStream);
                z = nestedException instanceof JDOMException;
                this = nestedException;
            } else {
                return;
            }
        } while (!z);
    }

    public void printStackTrace(PrintWriter printWriter) {
        boolean z;
        super.printStackTrace(printWriter);
        this = this;
        do {
            Throwable nestedException = getNestedException(this);
            if (nestedException != null) {
                printWriter.print("Caused by: ");
                nestedException.printStackTrace(printWriter);
                z = nestedException instanceof JDOMException;
                this = nestedException;
            } else {
                return;
            }
        } while (!z);
    }
}
