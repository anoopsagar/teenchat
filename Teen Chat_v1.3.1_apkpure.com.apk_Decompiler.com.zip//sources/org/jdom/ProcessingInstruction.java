package org.jdom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jdom.output.XMLOutputter;

public class ProcessingInstruction extends Content {
    private static final String CVS_ID = "@(#) $RCSfile: ProcessingInstruction.java,v $ $Revision: 1.47 $ $Date: 2007/11/10 05:28:59 $ $Name: jdom_1_1 $";
    protected Map mapData;
    protected String rawData;
    protected String target;

    protected ProcessingInstruction() {
    }

    public ProcessingInstruction(String str, String str2) {
        setTarget(str);
        setData(str2);
    }

    public ProcessingInstruction(String str, Map map) {
        setTarget(str);
        setData(map);
    }

    private static int[] extractQuotedString(String str) {
        int i = 0;
        char c = '\"';
        boolean z = false;
        for (int i2 = 0; i2 < str.length(); i2++) {
            char charAt = str.charAt(i2);
            if (charAt == '\"' || charAt == '\'') {
                if (!z) {
                    i = i2 + 1;
                    c = charAt;
                    z = true;
                } else if (c == charAt) {
                    return new int[]{i, i2};
                }
            }
        }
        return null;
    }

    private Map parseData(String str) {
        String str2;
        String str3;
        HashMap hashMap = new HashMap();
        String trim = str.trim();
        while (!trim.trim().equals("")) {
            char charAt = trim.charAt(0);
            int i = 0;
            int i2 = 1;
            while (true) {
                if (i2 >= trim.length()) {
                    str2 = "";
                    str3 = "";
                    break;
                }
                char charAt2 = trim.charAt(i2);
                if (charAt2 == '=') {
                    str3 = trim.substring(i, i2).trim();
                    int[] extractQuotedString = extractQuotedString(trim.substring(i2 + 1));
                    if (extractQuotedString == null) {
                        return new HashMap();
                    }
                    str2 = trim.substring(extractQuotedString[0] + i2 + 1, extractQuotedString[1] + i2 + 1);
                    i2 += extractQuotedString[1] + 1;
                } else {
                    int i3 = (!Character.isWhitespace(charAt) || Character.isWhitespace(charAt2)) ? i : i2;
                    i2++;
                    i = i3;
                    charAt = charAt2;
                }
            }
            trim = trim.substring(i2);
            if (str3.length() > 0 && str2 != null) {
                hashMap.put(str3, str2);
            }
        }
        return hashMap;
    }

    private String toString(Map map) {
        StringBuffer stringBuffer = new StringBuffer();
        for (String str : map.keySet()) {
            stringBuffer.append(str).append("=\"").append((String) map.get(str)).append("\" ");
        }
        if (stringBuffer.length() > 0) {
            stringBuffer.setLength(stringBuffer.length() - 1);
        }
        return stringBuffer.toString();
    }

    public Object clone() {
        ProcessingInstruction processingInstruction = (ProcessingInstruction) super.clone();
        if (this.mapData != null) {
            processingInstruction.mapData = parseData(this.rawData);
        }
        return processingInstruction;
    }

    public String getData() {
        return this.rawData;
    }

    public List getPseudoAttributeNames() {
        Set<Object> entrySet = this.mapData.entrySet();
        ArrayList arrayList = new ArrayList();
        for (Object obj : entrySet) {
            String obj2 = obj.toString();
            arrayList.add(obj2.substring(0, obj2.indexOf("=")));
        }
        return arrayList;
    }

    public String getPseudoAttributeValue(String str) {
        return (String) this.mapData.get(str);
    }

    public String getTarget() {
        return this.target;
    }

    public String getValue() {
        return this.rawData;
    }

    public boolean removePseudoAttribute(String str) {
        if (this.mapData.remove(str) == null) {
            return false;
        }
        this.rawData = toString(this.mapData);
        return true;
    }

    public ProcessingInstruction setData(String str) {
        String checkProcessingInstructionData = Verifier.checkProcessingInstructionData(str);
        if (checkProcessingInstructionData != null) {
            throw new IllegalDataException(str, checkProcessingInstructionData);
        }
        this.rawData = str;
        this.mapData = parseData(str);
        return this;
    }

    public ProcessingInstruction setData(Map map) {
        String processingInstruction = toString(map);
        String checkProcessingInstructionData = Verifier.checkProcessingInstructionData(processingInstruction);
        if (checkProcessingInstructionData != null) {
            throw new IllegalDataException(processingInstruction, checkProcessingInstructionData);
        }
        this.rawData = processingInstruction;
        this.mapData = map;
        return this;
    }

    public ProcessingInstruction setPseudoAttribute(String str, String str2) {
        String checkProcessingInstructionData = Verifier.checkProcessingInstructionData(str);
        if (checkProcessingInstructionData != null) {
            throw new IllegalDataException(str, checkProcessingInstructionData);
        }
        String checkProcessingInstructionData2 = Verifier.checkProcessingInstructionData(str2);
        if (checkProcessingInstructionData2 != null) {
            throw new IllegalDataException(str2, checkProcessingInstructionData2);
        }
        this.mapData.put(str, str2);
        this.rawData = toString(this.mapData);
        return this;
    }

    public ProcessingInstruction setTarget(String str) {
        String checkProcessingInstructionTarget = Verifier.checkProcessingInstructionTarget(str);
        if (checkProcessingInstructionTarget != null) {
            throw new IllegalTargetException(str, checkProcessingInstructionTarget);
        }
        this.target = str;
        return this;
    }

    public String toString() {
        return new StringBuffer().append("[ProcessingInstruction: ").append(new XMLOutputter().outputString(this)).append("]").toString();
    }
}
