package org.jdom;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.jdom.filter.ElementFilter;
import org.jdom.filter.Filter;

public class Element extends Content implements Parent {
    private static final String CVS_ID = "@(#) $RCSfile: Element.java,v $ $Revision: 1.159 $ $Date: 2007/11/14 05:02:08 $ $Name: jdom_1_1 $";
    private static final int INITIAL_ARRAY_SIZE = 5;
    protected transient List additionalNamespaces;
    AttributeList attributes;
    ContentList content;
    protected String name;
    protected transient Namespace namespace;

    protected Element() {
        this.attributes = new AttributeList(this);
        this.content = new ContentList(this);
    }

    public Element(String str) {
        this(str, (Namespace) null);
    }

    public Element(String str, String str2) {
        this(str, Namespace.getNamespace("", str2));
    }

    public Element(String str, String str2, String str3) {
        this(str, Namespace.getNamespace(str2, str3));
    }

    public Element(String str, Namespace namespace2) {
        this.attributes = new AttributeList(this);
        this.content = new ContentList(this);
        setName(str);
        setNamespace(namespace2);
    }

    private void readObject(ObjectInputStream objectInputStream) {
        objectInputStream.defaultReadObject();
        this.namespace = Namespace.getNamespace((String) objectInputStream.readObject(), (String) objectInputStream.readObject());
        int read = objectInputStream.read();
        if (read != 0) {
            this.additionalNamespaces = new ArrayList(read);
            for (int i = 0; i < read; i++) {
                this.additionalNamespaces.add(Namespace.getNamespace((String) objectInputStream.readObject(), (String) objectInputStream.readObject()));
            }
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeObject(this.namespace.getPrefix());
        objectOutputStream.writeObject(this.namespace.getURI());
        if (this.additionalNamespaces == null) {
            objectOutputStream.write(0);
            return;
        }
        int size = this.additionalNamespaces.size();
        objectOutputStream.write(size);
        for (int i = 0; i < size; i++) {
            Namespace namespace2 = (Namespace) this.additionalNamespaces.get(i);
            objectOutputStream.writeObject(namespace2.getPrefix());
            objectOutputStream.writeObject(namespace2.getURI());
        }
    }

    public Element addContent(int i, Collection collection) {
        this.content.addAll(i, collection);
        return this;
    }

    public Element addContent(int i, Content content2) {
        this.content.add(i, content2);
        return this;
    }

    public Element addContent(String str) {
        return addContent((Content) new Text(str));
    }

    public Element addContent(Collection collection) {
        this.content.addAll(collection);
        return this;
    }

    public Element addContent(Content content2) {
        this.content.add(content2);
        return this;
    }

    public void addNamespaceDeclaration(Namespace namespace2) {
        String checkNamespaceCollision = Verifier.checkNamespaceCollision(namespace2, this);
        if (checkNamespaceCollision != null) {
            throw new IllegalAddException(this, namespace2, checkNamespaceCollision);
        }
        if (this.additionalNamespaces == null) {
            this.additionalNamespaces = new ArrayList(5);
        }
        this.additionalNamespaces.add(namespace2);
    }

    public Object clone() {
        Element element = (Element) super.clone();
        element.content = new ContentList(element);
        element.attributes = new AttributeList(element);
        if (this.attributes != null) {
            for (int i = 0; i < this.attributes.size(); i++) {
                element.attributes.add(((Attribute) this.attributes.get(i)).clone());
            }
        }
        if (this.additionalNamespaces != null) {
            element.additionalNamespaces = new ArrayList(this.additionalNamespaces);
        }
        if (this.content != null) {
            for (int i2 = 0; i2 < this.content.size(); i2++) {
                element.content.add(((Content) this.content.get(i2)).clone());
            }
        }
        return element;
    }

    public List cloneContent() {
        int contentSize = getContentSize();
        ArrayList arrayList = new ArrayList(contentSize);
        for (int i = 0; i < contentSize; i++) {
            arrayList.add(getContent(i).clone());
        }
        return arrayList;
    }

    public List getAdditionalNamespaces() {
        return this.additionalNamespaces == null ? Collections.EMPTY_LIST : Collections.unmodifiableList(this.additionalNamespaces);
    }

    public Attribute getAttribute(String str) {
        return getAttribute(str, Namespace.NO_NAMESPACE);
    }

    public Attribute getAttribute(String str, Namespace namespace2) {
        return (Attribute) this.attributes.get(str, namespace2);
    }

    public String getAttributeValue(String str) {
        return getAttributeValue(str, Namespace.NO_NAMESPACE);
    }

    public String getAttributeValue(String str, String str2) {
        return getAttributeValue(str, Namespace.NO_NAMESPACE, str2);
    }

    public String getAttributeValue(String str, Namespace namespace2) {
        return getAttributeValue(str, namespace2, (String) null);
    }

    public String getAttributeValue(String str, Namespace namespace2, String str2) {
        Attribute attribute = (Attribute) this.attributes.get(str, namespace2);
        return attribute == null ? str2 : attribute.getValue();
    }

    public List getAttributes() {
        return this.attributes;
    }

    public Element getChild(String str) {
        return getChild(str, Namespace.NO_NAMESPACE);
    }

    public Element getChild(String str, Namespace namespace2) {
        Iterator it = this.content.getView(new ElementFilter(str, namespace2)).iterator();
        if (it.hasNext()) {
            return (Element) it.next();
        }
        return null;
    }

    public String getChildText(String str) {
        Element child = getChild(str);
        if (child == null) {
            return null;
        }
        return child.getText();
    }

    public String getChildText(String str, Namespace namespace2) {
        Element child = getChild(str, namespace2);
        if (child == null) {
            return null;
        }
        return child.getText();
    }

    public String getChildTextNormalize(String str) {
        Element child = getChild(str);
        if (child == null) {
            return null;
        }
        return child.getTextNormalize();
    }

    public String getChildTextNormalize(String str, Namespace namespace2) {
        Element child = getChild(str, namespace2);
        if (child == null) {
            return null;
        }
        return child.getTextNormalize();
    }

    public String getChildTextTrim(String str) {
        Element child = getChild(str);
        if (child == null) {
            return null;
        }
        return child.getTextTrim();
    }

    public String getChildTextTrim(String str, Namespace namespace2) {
        Element child = getChild(str, namespace2);
        if (child == null) {
            return null;
        }
        return child.getTextTrim();
    }

    public List getChildren() {
        return this.content.getView(new ElementFilter());
    }

    public List getChildren(String str) {
        return getChildren(str, Namespace.NO_NAMESPACE);
    }

    public List getChildren(String str, Namespace namespace2) {
        return this.content.getView(new ElementFilter(str, namespace2));
    }

    public List getContent() {
        return this.content;
    }

    public List getContent(Filter filter) {
        return this.content.getView(filter);
    }

    public Content getContent(int i) {
        return (Content) this.content.get(i);
    }

    public int getContentSize() {
        return this.content.size();
    }

    public Iterator getDescendants() {
        return new DescendantIterator(this);
    }

    public Iterator getDescendants(Filter filter) {
        return new FilterIterator(new DescendantIterator(this), filter);
    }

    public String getName() {
        return this.name;
    }

    public Namespace getNamespace() {
        return this.namespace;
    }

    public Namespace getNamespace(String str) {
        if (str == null) {
            return null;
        }
        if ("xml".equals(str)) {
            return Namespace.XML_NAMESPACE;
        }
        if (str.equals(getNamespacePrefix())) {
            return getNamespace();
        }
        if (this.additionalNamespaces != null) {
            int i = 0;
            while (true) {
                int i2 = i;
                if (i2 >= this.additionalNamespaces.size()) {
                    break;
                }
                Namespace namespace2 = (Namespace) this.additionalNamespaces.get(i2);
                if (str.equals(namespace2.getPrefix())) {
                    return namespace2;
                }
                i = i2 + 1;
            }
        }
        if (this.parent instanceof Element) {
            return ((Element) this.parent).getNamespace(str);
        }
        return null;
    }

    public String getNamespacePrefix() {
        return this.namespace.getPrefix();
    }

    public String getNamespaceURI() {
        return this.namespace.getURI();
    }

    public String getQualifiedName() {
        return "".equals(this.namespace.getPrefix()) ? getName() : new StringBuffer(this.namespace.getPrefix()).append(':').append(this.name).toString();
    }

    public String getText() {
        if (this.content.size() == 0) {
            return "";
        }
        if (this.content.size() == 1) {
            Object obj = this.content.get(0);
            return obj instanceof Text ? ((Text) obj).getText() : "";
        }
        StringBuffer stringBuffer = new StringBuffer();
        boolean z = false;
        for (int i = 0; i < this.content.size(); i++) {
            Object obj2 = this.content.get(i);
            if (obj2 instanceof Text) {
                stringBuffer.append(((Text) obj2).getText());
                z = true;
            }
        }
        return !z ? "" : stringBuffer.toString();
    }

    public String getTextNormalize() {
        return Text.normalizeString(getText());
    }

    public String getTextTrim() {
        return getText().trim();
    }

    public String getValue() {
        StringBuffer stringBuffer = new StringBuffer();
        for (Content content2 : getContent()) {
            if ((content2 instanceof Element) || (content2 instanceof Text)) {
                stringBuffer.append(content2.getValue());
            }
        }
        return stringBuffer.toString();
    }

    public int indexOf(Content content2) {
        return this.content.indexOf(content2);
    }

    public boolean isAncestor(Element element) {
        for (Parent parent = element.getParent(); parent instanceof Element; parent = parent.getParent()) {
            if (parent == this) {
                return true;
            }
        }
        return false;
    }

    public boolean isRootElement() {
        return this.parent instanceof Document;
    }

    public boolean removeAttribute(String str) {
        return removeAttribute(str, Namespace.NO_NAMESPACE);
    }

    public boolean removeAttribute(String str, Namespace namespace2) {
        return this.attributes.remove(str, namespace2);
    }

    public boolean removeAttribute(Attribute attribute) {
        return this.attributes.remove(attribute);
    }

    public boolean removeChild(String str) {
        return removeChild(str, Namespace.NO_NAMESPACE);
    }

    public boolean removeChild(String str, Namespace namespace2) {
        Iterator it = this.content.getView(new ElementFilter(str, namespace2)).iterator();
        if (!it.hasNext()) {
            return false;
        }
        it.next();
        it.remove();
        return true;
    }

    public boolean removeChildren(String str) {
        return removeChildren(str, Namespace.NO_NAMESPACE);
    }

    public boolean removeChildren(String str, Namespace namespace2) {
        boolean z = false;
        Iterator it = this.content.getView(new ElementFilter(str, namespace2)).iterator();
        while (it.hasNext()) {
            it.next();
            it.remove();
            z = true;
        }
        return z;
    }

    public List removeContent() {
        ArrayList arrayList = new ArrayList(this.content);
        this.content.clear();
        return arrayList;
    }

    public List removeContent(Filter filter) {
        ArrayList arrayList = new ArrayList();
        Iterator it = this.content.getView(filter).iterator();
        while (it.hasNext()) {
            arrayList.add((Content) it.next());
            it.remove();
        }
        return arrayList;
    }

    public Content removeContent(int i) {
        return (Content) this.content.remove(i);
    }

    public boolean removeContent(Content content2) {
        return this.content.remove(content2);
    }

    public void removeNamespaceDeclaration(Namespace namespace2) {
        if (this.additionalNamespaces != null) {
            this.additionalNamespaces.remove(namespace2);
        }
    }

    public Element setAttribute(String str, String str2) {
        Attribute attribute = getAttribute(str);
        if (attribute == null) {
            setAttribute(new Attribute(str, str2));
        } else {
            attribute.setValue(str2);
        }
        return this;
    }

    public Element setAttribute(String str, String str2, Namespace namespace2) {
        Attribute attribute = getAttribute(str, namespace2);
        if (attribute == null) {
            setAttribute(new Attribute(str, str2, namespace2));
        } else {
            attribute.setValue(str2);
        }
        return this;
    }

    public Element setAttribute(Attribute attribute) {
        this.attributes.add(attribute);
        return this;
    }

    public Element setAttributes(Collection collection) {
        this.attributes.clearAndSet(collection);
        return this;
    }

    public Element setAttributes(List list) {
        return setAttributes((Collection) list);
    }

    public Element setContent(int i, Content content2) {
        this.content.set(i, content2);
        return this;
    }

    public Element setContent(Collection collection) {
        this.content.clearAndSet(collection);
        return this;
    }

    public Element setContent(Content content2) {
        this.content.clear();
        this.content.add(content2);
        return this;
    }

    public Parent setContent(int i, Collection collection) {
        this.content.remove(i);
        this.content.addAll(i, collection);
        return this;
    }

    public Element setName(String str) {
        String checkElementName = Verifier.checkElementName(str);
        if (checkElementName != null) {
            throw new IllegalNameException(str, "element", checkElementName);
        }
        this.name = str;
        return this;
    }

    public Element setNamespace(Namespace namespace2) {
        if (namespace2 == null) {
            namespace2 = Namespace.NO_NAMESPACE;
        }
        this.namespace = namespace2;
        return this;
    }

    public Element setText(String str) {
        this.content.clear();
        if (str != null) {
            addContent((Content) new Text(str));
        }
        return this;
    }

    public String toString() {
        StringBuffer append = new StringBuffer(64).append("[Element: <").append(getQualifiedName());
        String namespaceURI = getNamespaceURI();
        if (!"".equals(namespaceURI)) {
            append.append(" [Namespace: ").append(namespaceURI).append("]");
        }
        append.append("/>]");
        return append.toString();
    }
}
