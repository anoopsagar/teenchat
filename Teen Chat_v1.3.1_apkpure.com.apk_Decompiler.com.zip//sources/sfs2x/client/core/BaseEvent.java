package sfs2x.client.core;

import java.util.HashMap;
import java.util.Map;

public class BaseEvent {
    private Map arguments;
    protected Object target;
    protected String type;

    public BaseEvent(String str) {
        this.type = str;
        if (getArguments() == null) {
            setArguments(new HashMap());
        }
    }

    public BaseEvent(String str, Map map) {
        this.type = str;
        setArguments(map);
        if (getArguments() == null) {
            setArguments(new HashMap());
        }
    }

    public BaseEvent clone() {
        return new BaseEvent(this.type, getArguments());
    }

    public Map getArguments() {
        return this.arguments;
    }

    public Object getTarget() {
        return this.target;
    }

    public String getType() {
        return this.type;
    }

    public void setArguments(Map map) {
        this.arguments = map;
    }

    public void setTarget(Object obj) {
        this.target = obj;
    }

    public String toString() {
        return String.valueOf(this.type) + " [ " + (this.target != null ? this.target.toString() : "null") + "]";
    }
}
