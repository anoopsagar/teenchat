package sfs2x.client.core;

public interface IEventListener {
    void dispatch(BaseEvent baseEvent);
}
