package sfs2x.client.core;

import com.smartfoxserver.bitswarm.util.ByteUtils;
import com.smartfoxserver.v2.exceptions.SFSCodecException;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.protocol.binary.PacketHeader;
import com.smartfoxserver.v2.protocol.serialization.DefaultObjectDumpFormatter;
import java.nio.ByteBuffer;
import org.apache.commons.io.IOUtils;
import org.jboss.netty.handler.codec.http.HttpConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sfs2x.client.bitswarm.BitSwarmClient;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.bitswarm.IOHandler;
import sfs2x.client.bitswarm.IProtocolCodec;
import sfs2x.client.bitswarm.PendingPacket;
import sfs2x.client.util.ByteArray;
import sfs2x.fsm.FiniteStateMachine;

public class SFSIOHandler implements IOHandler {
    public static final int INT_BYTE_SIZE = 4;
    public static final int SHORT_BYTE_SIZE = 2;
    private final ByteArray EMPTY_BUFFER = new ByteArray();
    private BitSwarmClient bitSwarm;
    private FiniteStateMachine fsm;
    private boolean isDebugMode = false;
    private Logger log;
    private PendingPacket pendingPacket;
    private IProtocolCodec protocolCodec;
    private int skipBytes = 0;

    public SFSIOHandler(BitSwarmClient bitSwarmClient) {
        this.bitSwarm = bitSwarmClient;
        this.log = LoggerFactory.getLogger((Class) getClass());
        this.protocolCodec = new SFSProtocolCodec(this, bitSwarmClient);
        InitStates();
        this.isDebugMode = bitSwarmClient.getSfs().isDebug();
    }

    private void InitStates() {
        this.fsm = new FiniteStateMachine();
        this.fsm.addState(4);
        this.fsm.addState(3);
        this.fsm.addState(1);
        this.fsm.addState(2);
        this.fsm.addState(0);
        this.fsm.addStateTransition(0, 1, 0);
        this.fsm.addStateTransition(1, 3, 1);
        this.fsm.addStateTransition(1, 2, 2);
        this.fsm.addStateTransition(2, 3, 3);
        this.fsm.addStateTransition(3, 0, 4);
        this.fsm.addStateTransition(3, 4, 5);
        this.fsm.addStateTransition(4, 0, 6);
        this.fsm.setCurrentState(0);
    }

    private PacketHeader createPacketHeader(byte b) {
        boolean z = false;
        boolean z2 = (b & 64) > 0;
        boolean z3 = (b & HttpConstants.SP) > 0;
        boolean z4 = (b & 16) > 0;
        if ((b & 8) > 0) {
            z = true;
        }
        return new PacketHeader(true, z2, z3, z4, z);
    }

    private byte encodePacketHeader(PacketHeader packetHeader) {
        byte b = 0;
        if (packetHeader.isBinary()) {
            b = (byte) 128;
        }
        if (packetHeader.isEncrypted()) {
            b = (byte) (b | 64);
        }
        if (packetHeader.isCompressed()) {
            b = (byte) (b | HttpConstants.SP);
        }
        if (packetHeader.isBlueBoxed()) {
            b = (byte) (b | 16);
        }
        return packetHeader.isBigSized() ? (byte) (b | 8) : b;
    }

    private int getReadState() {
        return this.fsm.getCurrentState();
    }

    private ByteArray handleDataSize(ByteArray byteArray) {
        int i;
        int i2;
        if (this.isDebugMode && this.log.isDebugEnabled()) {
            this.log.debug("Handling Header Size. Length: " + byteArray.getLength() + " (" + (this.pendingPacket.getHeader().isBigSized() ? "big" : "small") + ")");
        }
        if (this.pendingPacket.getHeader().isBigSized()) {
            i2 = byteArray.getLength() >= 4 ? byteArray.readInt() : -1;
            i = 4;
        } else if (byteArray.getLength() >= 2) {
            i2 = byteArray.readUShort();
            i = 2;
        } else {
            i = 2;
            i2 = -1;
        }
        if (this.isDebugMode && this.log.isDebugEnabled()) {
            this.log.debug("Data size is " + i2);
        }
        if (i2 != -1) {
            this.pendingPacket.getHeader().setExpectedLen(i2);
            ByteArray resizeByteArray = resizeByteArray(byteArray, i, byteArray.getLength() - i);
            this.fsm.applyTransition(1);
            return resizeByteArray;
        }
        this.fsm.applyTransition(2);
        writeBytes(this.pendingPacket, byteArray);
        return this.EMPTY_BUFFER;
    }

    private ByteArray handleDataSizeFragment(ByteArray byteArray) {
        if (this.isDebugMode && this.log.isDebugEnabled()) {
            this.log.debug("Handling Size fragment. Data: " + byteArray.getLength());
        }
        int length = this.pendingPacket.getHeader().isBigSized() ? 4 - this.pendingPacket.getBuffer().getLength() : 2 - this.pendingPacket.getBuffer().getLength();
        if (byteArray.getLength() >= length) {
            writeBytes(this.pendingPacket, byteArray, length);
            int i = this.pendingPacket.getHeader().isBigSized() ? 4 : 2;
            ByteArray byteArray2 = new ByteArray();
            byteArray2.writeBytes(this.pendingPacket.getBuffer().getBytes(), i);
            byteArray2.setPosition(0);
            int readInt = this.pendingPacket.getHeader().isBigSized() ? byteArray2.readInt() : byteArray2.readShort();
            if (this.isDebugMode && this.log.isDebugEnabled()) {
                this.log.debug("DataSize is ready: " + readInt + " bytes");
            }
            this.pendingPacket.getHeader().setExpectedLen(readInt);
            this.pendingPacket.setBuffer(new ByteArray());
            this.fsm.applyTransition(3);
            return byteArray.getLength() > length ? resizeByteArray(byteArray, length, byteArray.getLength() - length) : this.EMPTY_BUFFER;
        }
        writeBytes(this.pendingPacket, byteArray);
        return this.EMPTY_BUFFER;
    }

    private ByteArray handleInvalidData(ByteArray byteArray) {
        if (this.skipBytes == 0) {
            this.fsm.applyTransition(6);
            return byteArray;
        }
        int min = Math.min(byteArray.getLength(), this.skipBytes);
        ByteArray resizeByteArray = resizeByteArray(byteArray, min, byteArray.getLength() - min);
        this.skipBytes -= min;
        return resizeByteArray;
    }

    private ByteArray handleNewPacket(ByteArray byteArray) {
        if (this.isDebugMode) {
            this.log.info("Handling New Packet of size " + byteArray.getLength());
        }
        byte readByte = byteArray.readByte();
        if (((readByte & 128) ^ -1) > 0) {
            throw new SFSException("Unexpected header byte: " + readByte + IOUtils.LINE_SEPARATOR_UNIX + DefaultObjectDumpFormatter.prettyPrintByteArray(byteArray.getBytes()));
        }
        this.pendingPacket = new PendingPacket(createPacketHeader(readByte));
        this.fsm.applyTransition(0);
        return resizeByteArray(byteArray, 1, byteArray.getLength() - 1);
    }

    private ByteArray handlePacketData(ByteArray byteArray) {
        int expectedLen = this.pendingPacket.getHeader().getExpectedLen() - this.pendingPacket.getBuffer().getLength();
        boolean z = byteArray.getLength() > expectedLen;
        ByteArray byteArray2 = new ByteArray(byteArray.getBytes());
        try {
            if (this.isDebugMode) {
                this.log.info("Handling Data: " + byteArray.getLength() + ", previous state: " + this.pendingPacket.getBuffer().getLength() + "/" + this.pendingPacket.getHeader().getExpectedLen());
            }
            if (byteArray.getLength() >= expectedLen) {
                writeBytes(this.pendingPacket, byteArray, expectedLen);
                if (this.isDebugMode) {
                    this.log.info("<<< Packet Complete >>>");
                }
                if (this.pendingPacket.getHeader().isCompressed()) {
                    uncompress(this.pendingPacket);
                }
                this.protocolCodec.onPacketRead(this.pendingPacket.getBuffer());
                this.fsm.applyTransition(4);
            } else {
                writeBytes(this.pendingPacket, byteArray);
            }
            return z ? resizeByteArray(byteArray, expectedLen, byteArray.getLength() - expectedLen) : this.EMPTY_BUFFER;
        } catch (RuntimeException e) {
            this.log.error("Error handling data: " + e.getMessage(), (Throwable) e);
            this.skipBytes = expectedLen;
            this.fsm.applyTransition(5);
            return byteArray2;
        }
    }

    private ByteArray resizeByteArray(ByteArray byteArray, int i, int i2) {
        ByteBuffer allocate = ByteBuffer.allocate(i2);
        allocate.put(byteArray.getBytes(), i, i2);
        return new ByteArray(allocate.array());
    }

    private void uncompress(PendingPacket pendingPacket2) {
        ByteArray buffer = pendingPacket2.getBuffer();
        buffer.uncompress();
        pendingPacket2.setBuffer(buffer);
    }

    private void writeBytes(PendingPacket pendingPacket2, ByteArray byteArray) {
        ByteArray buffer = pendingPacket2.getBuffer();
        buffer.writeBytes(byteArray.getBytes());
        pendingPacket2.setBuffer(buffer);
    }

    private void writeBytes(PendingPacket pendingPacket2, ByteArray byteArray, int i) {
        ByteArray buffer = pendingPacket2.getBuffer();
        buffer.writeBytes(byteArray.getBytes(), i);
        pendingPacket2.setBuffer(buffer);
    }

    private void writeTCP(IMessage iMessage, ByteArray byteArray) {
        this.bitSwarm.getSocket().write(byteArray.getBytes());
        if (this.isDebugMode) {
            this.log.info("Data written: " + iMessage.getContent().getHexDump());
        }
    }

    private void writeUDP(IMessage iMessage, ByteArray byteArray) {
        this.bitSwarm.getUdpManager().send(byteArray);
    }

    public final IProtocolCodec getCodec() {
        return this.protocolCodec;
    }

    public void onDataRead(ByteArray byteArray) {
        if (byteArray.getLength() == 0) {
            throw new SFSException("Unexpected empty packet data: no readable bytes available!");
        }
        if (this.bitSwarm != null && this.isDebugMode) {
            if (byteArray.getLength() > 1024) {
                this.log.info("Data Read: Size > 1024, dump omitted");
            } else {
                this.log.info("Data Read: " + ByteUtils.fullHexDump(byteArray.getBytes()));
            }
        }
        byteArray.setPosition(0);
        while (byteArray.getLength() > 0) {
            if (getReadState() == 0) {
                byteArray = handleNewPacket(byteArray);
            } else if (getReadState() == 1) {
                byteArray = handleDataSize(byteArray);
            } else if (getReadState() == 2) {
                byteArray = handleDataSizeFragment(byteArray);
            } else if (getReadState() == 3) {
                byteArray = handlePacketData(byteArray);
            } else if (getReadState() == 4) {
                byteArray = handleInvalidData(byteArray);
            }
        }
    }

    public void onDataWrite(IMessage iMessage) {
        boolean z;
        boolean z2 = false;
        ByteArray byteArray = new ByteArray();
        ByteArray byteArray2 = new ByteArray(iMessage.getContent().toBinary());
        if (byteArray2.getLength() > this.bitSwarm.getCompressionThreshold()) {
            byteArray2.compress();
            z = true;
        } else {
            z = false;
        }
        if (byteArray2.getLength() > this.bitSwarm.getMaxMessageSize()) {
            throw new SFSCodecException("Message size is too big: " + byteArray2.getLength() + ", the server limit is: " + this.bitSwarm.getMaxMessageSize());
        }
        char c = byteArray2.getLength() > 65535 ? (char) 4 : 2;
        boolean isEncrypted = iMessage.isEncrypted();
        boolean useBlueBox = this.bitSwarm.getUseBlueBox();
        if (c == 4) {
            z2 = true;
        }
        byteArray.writeByte(encodePacketHeader(new PacketHeader(true, isEncrypted, z, useBlueBox, z2)));
        if (c > 2) {
            byteArray.writeInt(byteArray2.getLength());
        } else {
            byteArray.writeUShort(byteArray2.getLength());
        }
        byteArray.writeBytes(byteArray2.getBytes());
        if (this.bitSwarm.getUseBlueBox()) {
            this.bitSwarm.getHttpClient().send(byteArray);
        } else if (!this.bitSwarm.getSocket().isConnected()) {
        } else {
            if (iMessage.isUDP()) {
                writeUDP(iMessage, byteArray);
            } else {
                writeTCP(iMessage, byteArray);
            }
        }
    }
}
