package sfs2x.client.core.sockets;

import java.net.InetSocketAddress;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.jboss.netty.bootstrap.ConnectionlessBootstrap;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.buffer.TruncatedChannelBuffer;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.FixedReceiveBufferSizePredictorFactory;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.jboss.netty.channel.socket.DatagramChannel;
import org.jboss.netty.channel.socket.DatagramChannelFactory;
import org.jboss.netty.channel.socket.nio.NioDatagramChannelFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sfs2x.client.core.EventDispatcher;
import sfs2x.client.core.IDispatchable;
import sfs2x.client.core.IEventListener;

public class UDPSocketLayer implements IDispatchable, ISocketLayer {
    /* access modifiers changed from: private */
    public DatagramChannel channel;
    private EventDispatcher dispatcher = new EventDispatcher(this);
    private DatagramChannelFactory factory;
    private String ipAddress;
    private boolean isDisconnecting = false;
    private Logger log = LoggerFactory.getLogger((Class) getClass());
    private int socketNumber;

    class UDPClientHandler extends SimpleChannelUpstreamHandler {
        private UDPClientHandler() {
        }

        /* synthetic */ UDPClientHandler(UDPSocketLayer uDPSocketLayer, UDPClientHandler uDPClientHandler) {
            this();
        }

        public void exceptionCaught(ChannelHandlerContext channelHandlerContext, ExceptionEvent exceptionEvent) {
            UDPSocketLayer.this.channel.close();
            UDPSocketLayer.this.handleError("Socket error: " + exceptionEvent.getCause().getMessage());
        }

        public void messageReceived(ChannelHandlerContext channelHandlerContext, MessageEvent messageEvent) {
            try {
                UDPSocketLayer.this.handleBinaryData(((TruncatedChannelBuffer) messageEvent.getMessage()).array());
            } catch (Exception e) {
                UDPSocketLayer.this.handleError("General error reading data from socket: " + e.getMessage());
            }
        }
    }

    private void callOnData(byte[] bArr) {
        SocketEvent socketEvent = new SocketEvent(SocketEvent.OnData);
        socketEvent.getArguments().put("data", bArr);
        this.dispatcher.dispatchEvent(socketEvent);
    }

    private void callOnError(String str) {
        SocketEvent socketEvent = new SocketEvent(SocketEvent.OnError);
        socketEvent.getArguments().put("message", str);
        this.dispatcher.dispatchEvent(socketEvent);
    }

    /* access modifiers changed from: private */
    public void handleBinaryData(byte[] bArr) {
        callOnData(bArr);
    }

    /* access modifiers changed from: private */
    public void handleError(final String str) {
        new Thread(new Runnable() {
            public void run() {
                UDPSocketLayer.this.handleErrorThread(str);
            }
        }).start();
    }

    /* access modifiers changed from: private */
    public void handleErrorThread(String str) {
        releaseResources();
        if (!this.isDisconnecting) {
            logError(str);
            callOnError(str);
        }
    }

    private void logError(String str) {
        this.log.error("UDPSocketLayer: " + str);
    }

    private void releaseResources() {
        if (this.channel != null) {
            this.channel.close();
        }
        if (this.factory != null) {
            this.factory.releaseExternalResources();
        }
        this.factory = null;
        this.channel = null;
    }

    public void addEventListener(String str, IEventListener iEventListener) {
        this.dispatcher.addEventListener(str, iEventListener);
    }

    public void connect(String str, int i) {
        this.ipAddress = str;
        this.socketNumber = i;
        this.factory = new NioDatagramChannelFactory((Executor) Executors.newCachedThreadPool());
        ConnectionlessBootstrap connectionlessBootstrap = new ConnectionlessBootstrap(this.factory);
        connectionlessBootstrap.setPipelineFactory(new ChannelPipelineFactory() {
            public ChannelPipeline getPipeline() {
                return Channels.pipeline(new UDPClientHandler(UDPSocketLayer.this, (UDPClientHandler) null));
            }
        });
        connectionlessBootstrap.setOption("broadcast", "true");
        connectionlessBootstrap.setOption("receiveBufferSizePredictorFactory", new FixedReceiveBufferSizePredictorFactory(1024));
        this.channel = (DatagramChannel) connectionlessBootstrap.bind(new InetSocketAddress(0));
    }

    public void disconnect() {
        this.isDisconnecting = true;
        releaseResources();
        this.isDisconnecting = false;
    }

    public void disconnect(String str) {
    }

    public EventDispatcher getDispatcher() {
        return this.dispatcher;
    }

    public boolean isConnected() {
        return false;
    }

    public void kill() {
    }

    public boolean requiresConnection() {
        return false;
    }

    public void write(byte[] bArr) {
        try {
            this.channel.write(ChannelBuffers.wrappedBuffer(bArr), new InetSocketAddress(this.ipAddress, this.socketNumber));
        } catch (Exception e) {
            e.printStackTrace();
            logError("Error writing UDP data: " + e.getLocalizedMessage());
            handleError(e.getLocalizedMessage());
        }
    }
}
