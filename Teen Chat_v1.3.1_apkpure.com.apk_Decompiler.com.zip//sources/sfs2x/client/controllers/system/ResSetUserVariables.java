package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.ArrayList;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.User;
import sfs2x.client.entities.variables.SFSUserVariable;
import sfs2x.client.entities.variables.UserVariable;

public class ResSetUserVariables implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        int intValue = content.getInt("u").intValue();
        ISFSArray sFSArray = content.getSFSArray("vl");
        User userById = iSmartFox.getUserManager().getUserById(intValue);
        ArrayList arrayList = new ArrayList();
        if (userById != null) {
            for (int i = 0; i < sFSArray.size(); i++) {
                UserVariable fromSFSArray = SFSUserVariable.fromSFSArray(sFSArray.getSFSArray(i));
                userById.setVariable(fromSFSArray);
                arrayList.add(fromSFSArray.getName());
            }
            hashMap.put("changedVars", arrayList);
            hashMap.put("user", userById);
            iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.USER_VARIABLES_UPDATE, hashMap));
            return;
        }
        iSmartFox.getLogger().warn("UserVariablesUpdate: unknown user id = " + intValue);
    }
}
