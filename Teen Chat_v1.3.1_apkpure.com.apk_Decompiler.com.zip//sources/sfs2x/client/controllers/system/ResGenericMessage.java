package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSBuddyEvent;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.Buddy;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.SFSUser;
import sfs2x.client.entities.User;
import sfs2x.client.requests.GenericMessageRequest;

public class ResGenericMessage implements IResHandler {
    private ISmartFox sfs;

    private void handleAdminMessage(ISFSObject iSFSObject) {
        handleModMessage(iSFSObject, SFSEvent.ADMIN_MESSAGE);
    }

    private void handleBuddyMessage(ISFSObject iSFSObject) {
        HashMap hashMap = new HashMap();
        int intValue = iSFSObject.getInt("u").intValue();
        Buddy buddyById = this.sfs.getBuddyManager().getBuddyById(intValue);
        hashMap.put("isItMe", Boolean.valueOf(this.sfs.getMySelf().getId() == intValue));
        hashMap.put("buddy", buddyById);
        hashMap.put("message", iSFSObject.getUtfString("m"));
        hashMap.put("data", iSFSObject.getSFSObject("p"));
        this.sfs.dispatchEvent(new SFSBuddyEvent(SFSBuddyEvent.BUDDY_MESSAGE, hashMap));
    }

    private void handleModMessage(ISFSObject iSFSObject) {
        handleModMessage(iSFSObject, SFSEvent.MODERATOR_MESSAGE);
    }

    private void handleModMessage(ISFSObject iSFSObject, String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("sender", SFSUser.fromSFSArray(iSFSObject.getSFSArray(GenericMessageRequest.KEY_SENDER_DATA)));
        hashMap.put("message", iSFSObject.getUtfString("m"));
        hashMap.put("data", iSFSObject.getSFSObject("p"));
        this.sfs.dispatchEvent(new SFSEvent(str, hashMap));
    }

    private void handleObjectMessage(ISFSObject iSFSObject) {
        HashMap hashMap = new HashMap();
        hashMap.put("sender", this.sfs.getUserManager().getUserById(iSFSObject.getInt("u").intValue()));
        hashMap.put("message", iSFSObject.getSFSObject("p"));
        this.sfs.dispatchEvent(new SFSEvent(SFSEvent.OBJECT_MESSAGE, hashMap));
    }

    private void handlePrivateMessage(ISFSObject iSFSObject) {
        HashMap hashMap = new HashMap();
        User userById = this.sfs.getUserManager().getUserById(iSFSObject.getInt("u").intValue());
        if (userById == null) {
            if (!iSFSObject.containsKey(GenericMessageRequest.KEY_SENDER_DATA)) {
                this.sfs.getLogger().warn("Unexpected. Private message has no Sender details!");
                return;
            }
            userById = SFSUser.fromSFSArray(iSFSObject.getSFSArray(GenericMessageRequest.KEY_SENDER_DATA));
        }
        hashMap.put("sender", userById);
        hashMap.put("message", iSFSObject.getUtfString("m"));
        hashMap.put("data", iSFSObject.getSFSObject("p"));
        this.sfs.dispatchEvent(new SFSEvent(SFSEvent.PRIVATE_MESSAGE, hashMap));
    }

    private void handlePublicMessage(ISFSObject iSFSObject) {
        HashMap hashMap = new HashMap();
        int intValue = iSFSObject.getInt("r").intValue();
        Room roomById = this.sfs.getRoomManager().getRoomById(intValue);
        if (roomById != null) {
            hashMap.put("room", roomById);
            hashMap.put("sender", this.sfs.getUserManager().getUserById(iSFSObject.getInt("u").intValue()));
            hashMap.put("message", iSFSObject.getUtfString("m"));
            hashMap.put("data", iSFSObject.getSFSObject("p"));
            this.sfs.dispatchEvent(new SFSEvent(SFSEvent.PUBLIC_MESSAGE, hashMap));
            return;
        }
        this.sfs.getLogger().warn("Unexpected, PublicMessage target room doesn't exist. RoomId: " + intValue);
    }

    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        this.sfs = iSmartFox;
        ISFSObject content = iMessage.getContent();
        byte byteValue = content.getByte("t").byteValue();
        if (byteValue == 0) {
            handlePublicMessage(content);
        } else if (byteValue == 1) {
            handlePrivateMessage(content);
        } else if (byteValue == 5) {
            handleBuddyMessage(content);
        } else if (byteValue == 2) {
            handleModMessage(content);
        } else if (byteValue == 3) {
            handleAdminMessage(content);
        } else if (byteValue == 4) {
            handleObjectMessage(content);
        }
    }
}
