package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;

public class ResLogout implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        iSmartFox.handleLogout();
        hashMap.put("zoneName", content.getUtfString("zn"));
        iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.LOGOUT, hashMap));
    }
}
