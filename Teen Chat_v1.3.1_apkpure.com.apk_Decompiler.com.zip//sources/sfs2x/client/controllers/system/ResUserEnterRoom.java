package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.User;

public class ResUserEnterRoom implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        Room roomById = iSmartFox.getRoomManager().getRoomById(content.getInt("r").intValue());
        if (roomById != null) {
            User orCreateUser = systemController.getOrCreateUser(content.getSFSArray("u"), true, roomById);
            roomById.addUser(orCreateUser);
            hashMap.put("user", orCreateUser);
            hashMap.put("room", roomById);
            iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.USER_ENTER_ROOM, hashMap));
        }
    }
}
