package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.User;

public class ResUserExitRoom implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        int intValue = content.getInt("r").intValue();
        int intValue2 = content.getInt("u").intValue();
        Room roomById = iSmartFox.getRoomManager().getRoomById(intValue);
        User userById = iSmartFox.getUserManager().getUserById(intValue2);
        if (roomById == null || userById == null) {
            iSmartFox.getLogger().warn("Failed to handle UserExit event. Room: " + roomById + ", User: " + userById);
            return;
        }
        roomById.removeUser(userById);
        iSmartFox.getUserManager().removeUser(userById);
        if (userById.isItMe() && roomById.isJoined()) {
            roomById.setJoined(false);
            if (iSmartFox.getJoinedRooms().size() == 0) {
                iSmartFox.setLastJoinedRoom((Room) null);
            }
            if (!roomById.isManaged()) {
                iSmartFox.getRoomManager().removeRoom(roomById);
            }
        }
        hashMap.put("user", userById);
        hashMap.put("room", roomById);
        iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.USER_EXIT_ROOM, hashMap));
    }
}
