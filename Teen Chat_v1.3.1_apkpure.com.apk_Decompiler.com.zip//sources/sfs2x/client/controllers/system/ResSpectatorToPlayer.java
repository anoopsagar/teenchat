package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.User;
import sfs2x.client.requests.BaseRequest;
import sfs2x.client.util.SFSErrorCodes;

public class ResSpectatorToPlayer implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        if (!content.containsKey(BaseRequest.KEY_ERROR_CODE)) {
            int intValue = content.getInt("r").intValue();
            int intValue2 = content.getInt("u").intValue();
            short shortValue = content.getShort("p").shortValue();
            User userById = iSmartFox.getUserManager().getUserById(intValue2);
            Room roomById = iSmartFox.getRoomManager().getRoomById(intValue);
            if (roomById == null) {
                iSmartFox.getLogger().warn("Room not found, ID:" + intValue + ", SpectatorToPlayer failed.");
            } else if (userById == null) {
                iSmartFox.getLogger().warn("User not found, ID:" + intValue2 + ", SpectatorToPlayer failed.");
            } else if (userById.isJoinedInRoom(roomById)) {
                userById.setPlayerId(shortValue, roomById);
                hashMap.put("room", roomById);
                hashMap.put("user", userById);
                hashMap.put("playerId", Integer.valueOf(shortValue));
                iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.SPECTATOR_TO_PLAYER, hashMap));
            } else {
                iSmartFox.getLogger().warn("User: " + userById + " not joined in Room: " + roomById + ", SpectatorToPlayer failed.");
            }
        } else {
            short shortValue2 = content.getShort(BaseRequest.KEY_ERROR_CODE).shortValue();
            hashMap.put("errorMessage", SFSErrorCodes.getErrorMessage(shortValue2, content.getUtfStringArray(BaseRequest.KEY_ERROR_PARAMS).toArray()));
            hashMap.put("errorCode", Short.valueOf(shortValue2));
            iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.SPECTATOR_TO_PLAYER_ERROR, hashMap));
        }
    }
}
