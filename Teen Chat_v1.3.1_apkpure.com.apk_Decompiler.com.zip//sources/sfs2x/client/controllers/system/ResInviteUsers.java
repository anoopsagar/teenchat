package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.SFSUser;
import sfs2x.client.entities.User;
import sfs2x.client.entities.invitation.SFSInvitation;
import sfs2x.client.requests.game.InviteUsersRequest;

public class ResInviteUsers implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        User userById = content.containsKey(InviteUsersRequest.KEY_USER_ID) ? iSmartFox.getUserManager().getUserById(content.getInt(InviteUsersRequest.KEY_USER_ID).intValue()) : SFSUser.fromSFSArray(content.getSFSArray("u"));
        short shortValue = content.getShort("t").shortValue();
        int intValue = content.getInt(InviteUsersRequest.KEY_INVITATION_ID).intValue();
        SFSInvitation sFSInvitation = new SFSInvitation(userById, iSmartFox.getMySelf(), shortValue, content.getSFSObject("p"));
        sFSInvitation.setId(intValue);
        hashMap.put(SFSEvent.INVITATION, sFSInvitation);
        iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.INVITATION, hashMap));
    }
}
