package sfs2x.client.controllers.system;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.controllers.IResHandler;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.entities.Room;
import sfs2x.client.requests.BaseRequest;
import sfs2x.client.requests.ChangeRoomNameRequest;
import sfs2x.client.util.SFSErrorCodes;

public class ResChangeRoomName implements IResHandler {
    public void handleResponse(ISmartFox iSmartFox, SystemController systemController, IMessage iMessage) {
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        if (!content.containsKey(BaseRequest.KEY_ERROR_CODE)) {
            int intValue = content.getInt("r").intValue();
            Room roomById = iSmartFox.getRoomManager().getRoomById(intValue);
            if (roomById != null) {
                hashMap.put("oldName", roomById.getName());
                iSmartFox.getRoomManager().changeRoomName(roomById, content.getUtfString(ChangeRoomNameRequest.KEY_NAME));
                hashMap.put("room", roomById);
                iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.ROOM_NAME_CHANGE, hashMap));
                return;
            }
            iSmartFox.getLogger().warn("Room not found, ID:" + intValue + ", Room name change failed.");
            return;
        }
        short shortValue = content.getShort(BaseRequest.KEY_ERROR_CODE).shortValue();
        hashMap.put("errorMessage", SFSErrorCodes.getErrorMessage(shortValue, content.getUtfStringArray(BaseRequest.KEY_ERROR_PARAMS).toArray()));
        hashMap.put("errorCode", Short.valueOf(shortValue));
        iSmartFox.dispatchEvent(new SFSEvent(SFSEvent.ROOM_NAME_CHANGE_ERROR, hashMap));
    }
}
