package sfs2x.client.controllers;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.HashMap;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.BaseController;
import sfs2x.client.bitswarm.BitSwarmClient;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.core.SFSEvent;

public class ExtensionController extends BaseController {
    public static final String KEY_CMD = "c";
    public static final String KEY_PARAMS = "p";
    public static final String KEY_ROOM = "r";
    private BitSwarmClient bitSwarm;
    private ISmartFox sfs;

    public ExtensionController(ISmartFox iSmartFox) {
        this.sfs = iSmartFox;
    }

    public ExtensionController(BitSwarmClient bitSwarmClient) {
        this.bitSwarm = bitSwarmClient;
        this.sfs = bitSwarmClient.getSfs();
    }

    public void handleMessage(IMessage iMessage) {
        if (this.sfs.isDebug()) {
            this.log.info(iMessage.toString());
        }
        ISFSObject content = iMessage.getContent();
        HashMap hashMap = new HashMap();
        hashMap.put("cmd", content.getUtfString("c"));
        hashMap.put("params", content.getSFSObject("p"));
        if (content.containsKey("r")) {
            hashMap.put("sourceRoom", content.getInt("r"));
        }
        if (iMessage.isUDP()) {
            hashMap.put("packetId", Long.valueOf(iMessage.getPacketId()));
        }
        this.sfs.dispatchEvent(new SFSEvent(SFSEvent.EXTENSION_RESPONSE, hashMap));
    }
}
