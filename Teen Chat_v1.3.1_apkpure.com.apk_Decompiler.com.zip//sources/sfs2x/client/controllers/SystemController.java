package sfs2x.client.controllers;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang.time.DateUtils;
import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.BaseController;
import sfs2x.client.bitswarm.BitSwarmClient;
import sfs2x.client.bitswarm.IMessage;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.SFSRoom;
import sfs2x.client.entities.SFSUser;
import sfs2x.client.entities.User;
import sfs2x.client.entities.managers.IRoomManager;
import sfs2x.client.entities.variables.SFSUserVariable;
import sfs2x.client.requests.BaseRequest;

public class SystemController extends BaseController {
    private static final String RES_HANDLERS_PACKAGE = "sfs2x.client.controllers.system.";
    private BitSwarmClient bitSwarm;
    private Map responseHandlerCache;
    private Map responseHandlers;
    private ISmartFox sfs;

    public SystemController() {
        initRequestHandlers();
    }

    public SystemController(ISmartFox iSmartFox) {
        this();
        this.sfs = iSmartFox;
    }

    public SystemController(BitSwarmClient bitSwarmClient) {
        this();
        this.bitSwarm = bitSwarmClient;
        this.sfs = bitSwarmClient.getSfs();
    }

    private String getEvtName(int i) {
        return (String) this.responseHandlers.get(Integer.valueOf(i));
    }

    private void initRequestHandlers() {
        this.responseHandlers = new HashMap();
        this.responseHandlerCache = new HashMap();
        this.responseHandlers.put(0, "ResHandshake");
        this.responseHandlers.put(1, "ResLogin");
        this.responseHandlers.put(2, "ResLogout");
        this.responseHandlers.put(4, "ResJoinRoom");
        this.responseHandlers.put(6, "ResCreateRoom");
        this.responseHandlers.put(7, "ResGenericMessage");
        this.responseHandlers.put(8, "ResChangeRoomName");
        this.responseHandlers.put(9, "ResChangeRoomPassword");
        this.responseHandlers.put(19, "ResChangeRoomCapacity");
        this.responseHandlers.put(11, "ResSetRoomVariables");
        this.responseHandlers.put(12, "ResSetUserVariables");
        this.responseHandlers.put(13, "ResCallExtension");
        this.responseHandlers.put(15, "ResSubscribeRoomGroup");
        this.responseHandlers.put(16, "ResUnsubscribeRoomGroup");
        this.responseHandlers.put(17, "ResSpectatorToPlayer");
        this.responseHandlers.put(18, "ResPlayerToSpectator");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.InitBuddyList), "ResInitBuddyList");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.AddBuddy), "ResAddBuddy");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.RemoveBuddy), "ResRemoveBuddy");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.BlockBuddy), "ResBlockBuddy");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.GoOnline), "ResGoOnline");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.SetBuddyVariables), "ResSetBuddyVariables");
        this.responseHandlers.put(27, "ResFindRooms");
        this.responseHandlers.put(28, "ResFindUsers");
        this.responseHandlers.put(300, "ResInviteUsers");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.InvitationReply), "ResInvitationReply");
        this.responseHandlers.put(Integer.valueOf(BaseRequest.QuickJoinGame), "ResQuickJoinGame");
        this.responseHandlers.put(29, "ResPingPong");
        this.responseHandlers.put(30, "ResSetUserPosition");
        this.responseHandlers.put(Integer.valueOf(DateUtils.MILLIS_IN_SECOND), "ResUserEnterRoom");
        this.responseHandlers.put(Integer.valueOf(DateUtils.SEMI_MONTH), "ResUserCountChange");
        this.responseHandlers.put(1002, "ResUserLost");
        this.responseHandlers.put(1003, "ResRoomLost");
        this.responseHandlers.put(1004, "ResUserExitRoom");
        this.responseHandlers.put(1005, "ResClientDisconnect");
        this.responseHandlers.put(1006, "ResReconnectionFailure");
        this.responseHandlers.put(1007, "ResSetMMOItemVariable");
    }

    public User getOrCreateUser(ISFSArray iSFSArray, boolean z, Room room) {
        User user;
        User userById = this.sfs.getUserManager().getUserById(iSFSArray.getInt(0).intValue());
        if (userById == null) {
            user = SFSUser.fromSFSArray(iSFSArray, room);
            user.setUserManager(this.sfs.getUserManager());
        } else {
            if (room != null) {
                userById.setPlayerId(iSFSArray.getShort(3).shortValue(), room);
                ISFSArray sFSArray = iSFSArray.getSFSArray(4);
                for (int i = 0; i < sFSArray.size(); i++) {
                    userById.setVariable(SFSUserVariable.fromSFSArray(sFSArray.getSFSArray(i)));
                }
            }
            user = userById;
        }
        if (z) {
            this.sfs.getUserManager().addUser(user);
        }
        return user;
    }

    public void handleMessage(IMessage iMessage) {
        IResHandler iResHandler;
        if (this.sfs.isDebug()) {
            this.log.info("Message: " + getEvtName(iMessage.getId()) + " " + iMessage);
        }
        String str = (String) this.responseHandlers.get(Integer.valueOf(iMessage.getId()));
        if (str != null) {
            try {
                if (this.responseHandlerCache.containsKey(str)) {
                    iResHandler = (IResHandler) this.responseHandlerCache.get(str);
                } else {
                    iResHandler = (IResHandler) Class.forName(RES_HANDLERS_PACKAGE + str).newInstance();
                    this.responseHandlerCache.put(str, iResHandler);
                }
                iResHandler.handleResponse(this.sfs, this, iMessage);
            } catch (ClassNotFoundException e) {
                this.log.warn(String.format("Cannot instantiate handler for eventId: %s, %s, Class: %s.%s", new Object[]{Integer.valueOf(iMessage.getId()), str, RES_HANDLERS_PACKAGE, str}));
            } catch (Exception e2) {
                this.log.warn("Error in handling event: " + e2);
                e2.printStackTrace();
            }
        } else {
            this.log.warn("Unknown message id: " + iMessage.getId());
        }
    }

    public void populateRoomList(ISFSArray iSFSArray) {
        IRoomManager roomManager = this.sfs.getRoomManager();
        for (int i = 0; i < iSFSArray.size(); i++) {
            roomManager.replaceRoom(SFSRoom.fromSFSArray(iSFSArray.getSFSArray(i)));
        }
    }
}
