package sfs2x.client.entities.variables;

import com.smartfoxserver.v2.entities.data.ISFSArray;

public class SFSRoomVariable extends SFSUserVariable implements RoomVariable {
    private boolean isPersistent;
    private boolean isPrivate;

    public SFSRoomVariable(String str, Object obj) {
        super(str, obj, -1);
    }

    public SFSRoomVariable(String str, Object obj, int i) {
        super(str, obj, i);
    }

    public static RoomVariable fromSFSArray(ISFSArray iSFSArray) {
        SFSRoomVariable sFSRoomVariable = new SFSRoomVariable(iSFSArray.getUtfString(0), iSFSArray.getElementAt(2), iSFSArray.getByte(1).byteValue());
        sFSRoomVariable.setPrivate(iSFSArray.getBool(3).booleanValue());
        sFSRoomVariable.setPersistent(iSFSArray.getBool(4).booleanValue());
        return sFSRoomVariable;
    }

    public boolean isPersistent() {
        return this.isPersistent;
    }

    public boolean isPrivate() {
        return this.isPrivate;
    }

    public void setPersistent(boolean z) {
        this.isPersistent = z;
    }

    public void setPrivate(boolean z) {
        this.isPrivate = z;
    }

    public ISFSArray toSFSArray() {
        ISFSArray sFSArray = super.toSFSArray();
        sFSArray.addBool(this.isPrivate);
        sFSArray.addBool(this.isPersistent);
        return sFSArray;
    }

    public String toString() {
        return "[RVar: " + this.name + ", type: " + this.type + ", value: " + this.val + ", isPriv: " + this.isPrivate + "]";
    }
}
