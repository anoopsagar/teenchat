package sfs2x.client.entities.variables;

public class ReservedRoomVariables {
    public static final String RV_GAME_STARTED = "$GS";
}
