package sfs2x.client.entities.variables;

public interface IMMOItemVariable extends UserVariable {
}
