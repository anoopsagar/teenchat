package sfs2x.client.entities.variables;

public interface BuddyVariable extends UserVariable {
    boolean isOffline();
}
