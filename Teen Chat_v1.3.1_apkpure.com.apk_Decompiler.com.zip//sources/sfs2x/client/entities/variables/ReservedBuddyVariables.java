package sfs2x.client.entities.variables;

public class ReservedBuddyVariables {
    public static final String BV_NICKNAME = "$__BV_NICKNAME__";
    public static final String BV_ONLINE = "$__BV_ONLINE__";
    public static final String BV_STATE = "$__BV_STATE__";
}
