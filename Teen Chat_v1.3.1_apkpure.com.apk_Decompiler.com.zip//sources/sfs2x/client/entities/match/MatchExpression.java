package sfs2x.client.entities.match;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.SFSArray;
import net.sf.json.util.JSONUtils;

public class MatchExpression {
    private IMatcher condition;
    private LogicOperator logicOp;
    private MatchExpression next;
    private MatchExpression parent;
    private Object value;
    private String varName;

    public MatchExpression(String str, IMatcher iMatcher, Object obj) {
        this.varName = str;
        this.condition = iMatcher;
        this.value = obj;
    }

    protected MatchExpression(String str, IMatcher iMatcher, Object obj, LogicOperator logicOperator, MatchExpression matchExpression) {
        this(str, iMatcher, obj);
        this.logicOp = logicOperator;
        this.parent = matchExpression;
    }

    private ISFSArray expressionAsSFSArray() {
        SFSArray sFSArray = new SFSArray();
        if (this.logicOp != null) {
            sFSArray.addUtfString(this.logicOp.getId());
        } else {
            sFSArray.addNull();
        }
        sFSArray.addUtfString(this.varName);
        sFSArray.addByte((byte) this.condition.getType());
        sFSArray.addUtfString(this.condition.getSymbol());
        if (this.condition.getType() == 0) {
            sFSArray.addBool(((Boolean) this.value).booleanValue());
        } else if (this.condition.getType() != 1) {
            sFSArray.addUtfString(this.value.toString());
        } else if (this.value instanceof Integer) {
            sFSArray.addDouble(((Integer) this.value).doubleValue());
        } else if (this.value instanceof Double) {
            sFSArray.addDouble(((Double) this.value).doubleValue());
        } else {
            sFSArray.addDouble(((Double) this.value).doubleValue());
        }
        return sFSArray;
    }

    public MatchExpression and(String str, IMatcher iMatcher, Object obj) {
        this.next = new MatchExpression(str, iMatcher, obj, LogicOperator.AND, this);
        return this.next;
    }

    public String asString() {
        StringBuilder sb = new StringBuilder();
        if (this.logicOp != null) {
            sb.append(" ").append(this.logicOp.getId()).append(" ");
        }
        sb.append("(");
        sb.append(this.varName).append(" ").append(this.condition.getSymbol()).append(" ").append(this.value instanceof String ? JSONUtils.SINGLE_QUOTE + this.value + JSONUtils.SINGLE_QUOTE : this.value);
        sb.append(")");
        return sb.toString();
    }

    public IMatcher getCondition() {
        return this.condition;
    }

    public LogicOperator getLogicOp() {
        return this.logicOp;
    }

    public MatchExpression getNext() {
        return this.next;
    }

    public Object getValue() {
        return this.value;
    }

    public String getVarName() {
        return this.varName;
    }

    public boolean hasNext() {
        return this.next != null;
    }

    public MatchExpression or(String str, IMatcher iMatcher, Object obj) {
        this.next = new MatchExpression(str, iMatcher, obj, LogicOperator.OR, this);
        return this.next;
    }

    public MatchExpression rewind() {
        while (this.parent != null) {
            this = this.parent;
        }
        return this;
    }

    public ISFSArray toSFSArray() {
        MatchExpression rewind = rewind();
        SFSArray sFSArray = new SFSArray();
        sFSArray.addSFSArray(rewind.expressionAsSFSArray());
        while (rewind.hasNext()) {
            rewind = rewind.next;
            sFSArray.addSFSArray(rewind.expressionAsSFSArray());
        }
        return sFSArray;
    }

    public String toString() {
        MatchExpression rewind = rewind();
        StringBuilder sb = new StringBuilder(rewind.asString());
        while (rewind.hasNext()) {
            rewind = rewind.next;
            sb.append(rewind.asString());
        }
        return sb.toString();
    }
}
