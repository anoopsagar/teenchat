package sfs2x.client.entities.match;

public interface IMatcher {
    String getSymbol();

    int getType();
}
