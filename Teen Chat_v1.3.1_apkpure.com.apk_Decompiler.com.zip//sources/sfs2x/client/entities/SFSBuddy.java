package sfs2x.client.entities;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import sfs2x.client.entities.variables.BuddyVariable;
import sfs2x.client.entities.variables.ReservedBuddyVariables;
import sfs2x.client.entities.variables.SFSBuddyVariable;

public class SFSBuddy implements Buddy {
    protected int id;
    protected boolean isBlocked;
    protected boolean isTemp;
    protected String name;
    protected Map variables;

    public SFSBuddy(int i, String str) {
        this(i, str, false, false);
    }

    public SFSBuddy(int i, String str, boolean z) {
        this(i, str, z, false);
    }

    public SFSBuddy(int i, String str, boolean z, boolean z2) {
        this.variables = new HashMap();
        this.name = str;
        this.id = i;
        this.isBlocked = z;
        this.isTemp = z2;
        this.variables = new HashMap();
    }

    public static Buddy fromSFSArray(ISFSArray iSFSArray) {
        SFSBuddy sFSBuddy = new SFSBuddy(iSFSArray.getInt(0).intValue(), iSFSArray.getUtfString(1), iSFSArray.getBool(2).booleanValue(), iSFSArray.size() > 4 ? iSFSArray.getBool(4).booleanValue() : false);
        ISFSArray sFSArray = iSFSArray.getSFSArray(3);
        for (int i = 0; i < sFSArray.size(); i++) {
            sFSBuddy.setVariable(SFSBuddyVariable.fromSFSArray(sFSArray.getSFSArray(i)));
        }
        return sFSBuddy;
    }

    public void clearVolatileVariables() {
        Iterator it = this.variables.values().iterator();
        while (it.hasNext()) {
            if (!((BuddyVariable) it.next()).getName().startsWith(SFSBuddyVariable.OFFLINE_PREFIX)) {
                it.remove();
            }
        }
    }

    public boolean containsVariable(String str) {
        return this.variables.containsKey(str);
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getNickName() {
        BuddyVariable variable = getVariable(ReservedBuddyVariables.BV_NICKNAME);
        if (variable == null) {
            return null;
        }
        return variable.getStringValue();
    }

    public List getOfflineVariables() {
        ArrayList arrayList = new ArrayList();
        for (BuddyVariable buddyVariable : this.variables.values()) {
            if (buddyVariable.getName().startsWith(SFSBuddyVariable.OFFLINE_PREFIX)) {
                arrayList.add(buddyVariable);
            }
        }
        return arrayList;
    }

    public List getOnlineVariables() {
        ArrayList arrayList = new ArrayList();
        for (BuddyVariable buddyVariable : this.variables.values()) {
            if (!buddyVariable.getName().startsWith(SFSBuddyVariable.OFFLINE_PREFIX)) {
                arrayList.add(buddyVariable);
            }
        }
        return arrayList;
    }

    public String getState() {
        BuddyVariable variable = getVariable(ReservedBuddyVariables.BV_STATE);
        if (variable == null) {
            return null;
        }
        return variable.getStringValue();
    }

    public BuddyVariable getVariable(String str) {
        if (this.variables.containsKey(str)) {
            return (BuddyVariable) this.variables.get(str);
        }
        return null;
    }

    public List getVariables() {
        return new ArrayList(this.variables.values());
    }

    public boolean isBlocked() {
        return this.isBlocked;
    }

    public boolean isOnline() {
        BuddyVariable variable = getVariable(ReservedBuddyVariables.BV_ONLINE);
        return (variable == null ? true : variable.getBoolValue().booleanValue()) && this.id > -1;
    }

    public boolean isTemp() {
        return this.isTemp;
    }

    public void removeVariable(String str) {
        this.variables.remove(str);
    }

    public void setBlocked(boolean z) {
        this.isBlocked = z;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setVariable(BuddyVariable buddyVariable) {
        this.variables.put(buddyVariable.getName(), buddyVariable);
    }

    public void setVariables(List list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            setVariable((BuddyVariable) it.next());
        }
    }

    public String toString() {
        return "[Buddy: " + this.name + ", id: " + this.id + "]";
    }
}
