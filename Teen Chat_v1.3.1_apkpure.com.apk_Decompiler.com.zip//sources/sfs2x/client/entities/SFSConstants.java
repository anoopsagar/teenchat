package sfs2x.client.entities;

public class SFSConstants {
    public static final String DEFAULT_GROUP_ID = "default";
    public static final String REQUEST_UDP_PACKET_ID = "$FS_REQUEST_UDP_TIMESTAMP";
}
