package sfs2x.client.entities.managers;

import java.util.List;
import sfs2x.client.entities.Buddy;
import sfs2x.client.entities.variables.BuddyVariable;

public interface IBuddyManager {
    void addBuddy(Buddy buddy);

    void clearAll();

    boolean containsBuddy(String str);

    Buddy getBuddyById(int i);

    Buddy getBuddyByName(String str);

    Buddy getBuddyByNickName(String str);

    List getBuddyList();

    List getBuddyStates();

    String getMyNickName();

    boolean getMyOnlineState();

    String getMyState();

    BuddyVariable getMyVariable(String str);

    List getMyVariables();

    List getOfflineBuddies();

    List getOnlineBuddies();

    boolean isInited();

    Buddy removeBuddyById(int i);

    Buddy removeBuddyByName(String str);

    void setBuddyStates(List list);

    void setInited(boolean z);

    void setMyNickName(String str);

    void setMyOnlineState(boolean z);

    void setMyState(String str);

    void setMyVariable(BuddyVariable buddyVariable);

    void setMyVariables(List list);
}
