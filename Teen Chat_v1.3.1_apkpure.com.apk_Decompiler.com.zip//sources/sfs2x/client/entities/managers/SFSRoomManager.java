package sfs2x.client.entities.managers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.User;

public class SFSRoomManager implements IRoomManager {
    private List groups = new ArrayList();
    private String ownerZone;
    private Map roomsById = new HashMap();
    private Map roomsByName = new HashMap();
    protected ISmartFox smartFox;

    public SFSRoomManager(ISmartFox iSmartFox) {
        this.smartFox = iSmartFox;
    }

    private void removeRoom(int i, String str) {
        this.roomsById.remove(Integer.valueOf(i));
        this.roomsByName.remove(str);
    }

    public void addGroup(String str) {
        this.groups.add(str);
    }

    public void addRoom(Room room) {
        addRoom(room, true);
    }

    public void addRoom(Room room, boolean z) {
        this.roomsById.put(Integer.valueOf(room.getId()), room);
        this.roomsByName.put(room.getName(), room);
        if (!z) {
            room.setManaged(false);
        } else if (!containsGroup(room.getGroupId())) {
            addGroup(room.getGroupId());
        }
    }

    public void changeRoomCapacity(Room room, int i, int i2) {
        room.setMaxUsers(i);
        room.setMaxSpectators(i2);
    }

    public void changeRoomName(Room room, String str) {
        String name = room.getName();
        room.setName(str);
        this.roomsByName.put(str, room);
        this.roomsByName.remove(name);
    }

    public void changeRoomPasswordState(Room room, boolean z) {
        room.setPasswordProtected(z);
    }

    public boolean containsGroup(String str) {
        return this.groups.contains(str);
    }

    public boolean containsRoom(int i) {
        return this.roomsById.containsKey(Integer.valueOf(i));
    }

    public boolean containsRoom(String str) {
        return this.roomsByName.containsKey(str);
    }

    public boolean containsRoomInGroup(int i, String str) {
        for (Room id : getRoomListFromGroup(str)) {
            if (id.getId() == i) {
                return true;
            }
        }
        return false;
    }

    public boolean containsRoomInGroup(String str, String str2) {
        for (Room name : getRoomListFromGroup(str2)) {
            if (name.getName().equals(str)) {
                return true;
            }
        }
        return false;
    }

    public List getJoinedRooms() {
        ArrayList arrayList = new ArrayList();
        for (Room room : this.roomsById.values()) {
            if (room.isJoined()) {
                arrayList.add(room);
            }
        }
        return arrayList;
    }

    public String getOwnerZone() {
        return this.ownerZone;
    }

    public Room getRoomById(int i) {
        if (!this.roomsById.containsKey(Integer.valueOf(i))) {
            return null;
        }
        return (Room) this.roomsById.get(Integer.valueOf(i));
    }

    public Room getRoomByName(String str) {
        if (!this.roomsByName.containsKey(str)) {
            return null;
        }
        return (Room) this.roomsByName.get(str);
    }

    public int getRoomCount() {
        return this.roomsById.size();
    }

    public List getRoomGroups() {
        return this.groups;
    }

    public List getRoomList() {
        return new ArrayList(this.roomsById.values());
    }

    public List getRoomListFromGroup(String str) {
        ArrayList arrayList = new ArrayList();
        for (Room room : this.roomsById.values()) {
            if (room.getGroupId().equals(str)) {
                arrayList.add(room);
            }
        }
        return arrayList;
    }

    public ISmartFox getSmartFox() {
        return this.smartFox;
    }

    public List getUserRooms(User user) {
        ArrayList arrayList = new ArrayList();
        for (Room room : this.roomsById.values()) {
            if (room.containsUser(user)) {
                arrayList.add(room);
            }
        }
        return arrayList;
    }

    public void removeGroup(String str) {
        this.groups.remove(str);
        for (Room room : getRoomListFromGroup(str)) {
            if (!room.isJoined()) {
                removeRoom(room);
            } else {
                room.setManaged(false);
            }
        }
    }

    public void removeRoom(Room room) {
        removeRoom(room.getId(), room.getName());
    }

    public void removeRoomById(int i) {
        if (this.roomsById.containsKey(Integer.valueOf(i))) {
            removeRoom(i, ((Room) this.roomsById.get(Integer.valueOf(i))).getName());
        }
    }

    public void removeRoomByName(String str) {
        if (this.roomsByName.containsKey(str)) {
            removeRoom(((Room) this.roomsByName.get(str)).getId(), str);
        }
    }

    public void removeUser(User user) {
        for (Room room : this.roomsById.values()) {
            if (room.containsUser(user)) {
                room.removeUser(user);
            }
        }
    }

    public Room replaceRoom(Room room) {
        return replaceRoom(room, true);
    }

    public Room replaceRoom(Room room, boolean z) {
        Room roomById = getRoomById(room.getId());
        if (roomById != null) {
            roomById.merge(room);
            return roomById;
        }
        addRoom(room, z);
        return room;
    }
}
