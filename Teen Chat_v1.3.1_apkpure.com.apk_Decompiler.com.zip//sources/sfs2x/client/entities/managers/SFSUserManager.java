package sfs2x.client.entities.managers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.User;

public class SFSUserManager implements IUserManager {
    protected ISmartFox smartFox;
    private Map usersById = new HashMap();
    private Map usersByName = new HashMap();

    public SFSUserManager(ISmartFox iSmartFox) {
        this.smartFox = iSmartFox;
    }

    public void addUser(User user) {
        if (!(!this.usersById.containsKey(Integer.valueOf(user.getId())) || this.smartFox == null || this.smartFox.getLogger() == null)) {
            this.smartFox.getLogger().warn("Unexpected: duplicate user in UserManager: " + user);
        }
        addUserInternal(user);
    }

    /* access modifiers changed from: protected */
    public void addUserInternal(User user) {
        this.usersByName.put(user.getName(), user);
        this.usersById.put(Integer.valueOf(user.getId()), user);
    }

    public void clearAll() {
        this.usersByName = new HashMap();
        this.usersById = new HashMap();
    }

    public boolean containsUser(User user) {
        return this.usersByName.containsValue(user);
    }

    public boolean containsUserId(int i) {
        return this.usersById.containsKey(Integer.valueOf(i));
    }

    public boolean containsUserName(String str) {
        return this.usersByName.containsKey(str);
    }

    public ISmartFox getSmartFox() {
        return this.smartFox;
    }

    public User getUserById(int i) {
        if (!this.usersById.containsKey(Integer.valueOf(i))) {
            return null;
        }
        return (User) this.usersById.get(Integer.valueOf(i));
    }

    public User getUserByName(String str) {
        if (!this.usersByName.containsKey(str)) {
            return null;
        }
        return (User) this.usersByName.get(str);
    }

    public int getUserCount() {
        return this.usersById.size();
    }

    public List getUserList() {
        return new ArrayList(this.usersById.values());
    }

    public void removeUser(User user) {
        this.usersByName.remove(user.getName());
        this.usersById.remove(Integer.valueOf(user.getId()));
    }

    public void removeUserById(int i) {
        if (this.usersById.containsKey(Integer.valueOf(i))) {
            removeUser((User) this.usersById.get(Integer.valueOf(i)));
        }
    }
}
