package sfs2x.client.entities;

import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.data.Vec3D;
import sfs2x.client.entities.managers.IRoomManager;
import sfs2x.client.entities.managers.IUserManager;
import sfs2x.client.entities.managers.SFSUserManager;
import sfs2x.client.entities.variables.RoomVariable;
import sfs2x.client.entities.variables.SFSRoomVariable;

public class SFSRoom implements Room {
    protected String groupId;
    protected int id;
    protected boolean isGame;
    protected boolean isHidden;
    protected boolean isJoined;
    protected boolean isManaged;
    protected boolean isPasswordProtected;
    protected int maxSpectators;
    protected int maxUsers;
    protected String name;
    protected Map properties;
    protected IRoomManager roomManager;
    protected int specCount;
    protected int userCount;
    protected IUserManager userManager;
    protected Map variables;

    public SFSRoom(int i, String str) {
        this(i, str, SFSConstants.DEFAULT_GROUP_ID);
    }

    public SFSRoom(int i, String str, String str2) {
        this.id = i;
        this.name = str;
        this.groupId = str2;
        this.isHidden = false;
        this.isGame = false;
        this.isJoined = false;
        this.isManaged = true;
        this.specCount = 0;
        this.userCount = 0;
        this.variables = new HashMap();
        this.properties = new HashMap();
        this.userManager = new SFSUserManager((ISmartFox) null);
    }

    public static Room fromSFSArray(ISFSArray iSFSArray) {
        boolean z = iSFSArray.size() == 14;
        Room mMORoom = z ? new MMORoom(iSFSArray.getInt(0).intValue(), iSFSArray.getUtfString(1), iSFSArray.getUtfString(2)) : new SFSRoom(iSFSArray.getInt(0).intValue(), iSFSArray.getUtfString(1), iSFSArray.getUtfString(2));
        mMORoom.setGame(iSFSArray.getBool(3).booleanValue());
        mMORoom.setHidden(iSFSArray.getBool(4).booleanValue());
        mMORoom.setPasswordProtected(iSFSArray.getBool(5).booleanValue());
        mMORoom.setUserCount(iSFSArray.getShort(6).shortValue());
        mMORoom.setMaxUsers(iSFSArray.getShort(7).shortValue());
        ISFSArray sFSArray = iSFSArray.getSFSArray(8);
        if (sFSArray.size() > 0) {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < sFSArray.size(); i++) {
                arrayList.add(SFSRoomVariable.fromSFSArray(sFSArray.getSFSArray(i)));
            }
            mMORoom.setVariables(arrayList);
        }
        if (mMORoom.isGame()) {
            mMORoom.setSpectatorCount(iSFSArray.getShort(9).shortValue());
            mMORoom.setMaxSpectators(iSFSArray.getShort(10).shortValue());
        }
        if (z) {
            MMORoom mMORoom2 = (MMORoom) mMORoom;
            mMORoom2.setDefaultAOI(Vec3D.fromArray(iSFSArray.get(11)));
            if (!iSFSArray.isNull(13)) {
                mMORoom2.setLowerMapLimit(Vec3D.fromArray(iSFSArray.get(12)));
                mMORoom2.setHigherMapLimit(Vec3D.fromArray(iSFSArray.get(13)));
            }
        }
        return mMORoom;
    }

    public void addUser(User user) {
        this.userManager.addUser(user);
    }

    public boolean containsUser(User user) {
        return this.userManager.containsUser(user);
    }

    public boolean containsVariable(String str) {
        return this.variables.containsKey(str);
    }

    public int getCapacity() {
        return this.maxUsers + this.maxSpectators;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public int getId() {
        return this.id;
    }

    public int getMaxSpectators() {
        return this.maxSpectators;
    }

    public int getMaxUsers() {
        return this.maxUsers;
    }

    public String getName() {
        return this.name;
    }

    public List getPlayerList() {
        ArrayList arrayList = new ArrayList();
        for (User user : this.userManager.getUserList()) {
            if (user.isPlayerInRoom(this)) {
                arrayList.add(user);
            }
        }
        return arrayList;
    }

    public Map getProperties() {
        return this.properties;
    }

    public IRoomManager getRoomManager() {
        return this.roomManager;
    }

    public int getSpectatorCount() {
        if (!this.isGame) {
            return 0;
        }
        return this.isJoined ? getSpectatorList().size() : this.specCount;
    }

    public List getSpectatorList() {
        ArrayList arrayList = new ArrayList();
        for (User user : this.userManager.getUserList()) {
            if (user.isSpectatorInRoom(this)) {
                arrayList.add(user);
            }
        }
        return arrayList;
    }

    public User getUserById(int i) {
        return this.userManager.getUserById(i);
    }

    public User getUserByName(String str) {
        return this.userManager.getUserByName(str);
    }

    public int getUserCount() {
        return !this.isJoined ? this.userCount : this.isGame ? getPlayerList().size() : this.userManager.getUserCount();
    }

    public List getUserList() {
        return this.userManager.getUserList();
    }

    public RoomVariable getVariable(String str) {
        if (!this.variables.containsKey(str)) {
            return null;
        }
        return (RoomVariable) this.variables.get(str);
    }

    public List getVariables() {
        return new ArrayList(this.variables.values());
    }

    public boolean isGame() {
        return this.isGame;
    }

    public boolean isHidden() {
        return this.isHidden;
    }

    public boolean isJoined() {
        return this.isJoined;
    }

    public boolean isManaged() {
        return this.isManaged;
    }

    public boolean isPasswordProtected() {
        return this.isPasswordProtected;
    }

    public void merge(Room room) {
        this.variables = new HashMap();
        for (RoomVariable roomVariable : room.getVariables()) {
            this.variables.put(roomVariable.getName(), roomVariable);
        }
        this.userManager.clearAll();
        for (User addUser : room.getUserList()) {
            this.userManager.addUser(addUser);
        }
    }

    public void removeUser(User user) {
        this.userManager.removeUser(user);
    }

    public void setGame(boolean z) {
        this.isGame = z;
    }

    public void setHidden(boolean z) {
        this.isHidden = z;
    }

    public void setJoined(boolean z) {
        this.isJoined = z;
    }

    public void setManaged(boolean z) {
        this.isManaged = z;
    }

    public void setMaxSpectators(int i) {
        this.maxSpectators = i;
    }

    public void setMaxUsers(int i) {
        this.maxUsers = i;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setPasswordProtected(boolean z) {
        this.isPasswordProtected = z;
    }

    public void setProperties(Map map) {
        this.properties = map;
    }

    public void setRoomManager(IRoomManager iRoomManager) {
        if (this.roomManager != null) {
            throw new SFSException("Room manager already assigned. Room: " + this);
        }
        this.roomManager = iRoomManager;
    }

    public void setSpectatorCount(int i) {
        this.specCount = i;
    }

    public void setUserCount(int i) {
        this.userCount = i;
    }

    public void setVariable(RoomVariable roomVariable) {
        if (roomVariable.isNull()) {
            this.variables.remove(roomVariable.getName());
        } else {
            this.variables.put(roomVariable.getName(), roomVariable);
        }
    }

    public void setVariables(List list) {
        Iterator it = list.iterator();
        while (it.hasNext()) {
            setVariable((RoomVariable) it.next());
        }
    }

    public String toString() {
        return "[Room: " + this.name + ", Id: " + this.id + ", GroupId: " + this.groupId + "]";
    }
}
