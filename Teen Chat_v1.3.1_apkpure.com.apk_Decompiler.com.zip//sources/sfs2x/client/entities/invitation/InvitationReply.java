package sfs2x.client.entities.invitation;

public class InvitationReply {
    public static final int ACCEPT = 0;
    public static final int REFUSE = 1;
}
