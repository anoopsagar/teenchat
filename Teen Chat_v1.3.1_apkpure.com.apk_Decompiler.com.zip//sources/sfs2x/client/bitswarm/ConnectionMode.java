package sfs2x.client.bitswarm;

public enum ConnectionMode {
    SOCKET,
    HTTP
}
