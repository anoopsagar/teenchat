package sfs2x.client.bitswarm;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import sfs2x.client.util.ByteArray;

public interface IProtocolCodec {
    IOHandler getIOHandler();

    void onPacketRead(ISFSObject iSFSObject);

    void onPacketRead(ByteArray byteArray);

    void onPacketWrite(IMessage iMessage);

    void setIOHandler(IOHandler iOHandler);
}
