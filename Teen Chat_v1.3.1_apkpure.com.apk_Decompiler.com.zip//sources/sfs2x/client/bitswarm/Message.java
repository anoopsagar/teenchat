package sfs2x.client.bitswarm;

import com.smartfoxserver.v2.entities.data.ISFSObject;

public class Message implements IMessage {
    private ISFSObject content;
    private int id;
    private boolean isEncrypted = false;
    private boolean isUDP;
    private long packetId;
    private int targetController;

    public ISFSObject getContent() {
        return this.content;
    }

    public int getId() {
        return this.id;
    }

    public long getPacketId() {
        return this.packetId;
    }

    public int getTargetController() {
        return this.targetController;
    }

    public boolean isEncrypted() {
        return this.isEncrypted;
    }

    public boolean isUDP() {
        return this.isUDP;
    }

    public void setContent(ISFSObject iSFSObject) {
        this.content = iSFSObject;
    }

    public void setEncrypted(boolean z) {
        this.isEncrypted = z;
    }

    public void setId(int i) {
        this.id = i;
    }

    public void setPacketId(long j) {
        this.packetId = j;
    }

    public void setTargetController(int i) {
        this.targetController = i;
    }

    public void setUDP(boolean z) {
        this.isUDP = z;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{ Message id: ").append(this.id).append(" }\n");
        sb.append("{��Dump: }\n");
        sb.append(this.content.getDump());
        return sb.toString();
    }
}
