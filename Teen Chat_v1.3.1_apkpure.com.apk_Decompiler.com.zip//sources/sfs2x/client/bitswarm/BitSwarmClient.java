package sfs2x.client.bitswarm;

import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sfs2x.client.SmartFox;
import sfs2x.client.bitswarm.bbox.BBClient;
import sfs2x.client.bitswarm.bbox.BBEvent;
import sfs2x.client.controllers.ExtensionController;
import sfs2x.client.controllers.SystemController;
import sfs2x.client.core.BaseEvent;
import sfs2x.client.core.EventDispatcher;
import sfs2x.client.core.IDispatchable;
import sfs2x.client.core.IEventListener;
import sfs2x.client.core.sockets.ISocketLayer;
import sfs2x.client.core.sockets.SocketEvent;
import sfs2x.client.core.sockets.TCPSocketLayer;
import sfs2x.client.util.ByteArray;

public class BitSwarmClient implements IDispatchable {
    private boolean attemptingReconnection;
    private BBClient bbClient;
    private boolean bbConnected;
    private int compressionThreshold;
    private ConnectionMode connectionMode;
    private Map controllers;
    private boolean controllersInited;
    private String disconnectionReason;
    private EventDispatcher dispatcher;
    private ExtensionController extController;
    private long firstReconnAttempt;
    private IOHandler ioHandler;
    /* access modifiers changed from: private */
    public String lastIpAddress;
    /* access modifiers changed from: private */
    public int lastTcpPort;
    private Logger log;
    private int maxMessageSize;
    private int reconnCounter;
    private int reconnectionDelayMillis;
    private int reconnectionSeconds;
    private SmartFox sfs;
    /* access modifiers changed from: private */
    public ISocketLayer socket;
    private SystemController sysController;
    private IUDPManager udpManager;
    private boolean useBlueBox;

    public BitSwarmClient() {
        this((SmartFox) null);
    }

    public BitSwarmClient(SmartFox smartFox) {
        this.socket = null;
        this.controllers = new HashMap();
        this.compressionThreshold = 2000000;
        this.maxMessageSize = 10000;
        this.reconnectionDelayMillis = DateUtils.MILLIS_IN_SECOND;
        this.reconnectionSeconds = 0;
        this.controllersInited = false;
        this.useBlueBox = false;
        this.firstReconnAttempt = -1;
        this.reconnCounter = 1;
        this.sfs = smartFox;
        this.log = LoggerFactory.getLogger((Class) getClass());
        this.dispatcher = new EventDispatcher(this);
    }

    private void addController(int i, IController iController) {
        if (iController == null) {
            throw new IllegalArgumentException("Controller is null, it can't be added.");
        } else if (this.controllers.containsKey(Integer.valueOf(i))) {
            throw new IllegalArgumentException("A controller with id: " + i + " already exists! Controller can't be added: " + iController);
        } else {
            this.controllers.put(Integer.valueOf(i), iController);
        }
    }

    private void executeDisconnection() {
        BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.DISCONNECT);
        HashMap hashMap = new HashMap();
        hashMap.put("reason", this.disconnectionReason != null ? this.disconnectionReason : "unknown");
        bitSwarmEvent.setArguments(hashMap);
        dispatchEvent(bitSwarmEvent);
        this.disconnectionReason = null;
    }

    private void initControllers() {
        this.sysController = new SystemController(this);
        this.extController = new ExtensionController(this);
        addController(0, this.sysController);
        addController(1, this.extController);
    }

    /* access modifiers changed from: private */
    public void onBBConnect(BaseEvent baseEvent) {
        this.bbConnected = true;
        HashMap hashMap = new HashMap();
        hashMap.put("success", true);
        hashMap.put("isReconnection", false);
        BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.CONNECT);
        bitSwarmEvent.setArguments(hashMap);
        dispatchEvent(bitSwarmEvent);
    }

    /* access modifiers changed from: private */
    public void onBBData(BaseEvent baseEvent) {
        this.ioHandler.onDataRead((ByteArray) ((BBEvent) baseEvent).getArguments().get("data"));
    }

    /* access modifiers changed from: private */
    public void onBBDisconnect(BaseEvent baseEvent) {
        this.bbConnected = false;
        this.useBlueBox = false;
        if (this.disconnectionReason != null) {
            this.disconnectionReason = null;
        }
        dispatchEvent(new BitSwarmEvent(BitSwarmEvent.DISCONNECT, baseEvent.getArguments()));
    }

    /* access modifiers changed from: private */
    public void onBBError(BaseEvent baseEvent) {
        BBEvent bBEvent = (BBEvent) baseEvent;
        this.log.error("## BlueBox Error: " + ((String) bBEvent.getArguments().get("message")));
        BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.IO_ERROR);
        HashMap hashMap = new HashMap();
        hashMap.put("message", bBEvent.getArguments().get("message"));
        bitSwarmEvent.setArguments(hashMap);
        dispatchEvent(bitSwarmEvent);
    }

    /* access modifiers changed from: private */
    public synchronized void onSocketClose() {
        boolean z = true;
        synchronized (this) {
            if (this.sfs.getReconnectionSeconds() != 0) {
                z = false;
            }
            if (this.disconnectionReason != null || z) {
                this.firstReconnAttempt = -1;
                executeDisconnection();
            } else if (this.attemptingReconnection) {
                reconnect();
            } else {
                this.attemptingReconnection = true;
                this.firstReconnAttempt = System.currentTimeMillis();
                this.reconnCounter = 1;
                dispatchEvent(new BitSwarmEvent(BitSwarmEvent.RECONNECTION_TRY));
                reconnect();
            }
        }
    }

    /* access modifiers changed from: private */
    public void onSocketConnect() {
        BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.CONNECT);
        HashMap hashMap = new HashMap();
        hashMap.put("success", true);
        hashMap.put("isReconnection", Boolean.valueOf(this.attemptingReconnection));
        bitSwarmEvent.setArguments(hashMap);
        dispatchEvent(bitSwarmEvent);
    }

    /* access modifiers changed from: private */
    public void onSocketData(ByteArray byteArray) {
        try {
            this.ioHandler.onDataRead(byteArray);
        } catch (Exception e) {
            this.log.error("## SocketDataError: " + e.getMessage());
            BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.DATA_ERROR);
            HashMap hashMap = new HashMap();
            hashMap.put("message", e.toString());
            bitSwarmEvent.setArguments(hashMap);
            dispatchEvent(bitSwarmEvent);
        }
    }

    /* access modifiers changed from: private */
    public void onSocketError(String str) {
        if (this.attemptingReconnection) {
            reconnect();
            return;
        }
        HashMap hashMap = new HashMap();
        hashMap.put("message", str);
        BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.IO_ERROR);
        bitSwarmEvent.setArguments(hashMap);
        this.disconnectionReason = null;
        dispatchEvent(bitSwarmEvent);
    }

    private void reconnect() {
        if (this.attemptingReconnection) {
            long reconnectionSeconds2 = (((long) (this.sfs.getReconnectionSeconds() * DateUtils.MILLIS_IN_SECOND)) + this.firstReconnAttempt) - System.currentTimeMillis();
            if (reconnectionSeconds2 > 0) {
                this.log.info("Reconnection attempt:" + this.reconnCounter + " - time left:" + (reconnectionSeconds2 / 1000), (Object) " sec.");
                try {
                    Thread.sleep((long) this.reconnectionDelayMillis);
                } catch (InterruptedException e) {
                }
                connect(this.lastIpAddress, this.lastTcpPort);
                this.reconnCounter++;
                return;
            }
            BitSwarmEvent bitSwarmEvent = new BitSwarmEvent(BitSwarmEvent.DISCONNECT);
            HashMap hashMap = new HashMap();
            hashMap.put("reason", "unknown");
            bitSwarmEvent.setArguments(hashMap);
            dispatchEvent(bitSwarmEvent);
        }
    }

    public void addEventListener(String str, IEventListener iEventListener) {
        this.dispatcher.addEventListener(str, iEventListener);
    }

    public void connect() {
        connect("127.0.0.1", 9339);
    }

    public void connect(String str, int i) {
        this.lastIpAddress = str;
        this.lastTcpPort = i;
        if (this.useBlueBox) {
            this.bbClient.setPollSpeed(this.sfs.getConfig() != null ? this.sfs.getConfig().getBboxPollingRate() : 750);
            this.bbClient.connect(str, i);
            this.connectionMode = ConnectionMode.HTTP;
            return;
        }
        this.socket.connect(str, i);
        this.connectionMode = ConnectionMode.SOCKET;
    }

    public void destroy() {
        this.socket.getDispatcher().removeAll();
        if (this.socket.isConnected()) {
            this.socket.disconnect();
        }
        this.socket = null;
    }

    public void disconnect() {
        disconnect((String) null);
    }

    public void disconnect(String str) {
        this.disconnectionReason = str;
        if (this.useBlueBox) {
            this.bbClient.close(str);
            return;
        }
        this.socket.disconnect(str);
        if (this.udpManager != null) {
            this.udpManager.disconnect();
        }
    }

    /* access modifiers changed from: package-private */
    public void dispatchEvent(BitSwarmEvent bitSwarmEvent) {
        this.dispatcher.dispatchEvent(bitSwarmEvent);
    }

    public void enableBlueBoxDebug(boolean z) {
        this.bbClient.setDebug(z);
    }

    public void forceBlueBox(boolean z) {
        if (!this.bbConnected) {
            this.useBlueBox = z;
            return;
        }
        throw new SFSException("You can't change the BlueBox mode while the connection is running");
    }

    public int getCompressionThreshold() {
        return this.compressionThreshold;
    }

    public String getConnectionIp() {
        return !isConnected() ? "Not Connected" : this.lastIpAddress;
    }

    public ConnectionMode getConnectionMode() {
        return this.connectionMode;
    }

    public int getConnectionPort() {
        if (!isConnected()) {
            return -1;
        }
        return this.lastTcpPort;
    }

    public IController getController(int i) {
        return (IController) this.controllers.get(Integer.valueOf(i));
    }

    public EventDispatcher getDispatcher() {
        return this.dispatcher;
    }

    public ExtensionController getExtController() {
        return this.extController;
    }

    public BBClient getHttpClient() {
        return this.bbClient;
    }

    public IOHandler getIoHandler() {
        return this.ioHandler;
    }

    public int getMaxMessageSize() {
        return this.maxMessageSize;
    }

    public long getNextUdpPacketId() {
        return this.udpManager.getNextUdpPacketId();
    }

    public int getReconnectionDelayMillis() {
        return this.reconnectionDelayMillis;
    }

    public int getReconnectionSeconds() {
        if (this.reconnectionSeconds < 0) {
            return 0;
        }
        return this.reconnectionSeconds;
    }

    public SmartFox getSfs() {
        return this.sfs;
    }

    public ISocketLayer getSocket() {
        return this.socket;
    }

    public SystemController getSysController() {
        return this.sysController;
    }

    public IUDPManager getUdpManager() {
        return this.udpManager;
    }

    public boolean getUseBlueBox() {
        return this.useBlueBox;
    }

    public void init() {
        if (!this.controllersInited) {
            initControllers();
            this.controllersInited = true;
        }
        if (this.socket == null) {
            this.socket = new TCPSocketLayer();
            this.socket.addEventListener(SocketEvent.OnConnect, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onSocketConnect();
                }
            });
            this.socket.addEventListener(SocketEvent.OnDisconnect, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onSocketClose();
                }
            });
            this.socket.addEventListener(SocketEvent.OnData, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onSocketData(new ByteArray((byte[]) baseEvent.getArguments().get("data")));
                }
            });
            this.socket.addEventListener(SocketEvent.OnError, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onSocketError((String) baseEvent.getArguments().get("message"));
                }
            });
            this.bbClient = new BBClient(this);
            this.bbClient.addEventListener(BBEvent.CONNECT, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onBBConnect(baseEvent);
                }
            });
            this.bbClient.addEventListener(BBEvent.DATA, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onBBData(baseEvent);
                }
            });
            this.bbClient.addEventListener(BBEvent.DISCONNECT, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onBBDisconnect(baseEvent);
                }
            });
            this.bbClient.addEventListener(BBEvent.IO_ERROR, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onBBError(baseEvent);
                }
            });
            this.bbClient.addEventListener(BBEvent.SECURITY_ERROR, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    BitSwarmClient.this.onBBError(baseEvent);
                }
            });
        }
    }

    public boolean isAttemptingReconnection() {
        return this.attemptingReconnection;
    }

    public boolean isConnected() {
        if (this.useBlueBox) {
            return this.bbConnected;
        }
        if (this.socket == null) {
            return false;
        }
        return this.socket.isConnected();
    }

    public boolean isDebug() {
        return this.sfs == null || this.sfs.isDebug();
    }

    public boolean isReconnecting() {
        return this.attemptingReconnection;
    }

    public void killConnection() {
        if (!this.useBlueBox) {
            this.socket.kill();
        }
    }

    /* access modifiers changed from: package-private */
    public void retryConnection(int i) {
        final Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                BitSwarmClient.this.socket.connect(BitSwarmClient.this.lastIpAddress, BitSwarmClient.this.lastTcpPort);
                timer.cancel();
            }
        }, 100);
    }

    public void send(IMessage iMessage) {
        this.ioHandler.getCodec().onPacketWrite(iMessage);
    }

    public void setAttemptingReconnection(boolean z) {
        this.attemptingReconnection = z;
    }

    public void setCompressionThreshold(int i) {
        if (i > 100) {
            this.compressionThreshold = i;
            return;
        }
        throw new IllegalArgumentException("Compression threshold cannot be < 100 bytes.");
    }

    public void setIoHandler(IOHandler iOHandler) {
        if (this.ioHandler != null) {
            throw new IllegalStateException("IOHandler is already set!");
        }
        this.ioHandler = iOHandler;
    }

    public void setMaxMessageSize(int i) {
        this.maxMessageSize = i;
    }

    public void setReconnecting(boolean z) {
        this.attemptingReconnection = z;
    }

    public void setReconnectionDelayMillis(int i) {
        this.reconnectionDelayMillis = i;
    }

    public void setReconnectionSeconds(int i) {
        this.reconnectionSeconds = i;
    }

    public void setUdpManager(IUDPManager iUDPManager) {
        this.udpManager = iUDPManager;
    }

    public void stopReconnection() {
        this.attemptingReconnection = false;
        this.firstReconnAttempt = -1;
        if (this.socket.isConnected()) {
            this.socket.disconnect();
        }
    }
}
