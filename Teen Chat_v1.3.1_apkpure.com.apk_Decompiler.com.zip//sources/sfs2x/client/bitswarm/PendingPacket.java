package sfs2x.client.bitswarm;

import com.smartfoxserver.v2.protocol.binary.PacketHeader;
import sfs2x.client.util.ByteArray;

public class PendingPacket {
    private ByteArray buffer = new ByteArray();
    private PacketHeader header;

    public PendingPacket(PacketHeader packetHeader) {
        this.header = packetHeader;
        this.buffer.setCompressed(packetHeader.isCompressed());
    }

    public ByteArray getBuffer() {
        return this.buffer;
    }

    public PacketHeader getHeader() {
        return this.header;
    }

    public void setBuffer(ByteArray byteArray) {
        this.buffer = byteArray;
    }
}
