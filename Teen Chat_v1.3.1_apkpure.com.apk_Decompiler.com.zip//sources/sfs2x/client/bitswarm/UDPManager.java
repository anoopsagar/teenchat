package sfs2x.client.bitswarm;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.HashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.jboss.netty.handler.codec.http.HttpConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sfs2x.client.SmartFox;
import sfs2x.client.core.BaseEvent;
import sfs2x.client.core.IEventListener;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.core.sockets.ISocketLayer;
import sfs2x.client.core.sockets.SocketEvent;
import sfs2x.client.core.sockets.UDPSocketLayer;
import sfs2x.client.util.ByteArray;

public class UDPManager implements IUDPManager {
    private final int MAX_RETRY = 3;
    private final int RESPONSE_TIMEOUT = 3000;
    private int currentAttempt = 1;
    private boolean initSuccess = false;
    private ScheduledThreadPoolExecutor initTimer;
    private volatile boolean locked = false;
    /* access modifiers changed from: private */
    public Logger log = LoggerFactory.getLogger((Class) getClass());
    private long packetId = 0;
    private SmartFox sfs;
    private ISocketLayer udpSocket;
    private ScheduledFuture udpTimeout;

    /* access modifiers changed from: private */
    public void onTimeout() {
        if (this.currentAttempt < 3) {
            this.currentAttempt++;
            this.log.debug("UDP Init Attempt: " + this.currentAttempt);
            sendInitializationRequest();
            return;
        }
        stopTimer();
        this.currentAttempt = 0;
        this.locked = false;
        HashMap hashMap = new HashMap();
        hashMap.put("success", false);
        this.sfs.dispatchEvent(new SFSEvent(SFSEvent.UDP_INIT, hashMap));
    }

    /* access modifiers changed from: private */
    public void onUDPData(ByteArray byteArray) {
        if (byteArray.getBytesAvailable() < 4) {
            this.log.warn("Too small UDP packet. Len: " + byteArray.getLength());
            return;
        }
        this.sfs.isDebug();
        boolean z = (byteArray.readByte() & HttpConstants.SP) > 0;
        short readShort = byteArray.readShort();
        if (readShort > byteArray.getBytesAvailable()) {
            this.log.warn("Insufficient UDP data. Expected: " + readShort + ", got: " + byteArray.getBytesAvailable());
            return;
        }
        ByteArray byteArray2 = new ByteArray(byteArray.readBytes(readShort));
        if (z) {
            byteArray2.uncompress();
        }
        SFSObject newFromBinaryData = SFSObject.newFromBinaryData(byteArray2.getBytes());
        if (!newFromBinaryData.containsKey("h")) {
            this.sfs.getSocketEngine().getIoHandler().getCodec().onPacketRead((ISFSObject) newFromBinaryData);
        } else if (!this.initSuccess) {
            stopTimer();
            this.locked = false;
            this.initSuccess = true;
            HashMap hashMap = new HashMap();
            hashMap.put("success", true);
            this.sfs.dispatchEvent(new SFSEvent(SFSEvent.UDP_INIT, hashMap));
        }
    }

    /* access modifiers changed from: private */
    public void onUDPError(String str) {
        this.log.warn("Unexpected UDP I/O Error. " + str);
    }

    private synchronized void startTimer() {
        if (this.initTimer == null) {
            this.initTimer = new ScheduledThreadPoolExecutor(1);
        }
        this.udpTimeout = this.initTimer.schedule(new Runnable() {
            public void run() {
                try {
                    UDPManager.this.onTimeout();
                } catch (SFSException e) {
                    UDPManager.this.log.error(e.toString());
                }
            }
        }, 3000, TimeUnit.MILLISECONDS);
    }

    private synchronized void stopTimer() {
        if (this.udpTimeout != null) {
            this.udpTimeout.cancel(true);
        }
        if (this.initTimer != null) {
            this.initTimer.shutdown();
            this.initTimer = null;
        }
    }

    public void disconnect() {
        this.udpSocket.disconnect();
    }

    public long getNextUdpPacketId() {
        long j = this.packetId;
        this.packetId = 1 + j;
        return j;
    }

    public void initialize(String str, int i) {
        if (this.initSuccess) {
            this.log.warn("UDP Channel already initialized!");
        } else if (!this.locked) {
            this.locked = true;
            this.udpSocket = new UDPSocketLayer();
            this.udpSocket.addEventListener(SocketEvent.OnData, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    UDPManager.this.onUDPData(new ByteArray((byte[]) baseEvent.getArguments().get("data")));
                }
            });
            this.udpSocket.addEventListener(SocketEvent.OnError, new IEventListener() {
                public void dispatch(BaseEvent baseEvent) {
                    UDPManager.this.onUDPError((String) baseEvent.getArguments().get("message"));
                }
            });
            this.udpSocket.connect(str, i);
            sendInitializationRequest();
        } else {
            this.log.warn("UPD initialization is already in progress!");
        }
    }

    public boolean isInited() {
        return this.initSuccess;
    }

    public void reset() {
        stopTimer();
        this.currentAttempt = 1;
        this.initSuccess = false;
        this.locked = false;
        this.packetId = 0;
    }

    public void send(ByteArray byteArray) {
        if (this.initSuccess) {
            try {
                this.udpSocket.write(byteArray.getBytes());
                this.sfs.isDebug();
            } catch (Exception e) {
                this.log.warn("WriteUDP operation failed due to Error: " + e.getMessage());
            }
        } else {
            this.log.warn("UDP protocol is not initialized yet. Pleas use the initUDP() method.");
        }
    }

    /* access modifiers changed from: package-private */
    public void sendInitializationRequest() {
        SFSObject sFSObject = new SFSObject();
        sFSObject.putByte("c", (byte) 1);
        sFSObject.putByte("h", (byte) 1);
        sFSObject.putLong("i", getNextUdpPacketId());
        sFSObject.putInt("u", this.sfs.getMySelf().getId());
        ByteArray byteArray = new ByteArray(sFSObject.toBinary());
        ByteArray byteArray2 = new ByteArray();
        byteArray2.writeByte(Byte.MIN_VALUE);
        byteArray2.writeShort((short) byteArray.getLength());
        byteArray2.writeBytes(byteArray.getBytes());
        this.udpSocket.write(byteArray2.getBytes());
        startTimer();
    }

    public void setSfs(SmartFox smartFox) {
        this.sfs = smartFox;
    }
}
