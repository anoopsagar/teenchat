package sfs2x.client.bitswarm;

import sfs2x.client.util.ByteArray;

public interface IOHandler {
    IProtocolCodec getCodec();

    void onDataRead(ByteArray byteArray);

    void onDataWrite(IMessage iMessage);
}
