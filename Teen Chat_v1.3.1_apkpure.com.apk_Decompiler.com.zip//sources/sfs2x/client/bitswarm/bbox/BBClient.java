package sfs2x.client.bitswarm.bbox;

import android.support.v4.view.accessibility.AccessibilityEventCompat;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.apache.commons.lang.CharEncoding;
import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelFutureListener;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.DefaultChannelPipeline;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.jboss.netty.channel.socket.nio.NioClientSocketChannelFactory;
import org.jboss.netty.handler.codec.http.DefaultHttpRequest;
import org.jboss.netty.handler.codec.http.HttpChunk;
import org.jboss.netty.handler.codec.http.HttpChunkAggregator;
import org.jboss.netty.handler.codec.http.HttpClientCodec;
import org.jboss.netty.handler.codec.http.HttpContentDecompressor;
import org.jboss.netty.handler.codec.http.HttpHeaders;
import org.jboss.netty.handler.codec.http.HttpMethod;
import org.jboss.netty.handler.codec.http.HttpRequest;
import org.jboss.netty.handler.codec.http.HttpResponse;
import org.jboss.netty.handler.codec.http.HttpVersion;
import org.jboss.netty.util.CharsetUtil;
import sfs2x.client.bitswarm.BitSwarmClient;
import sfs2x.client.bitswarm.BitSwarmEvent;
import sfs2x.client.core.BaseEvent;
import sfs2x.client.core.EventDispatcher;
import sfs2x.client.core.IDispatchable;
import sfs2x.client.core.IEventListener;
import sfs2x.client.core.sockets.NettyTerminator;
import sfs2x.client.util.Base64;
import sfs2x.client.util.ByteArray;

public class BBClient implements IDispatchable {
    private final String BB_DEFAULT_HOST;
    private final int BB_DEFAULT_PORT;
    private final String BB_NULL;
    private final String BB_SERVLET;
    private final String CMD_CONNECT;
    private final String CMD_DATA;
    private final String CMD_POLL;
    private final int DEFAULT_POLL_SPEED;
    private final String ERR_INVALID_SESSION;
    private final int MAX_POLL_SPEED;
    private final int MIN_POLL_SPEED;
    private final int POLLING_TIMEOUT;
    private final String SEP;
    private final String SFS_HTTP;
    private String bbUrl;
    /* access modifiers changed from: private */
    public BitSwarmClient bitswarm;
    /* access modifiers changed from: private */
    public ClientBootstrap bootstrap;
    /* access modifiers changed from: private */
    public Channel channel;
    private boolean debug;
    private EventDispatcher dispatcher;
    /* access modifiers changed from: private */
    public String host;
    private boolean isConnected;
    /* access modifiers changed from: private */
    public long lastPollingTime;
    private final Runnable pollRunner;
    /* access modifiers changed from: private */
    public final ScheduledExecutorService pollScheduler;
    private int pollSpeed;
    /* access modifiers changed from: private */
    public int port;
    private String sessId;
    URI uri;

    final class BBChannelFutureListener implements ChannelFutureListener {
        private final HttpRequest request;

        public BBChannelFutureListener(HttpRequest httpRequest) {
            this.request = httpRequest;
        }

        public void operationComplete(ChannelFuture channelFuture) {
            BBClient.this.channel = channelFuture.getChannel();
            BBClient.this.channel.write(this.request);
        }
    }

    class HttpClientPipelineFactory implements ChannelPipelineFactory {
        private final boolean ssl;

        public HttpClientPipelineFactory(boolean z) {
            this.ssl = z;
        }

        public ChannelPipeline getPipeline() {
            DefaultChannelPipeline defaultChannelPipeline = new DefaultChannelPipeline();
            defaultChannelPipeline.addLast("codec", new HttpClientCodec());
            defaultChannelPipeline.addLast("inflater", new HttpContentDecompressor());
            defaultChannelPipeline.addLast("aggregator", new HttpChunkAggregator(AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START));
            defaultChannelPipeline.addLast("handler", new HttpResponseHandler(BBClient.this, (HttpResponseHandler) null));
            return defaultChannelPipeline;
        }
    }

    class HttpResponseHandler extends SimpleChannelUpstreamHandler {
        private boolean readingChunks;

        private HttpResponseHandler() {
        }

        /* synthetic */ HttpResponseHandler(BBClient bBClient, HttpResponseHandler httpResponseHandler) {
            this();
        }

        public void exceptionCaught(ChannelHandlerContext channelHandlerContext, ExceptionEvent exceptionEvent) {
            if (!(exceptionEvent.getCause() instanceof ConnectException)) {
                return;
            }
            if (BBClient.this.bitswarm == null || BBClient.this.bitswarm.getSfs().isConnecting()) {
                BBClient.this.onHttpError(exceptionEvent.getCause(), true);
            } else {
                BBClient.this.onHttpError(exceptionEvent.getCause(), false);
            }
        }

        public void messageReceived(ChannelHandlerContext channelHandlerContext, MessageEvent messageEvent) {
            if (!this.readingChunks) {
                HttpResponse httpResponse = (HttpResponse) messageEvent.getMessage();
                if (httpResponse.getStatus().getCode() != 200 || !httpResponse.isChunked()) {
                    BBClient.this.onHttpResponse(httpResponse.getContent().toString(CharsetUtil.UTF_8));
                    return;
                }
                this.readingChunks = true;
            } else if (((HttpChunk) messageEvent.getMessage()).isLast()) {
                this.readingChunks = false;
            }
        }
    }

    final class PollRunner implements Runnable {
        private PollRunner() {
        }

        /* synthetic */ PollRunner(BBClient bBClient, PollRunner pollRunner) {
            this();
        }

        public void run() {
            BBClient.this.poll();
        }
    }

    final class PollTimeOutMonitor implements Runnable {
        public PollTimeOutMonitor() {
            BBClient.this.lastPollingTime = System.currentTimeMillis();
        }

        public void run() {
            if (System.currentTimeMillis() > BBClient.this.lastPollingTime + 45000) {
                HashMap hashMap = new HashMap();
                hashMap.put("reason", "unknown");
                BBClient.this.dispatchEvent(new BBEvent(BBEvent.DISCONNECT, hashMap));
                BBClient.this.pollScheduler.shutdownNow();
            }
        }
    }

    public BBClient() {
        this.BB_DEFAULT_HOST = "localhost";
        this.BB_DEFAULT_PORT = 8080;
        this.BB_SERVLET = "BlueBox/BlueBox.do";
        this.BB_NULL = "null";
        this.CMD_CONNECT = BitSwarmEvent.CONNECT;
        this.CMD_POLL = "poll";
        this.CMD_DATA = "data";
        this.ERR_INVALID_SESSION = "err01";
        this.SFS_HTTP = "sfsHttp";
        this.SEP = "|";
        this.MIN_POLL_SPEED = 50;
        this.MAX_POLL_SPEED = 5000;
        this.DEFAULT_POLL_SPEED = 300;
        this.POLLING_TIMEOUT = 45000;
        this.isConnected = false;
        this.host = "localhost";
        this.port = 8080;
        this.sessId = null;
        this.pollSpeed = 300;
        this.lastPollingTime = 0;
        this.pollScheduler = new ScheduledThreadPoolExecutor(3);
        this.pollRunner = new PollRunner(this, (PollRunner) null);
    }

    public BBClient(String str, int i, BitSwarmClient bitSwarmClient) {
        this();
        init(bitSwarmClient, str, i, false);
    }

    public BBClient(String str, int i, boolean z, BitSwarmClient bitSwarmClient) {
        this();
        init(bitSwarmClient, str, i, z);
    }

    public BBClient(String str, BitSwarmClient bitSwarmClient) {
        this();
        init(bitSwarmClient, str, 8080, false);
    }

    public BBClient(BitSwarmClient bitSwarmClient) {
        this();
        init(bitSwarmClient, "localhost", 8080, false);
    }

    /* access modifiers changed from: private */
    public HttpRequest createRequest(String str, Object obj) {
        String encodeRequest = encodeRequest(str, obj);
        DefaultHttpRequest defaultHttpRequest = new DefaultHttpRequest(HttpVersion.HTTP_1_0, HttpMethod.POST, this.uri.toASCIIString());
        defaultHttpRequest.setHeader("Host", (Object) this.host);
        defaultHttpRequest.setHeader("Connection", (Object) "close");
        defaultHttpRequest.setHeader("Content-Type", (Object) HttpHeaders.Values.APPLICATION_X_WWW_FORM_URLENCODED);
        defaultHttpRequest.setHeader("Accept-Encoding", (Object) "gzip");
        String str2 = "sfsHttp=" + encodeRequest;
        byte[] bArr = new byte[0];
        try {
            bArr = str2.getBytes(CharEncoding.UTF_8);
        } catch (UnsupportedEncodingException e) {
            System.out.println("Unsupported encoding: " + e.getLocalizedMessage());
        }
        defaultHttpRequest.setContent(ChannelBuffers.copiedBuffer(bArr));
        defaultHttpRequest.setHeader("Content-Length", (Object) Integer.valueOf(bArr.length));
        return defaultHttpRequest;
    }

    private ByteArray decodeResponse(String str) {
        return new ByteArray(fromBase64String(str));
    }

    /* access modifiers changed from: private */
    public void dispatchEvent(BaseEvent baseEvent) {
        this.dispatcher.dispatchEvent(baseEvent);
    }

    private String encodeRequest(String str, Object obj) {
        if (str == null) {
            str = "null";
        }
        if (obj == null) {
            obj = "null";
        } else if (obj instanceof ByteArray) {
            obj = toBase64String(((ByteArray) obj).getBytes());
        }
        try {
            return URLEncoder.encode(String.valueOf("") + (this.sessId == null ? "null" : this.sessId) + String.valueOf("|") + str + String.valueOf("|") + obj, CharEncoding.UTF_8);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("Unable to encode BlueBox Message. Missing UTF-8 support!");
        }
    }

    private byte[] fromBase64String(String str) {
        return Base64.decode(str);
    }

    private void handleConnectionLost(boolean z) {
        handleConnectionLost(z, (String) null);
    }

    private void handleConnectionLost(boolean z, String str) {
        try {
            if (this.isConnected) {
                this.isConnected = false;
                this.sessId = null;
                this.pollScheduler.shutdownNow();
                this.channel.close();
                this.channel = null;
                if (z) {
                    HashMap hashMap = new HashMap();
                    hashMap.put("reason", str);
                    dispatchEvent(new BBEvent(BBEvent.DISCONNECT, hashMap));
                }
            }
        } finally {
            new NettyTerminator(this.bootstrap);
        }
    }

    private void init(BitSwarmClient bitSwarmClient, String str, int i, boolean z) {
        this.bitswarm = bitSwarmClient;
        this.host = str;
        this.port = i;
        setDebug(z);
        if (this.dispatcher == null) {
            this.dispatcher = new EventDispatcher(this);
        }
    }

    /* access modifiers changed from: private */
    public void onHttpError(Throwable th, boolean z) {
        handleConnectionLost(z);
        HashMap hashMap = new HashMap();
        hashMap.put("message", th.getMessage());
        dispatchEvent(new BBEvent(BBEvent.IO_ERROR, hashMap));
    }

    /* access modifiers changed from: private */
    public void onHttpResponse(String str) {
        try {
            if (isDebug()) {
                System.out.println("[ BB-Receive ]: " + str);
            }
            String[] split = str.split("\\|");
            if (split.length >= 2) {
                String str2 = split[0];
                String str3 = split[1];
                if (str2.equals(BitSwarmEvent.CONNECT)) {
                    this.sessId = str3;
                    this.isConnected = true;
                    dispatchEvent(new BBEvent(BBEvent.CONNECT));
                    this.pollScheduler.scheduleAtFixedRate(new PollTimeOutMonitor(), 0, 45000, TimeUnit.MILLISECONDS);
                    pollNext();
                } else if (str2.equals("poll")) {
                    ByteArray byteArray = null;
                    if (!str3.equals("null")) {
                        byteArray = decodeResponse(str3);
                    }
                    pollNext();
                    if (byteArray != null) {
                        HashMap hashMap = new HashMap();
                        hashMap.put("data", byteArray);
                        dispatchEvent(new BBEvent(BBEvent.DATA, hashMap));
                    }
                } else if (str2.equals("err01")) {
                    onHttpError(new Exception("Invalid BB session !"), false);
                }
            }
        } catch (Exception e) {
            onHttpError(e, false);
        }
    }

    /* access modifiers changed from: private */
    public void poll() {
        if (this.isConnected) {
            this.lastPollingTime = System.currentTimeMillis();
            sendRequest("poll");
        }
    }

    private void pollNext() {
        if (this.isConnected) {
            this.pollScheduler.schedule(this.pollRunner, (long) getPollSpeed(), TimeUnit.MILLISECONDS);
        }
    }

    private void sendRequest(String str) {
        sendRequest(str, (Object) null);
    }

    private void sendRequest(final String str, final Object obj) {
        this.pollScheduler.submit(new Runnable() {
            public void run() {
                BBClient.this.bootstrap.connect(new InetSocketAddress(BBClient.this.host, BBClient.this.port)).addListener(new BBChannelFutureListener(BBClient.this.createRequest(str, obj)));
            }
        });
    }

    private String toBase64String(byte[] bArr) {
        return Base64.encodeBytes(bArr);
    }

    public void addEventListener(String str, IEventListener iEventListener) {
        this.dispatcher.addEventListener(str, iEventListener);
    }

    public void close(String str) {
        handleConnectionLost(true, str);
    }

    public void connect() {
        connect("127.0.0.1", 8080);
    }

    public void connect(String str) {
        connect(str, 8080);
    }

    public void connect(String str, int i) {
        if (this.isConnected) {
            System.out.println("BB is already connected!");
            return;
        }
        this.host = str;
        this.port = i;
        this.bbUrl = "http://" + str + ":" + i + "/" + "BlueBox/BlueBox.do";
        try {
            this.uri = new URI(this.bbUrl);
            this.bootstrap = new ClientBootstrap(new NioClientSocketChannelFactory(Executors.newCachedThreadPool(), Executors.newCachedThreadPool()));
            this.bootstrap.setPipelineFactory(new HttpClientPipelineFactory((this.uri.getScheme() == null ? "http" : this.uri.getScheme()).equalsIgnoreCase("https")));
            sendRequest(BitSwarmEvent.CONNECT);
        } catch (URISyntaxException e) {
            System.out.println("Wrong uri: " + this.bbUrl);
        }
    }

    public EventDispatcher getDispatcher() {
        return this.dispatcher;
    }

    public String getHost() {
        return this.host;
    }

    public int getPollSpeed() {
        return this.pollSpeed;
    }

    public int getPort() {
        return this.port;
    }

    public String getSessionId() {
        return this.sessId;
    }

    public boolean isConnected() {
        return this.sessId != null;
    }

    public boolean isDebug() {
        return this.debug;
    }

    public void send(ByteArray byteArray) {
        if (!this.isConnected) {
            System.out.println("BB sending error: can't send data, BlueBox connection is not active");
        }
        try {
            sendRequest("data", byteArray);
        } catch (Exception e) {
            System.out.println("BB sending error: " + e.getMessage());
        }
    }

    public void setDebug(boolean z) {
        this.debug = z;
    }

    public void setPollSpeed(int i) {
        if (i < 50 || i > 5000) {
            i = 300;
        }
        this.pollSpeed = i;
    }
}
