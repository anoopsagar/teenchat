package sfs2x.client.bitswarm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseController implements IController {
    protected short id = -1;
    protected final Logger log = LoggerFactory.getLogger((Class) getClass());

    public short getId() {
        return this.id;
    }

    public void handleMessage(IMessage iMessage) {
        this.log.info("System controller got request: " + iMessage);
    }

    public void setId(short s) {
        if (this.id == -1) {
            this.id = s;
            return;
        }
        throw new IllegalStateException("Controller ID is already set: " + this.id + ". Can't be changed at runtime!");
    }
}
