package sfs2x.client.requests;

import sfs2x.client.ISmartFox;
import sfs2x.client.bitswarm.IMessage;

public interface IRequest {
    void execute(ISmartFox iSmartFox);

    IMessage getMessage();

    int getTargetController();

    boolean isEncrypted();

    void setEncrypted(boolean z);

    void setTargetController(int i);

    void validate(ISmartFox iSmartFox);
}
