package sfs2x.client.requests;

public class BanMode {
    public static final int BY_ADDRESS = 0;
    public static final int BY_NAME = 1;
}
