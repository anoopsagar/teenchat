package sfs2x.client.requests.game;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import java.util.ArrayList;
import java.util.List;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.Buddy;
import sfs2x.client.entities.User;
import sfs2x.client.exceptions.SFSValidationException;
import sfs2x.client.requests.BaseRequest;

public class InviteUsersRequest extends BaseRequest {
    public static final String KEY_INVITATION_ID = "ii";
    public static final String KEY_INVITED_USERS = "iu";
    public static final String KEY_INVITEE_ID = "ee";
    public static final String KEY_PARAMS = "p";
    public static final String KEY_REPLY_ID = "ri";
    public static final String KEY_TIME = "t";
    public static final String KEY_USER = "u";
    public static final String KEY_USER_ID = "ui";
    public static final int MAX_EXPIRY_TIME = 300;
    public static final int MAX_INVITATIONS_FROM_CLIENT_SIDE = 8;
    public static final int MIN_EXPIRY_TIME = 5;
    private List invitedUsers;
    private ISFSObject params;
    private int secondsForAnswer;

    public InviteUsersRequest(List list, int i, ISFSObject iSFSObject) {
        super(300);
        this.invitedUsers = list;
        this.secondsForAnswer = i;
        this.params = iSFSObject;
    }

    public void execute(ISmartFox iSmartFox) {
        ArrayList arrayList = new ArrayList();
        for (Object next : this.invitedUsers) {
            if ((next instanceof User) || (next instanceof Buddy)) {
                int id = next instanceof User ? ((User) next).getId() : ((Buddy) next).getId();
                if (id != iSmartFox.getMySelf().getId()) {
                    arrayList.add(Integer.valueOf(id));
                }
            }
        }
        this.sfso.putIntArray(KEY_INVITED_USERS, arrayList);
        this.sfso.putShort("t", (short) this.secondsForAnswer);
        if (this.params != null) {
            this.sfso.putSFSObject("p", this.params);
        }
    }

    public void validate(ISmartFox iSmartFox) {
        ArrayList arrayList = new ArrayList();
        if (this.invitedUsers == null || this.invitedUsers.isEmpty()) {
            arrayList.add("No invitation(s) to send");
        }
        if (this.invitedUsers.size() > 8) {
            arrayList.add("Too many invitations. Max allowed from client side is: 8");
        }
        if (this.secondsForAnswer < 5 || this.secondsForAnswer > 300) {
            arrayList.add("SecondsForAnswer value is out of range (5-300)");
        }
        if (!arrayList.isEmpty()) {
            throw new SFSValidationException("InvitationReply request error", arrayList);
        }
    }
}
