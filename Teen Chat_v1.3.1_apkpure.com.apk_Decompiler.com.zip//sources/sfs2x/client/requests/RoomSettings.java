package sfs2x.client.requests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import sfs2x.client.entities.SFSConstants;

public class RoomSettings {
    private RoomEvents events;
    private RoomExtension extension;
    private String groupId = SFSConstants.DEFAULT_GROUP_ID;
    private boolean isGame = false;
    private int maxSpectators = 0;
    private int maxUsers = 10;
    private int maxVariables = 5;
    private String name;
    private String password = "";
    private RoomPermissions permissions;
    private List variables = new ArrayList();

    public RoomSettings(String str) {
        this.name = str;
    }

    public RoomEvents getEvents() {
        return this.events;
    }

    public RoomExtension getExtension() {
        return this.extension;
    }

    public String getGroupId() {
        return this.groupId;
    }

    public int getMaxSpectators() {
        return this.maxSpectators;
    }

    public int getMaxUsers() {
        return this.maxUsers;
    }

    public int getMaxVariables() {
        return this.maxVariables;
    }

    public String getName() {
        return this.name;
    }

    public String getPassword() {
        return this.password;
    }

    public RoomPermissions getPermissions() {
        return this.permissions;
    }

    public List getVariables() {
        return this.variables;
    }

    public boolean isGame() {
        return this.isGame;
    }

    public void setEvents(RoomEvents roomEvents) {
        this.events = roomEvents;
    }

    public void setExtension(RoomExtension roomExtension) {
        this.extension = roomExtension;
    }

    public void setGame(boolean z) {
        this.isGame = z;
    }

    public void setGroupId(String str) {
        this.groupId = str;
    }

    public void setMaxSpectators(int i) {
        this.maxSpectators = i;
    }

    public void setMaxUsers(int i) {
        this.maxUsers = i;
    }

    public void setMaxVariables(int i) {
        this.maxVariables = i;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setPassword(String str) {
        this.password = str;
    }

    public void setPermissions(RoomPermissions roomPermissions) {
        this.permissions = roomPermissions;
    }

    public void setVariables(List list) {
        this.variables = Collections.unmodifiableList(new ArrayList(list));
    }
}
