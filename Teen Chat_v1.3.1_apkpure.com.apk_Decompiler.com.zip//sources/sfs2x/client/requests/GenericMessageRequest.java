package sfs2x.client.requests;

import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.exceptions.SFSException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.User;
import sfs2x.client.exceptions.SFSValidationException;
import sfs2x.client.util.SFSStringUtils;

public class GenericMessageRequest extends BaseRequest {
    public static final String KEY_MESSAGE = "m";
    public static final String KEY_MESSAGE_TYPE = "t";
    public static final String KEY_RECIPIENT = "rc";
    public static final String KEY_RECIPIENT_MODE = "rm";
    public static final String KEY_ROOM_ID = "r";
    public static final String KEY_SENDER_DATA = "sd";
    public static final String KEY_USER_ID = "u";
    public static final String KEY_XTRA_PARAMS = "p";
    protected Logger log = LoggerFactory.getLogger((Class) getClass());
    protected String message;
    protected ISFSObject params;
    protected Object recipient;
    protected Room room;
    protected int sendMode = -1;
    protected int type = -1;
    protected User user;

    public GenericMessageRequest() {
        super(7);
    }

    private void executeBuddyMessage(ISmartFox iSmartFox) {
        this.sfso.putInt(KEY_RECIPIENT, ((Integer) this.recipient).intValue());
        this.sfso.putUtfString("m", this.message);
        if (this.params != null) {
            this.sfso.putSFSObject("p", this.params);
        }
    }

    private void executeObjectMessage(ISmartFox iSmartFox) {
        if (this.room == null) {
            this.room = iSmartFox.getLastJoinedRoom();
        }
        HashSet hashSet = new HashSet();
        if (this.recipient instanceof Collection) {
            Collection collection = (Collection) this.recipient;
            if (collection.size() > this.room.getCapacity()) {
                throw new IllegalArgumentException("The number of recipients is bigger than the target Room capacity: " + collection.size());
            }
            for (Object next : collection) {
                if (next instanceof User) {
                    hashSet.add(Integer.valueOf(((User) next).getId()));
                } else {
                    this.log.warn("Bad recipient in ObjectMessage recipient list: " + next.getClass().getName() + ", expected type: User");
                }
            }
        }
        this.sfso.putInt("r", this.room.getId());
        this.sfso.putSFSObject("p", this.params);
        if (!hashSet.isEmpty()) {
            this.sfso.putIntArray(KEY_RECIPIENT, hashSet);
        }
    }

    private void executePrivateMessage(ISmartFox iSmartFox) {
        this.sfso.putInt(KEY_RECIPIENT, ((Integer) this.recipient).intValue());
        this.sfso.putUtfString("m", this.message);
        if (this.params != null) {
            this.sfso.putSFSObject("p", this.params);
        }
    }

    private void executePublicMessage(ISmartFox iSmartFox) {
        if (this.room == null) {
            this.room = iSmartFox.getLastJoinedRoom();
        }
        if (this.room == null) {
            throw new SFSException("User should be joined in a room in order to send a public message");
        }
        this.sfso.putInt("r", this.room.getId());
        this.sfso.putInt("u", iSmartFox.getMySelf().getId());
        this.sfso.putUtfString("m", this.message);
        if (this.params != null) {
            this.sfso.putSFSObject("p", this.params);
        }
    }

    private void executeSuperUserMessage(ISmartFox iSmartFox) {
        this.sfso.putUtfString("m", this.message);
        if (this.params != null) {
            this.sfso.putSFSObject("p", this.params);
        }
        this.sfso.putInt(KEY_RECIPIENT_MODE, this.sendMode);
        switch (this.sendMode) {
            case 0:
                this.sfso.putInt(KEY_RECIPIENT, ((User) this.recipient).getId());
                return;
            case 1:
                this.sfso.putInt(KEY_RECIPIENT, ((Room) this.recipient).getId());
                return;
            case 2:
                this.sfso.putUtfString(KEY_RECIPIENT, (String) this.recipient);
                return;
            default:
                return;
        }
    }

    private void validateBuddyMessage(ISmartFox iSmartFox, List list) {
        if (!iSmartFox.getBuddyManager().isInited()) {
            list.add("BuddyList is not inited. Please send an InitBuddyRequest first.");
        }
        if (!iSmartFox.getBuddyManager().getMyOnlineState()) {
            list.add("Can't send messages while off-line");
        }
        if (SFSStringUtils.isEmptyOrNull(this.message)) {
            list.add("Buddy message is empty!");
        }
        if (((Integer) this.recipient).intValue() < 0) {
            list.add("Recipient is not online or not in your buddy list");
        }
    }

    private void validateObjectMessage(ISmartFox iSmartFox, List list) {
        if (this.params == null) {
            list.add("Object message is null!");
        }
    }

    private void validatePrivateMessage(ISmartFox iSmartFox, List list) {
        if (SFSStringUtils.isEmptyOrNull(this.message)) {
            list.add("Private message is empty!");
        }
        if (((Integer) this.recipient).intValue() < 0) {
            list.add("Invalid recipient id: " + this.recipient);
        }
    }

    private void validatePublicMessage(ISmartFox iSmartFox, List list) {
        if (SFSStringUtils.isEmptyOrNull(this.message)) {
            list.add("Public message is empty!");
        }
        if (this.room != null && !iSmartFox.getJoinedRooms().contains(this.room)) {
            list.add("You are not joined in the target Room: " + this.room);
        }
    }

    private void validateSuperUserMessage(ISmartFox iSmartFox, List list) {
        if (SFSStringUtils.isEmptyOrNull(this.message)) {
            list.add("Moderator message is empty!");
        }
        switch (this.sendMode) {
            case 0:
                if (!(this.recipient instanceof User)) {
                    list.add("TO_USER expects a User object as recipient");
                    return;
                }
                return;
            case 1:
                if (!(this.recipient instanceof Room)) {
                    list.add("TO_ROOM expects a Room object as recipient");
                    return;
                }
                return;
            case 2:
                if (!(this.recipient instanceof String)) {
                    list.add("TO_GROUP expects a String object (the groupId) as recipient");
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void execute(ISmartFox iSmartFox) {
        this.sfso.putByte("t", (byte) this.type);
        switch (this.type) {
            case 0:
                executePublicMessage(iSmartFox);
                return;
            case 1:
                executePrivateMessage(iSmartFox);
                return;
            case 4:
                executeObjectMessage(iSmartFox);
                return;
            case 5:
                executeBuddyMessage(iSmartFox);
                return;
            default:
                executeSuperUserMessage(iSmartFox);
                return;
        }
    }

    public void validate(ISmartFox iSmartFox) {
        if (this.type < 0) {
            throw new SFSValidationException("PublicMessage request error", Collections.singletonList("Unsupported message type: " + this.type));
        }
        ArrayList arrayList = new ArrayList();
        switch (this.type) {
            case 0:
                validatePublicMessage(iSmartFox, arrayList);
                break;
            case 1:
                validatePrivateMessage(iSmartFox, arrayList);
                break;
            case 4:
                validateObjectMessage(iSmartFox, arrayList);
                break;
            case 5:
                validateBuddyMessage(iSmartFox, arrayList);
                break;
            default:
                validateSuperUserMessage(iSmartFox, arrayList);
                break;
        }
        if (!arrayList.isEmpty()) {
            throw new SFSValidationException("Request error - ", arrayList);
        }
    }
}
