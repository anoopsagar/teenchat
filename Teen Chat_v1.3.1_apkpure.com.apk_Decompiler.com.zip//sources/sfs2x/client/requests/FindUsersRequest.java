package sfs2x.client.requests;

import java.util.ArrayList;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.match.MatchExpression;
import sfs2x.client.exceptions.SFSValidationException;

public class FindUsersRequest extends BaseRequest {
    public static final String KEY_EXPRESSION = "e";
    public static final String KEY_FILTERED_USERS = "fu";
    public static final String KEY_GROUP = "g";
    public static final String KEY_LIMIT = "l";
    public static final String KEY_ROOM = "r";
    private short limit;
    private MatchExpression matchExpr;
    private Object target;

    public FindUsersRequest(MatchExpression matchExpression) {
        this(matchExpression, (Object) null, 0);
    }

    public FindUsersRequest(MatchExpression matchExpression, Object obj) {
        this(matchExpression, obj, 0);
    }

    public FindUsersRequest(MatchExpression matchExpression, Object obj, short s) {
        super(28);
        this.limit = s;
        this.target = obj;
        this.matchExpr = matchExpression;
    }

    public void execute(ISmartFox iSmartFox) {
        this.sfso.putSFSArray("e", this.matchExpr.toSFSArray());
        if (this.target != null) {
            if (this.target instanceof Room) {
                this.sfso.putInt("r", ((Room) this.target).getId());
            } else if (this.target instanceof String) {
                this.sfso.putUtfString("g", (String) this.target);
            }
        }
        if (this.limit > 0) {
            this.sfso.putShort("l", this.limit);
        }
    }

    public void validate(ISmartFox iSmartFox) {
        ArrayList arrayList = new ArrayList();
        if (this.matchExpr == null) {
            arrayList.add("Missing Match Expression");
        }
        if (arrayList.size() > 0) {
            throw new SFSValidationException("FindUsers request error", arrayList);
        }
    }
}
