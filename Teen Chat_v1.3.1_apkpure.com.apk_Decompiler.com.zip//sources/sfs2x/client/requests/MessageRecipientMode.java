package sfs2x.client.requests;

public class MessageRecipientMode {
    public static final int TO_GROUP = 2;
    public static final int TO_ROOM = 1;
    public static final int TO_USER = 0;
    public static final int TO_ZONE = 3;
    private int mode;
    private Object target;

    public MessageRecipientMode(int i, Object obj) {
        if (i < 0 || i > 3) {
            throw new IllegalArgumentException("Illegal recipient mode: " + i);
        }
        this.mode = i;
        this.target = obj;
    }

    public int getMode() {
        return this.mode;
    }

    public Object getTarget() {
        return this.target;
    }
}
