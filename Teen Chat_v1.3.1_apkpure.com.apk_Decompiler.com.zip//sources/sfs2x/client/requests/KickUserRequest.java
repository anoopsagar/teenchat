package sfs2x.client.requests;

import java.util.ArrayList;
import sfs2x.client.ISmartFox;
import sfs2x.client.exceptions.SFSValidationException;

public class KickUserRequest extends BaseRequest {
    public static final String KEY_DELAY = "d";
    public static final String KEY_MESSAGE = "m";
    public static final String KEY_USER_ID = "u";
    private int delay;
    private String message;
    private int userId;

    public KickUserRequest(int i) {
        this(i, (String) null, 5);
    }

    public KickUserRequest(int i, String str) {
        this(i, str, 5);
    }

    public KickUserRequest(int i, String str, int i2) {
        super(24);
        this.userId = i;
        this.message = str;
        this.delay = i2;
        if (this.delay < 0) {
            this.delay = 0;
        }
    }

    public void execute(ISmartFox iSmartFox) {
        this.sfso.putInt("u", this.userId);
        this.sfso.putInt("d", this.delay);
        if (this.message != null && this.message.length() > 0) {
            this.sfso.putUtfString("m", this.message);
        }
    }

    public void validate(ISmartFox iSmartFox) {
        ArrayList arrayList = new ArrayList();
        if (!iSmartFox.getMySelf().isModerator() && !iSmartFox.getMySelf().isAdmin()) {
            arrayList.add("You don't have enough permissions to execute this request.");
        }
        if (!arrayList.isEmpty()) {
            throw new SFSValidationException("KickUser request error", arrayList);
        }
    }
}
