package sfs2x.client.requests;

import sfs2x.client.ISmartFox;

public class PingPongRequest extends BaseRequest {
    public PingPongRequest() {
        super(29);
    }

    public void execute(ISmartFox iSmartFox) {
    }

    public void validate(ISmartFox iSmartFox) {
    }
}
