package sfs2x.client.requests.mmo;

public class SetMMOItemVariables {
    public static final String KEY_ITEM_ID = "i";
    public static final String KEY_ROOM_ID = "r";
    public static final String KEY_VAR_LIST = "v";
}
