package sfs2x.client.requests;

import com.smartfoxserver.v2.entities.data.SFSArray;
import java.util.ArrayList;
import java.util.List;
import sfs2x.client.ISmartFox;
import sfs2x.client.entities.Room;
import sfs2x.client.entities.variables.RoomVariable;
import sfs2x.client.exceptions.SFSValidationException;

public class SetRoomVariablesRequest extends BaseRequest {
    public static final String KEY_VAR_LIST = "vl";
    public static final String KEY_VAR_ROOM = "r";
    private Room room;
    private List roomVariables;

    public SetRoomVariablesRequest(List list) {
        this(list, (Room) null);
    }

    public SetRoomVariablesRequest(List list, Room room2) {
        super(11);
        this.roomVariables = list;
        this.room = room2;
    }

    public void execute(ISmartFox iSmartFox) {
        SFSArray newInstance = SFSArray.newInstance();
        for (RoomVariable sFSArray : this.roomVariables) {
            newInstance.addSFSArray(sFSArray.toSFSArray());
        }
        if (this.room == null) {
            this.room = iSmartFox.getLastJoinedRoom();
        }
        this.sfso.putSFSArray("vl", newInstance);
        this.sfso.putInt("r", this.room.getId());
    }

    public void validate(ISmartFox iSmartFox) {
        ArrayList arrayList = new ArrayList();
        if (this.room != null) {
            if (!this.room.containsUser(iSmartFox.getMySelf())) {
                arrayList.add("You are not joined in the target room");
            }
        } else if (iSmartFox.getLastJoinedRoom() == null) {
            arrayList.add("You are not joined in any rooms");
        }
        if (this.roomVariables == null || this.roomVariables.isEmpty()) {
            arrayList.add("No variables were specified");
        }
        if (!arrayList.isEmpty()) {
            throw new SFSValidationException("SetRoomVariables request error", arrayList);
        }
    }
}
