package sfs2x.client.util;

public class ConfigData {
    private String bboxHost;
    private int bboxPollingRate = 700;
    private int bboxPort = 8080;
    private boolean debug = false;
    private String host = "127.0.0.1";
    private int httpPort = 8080;
    private int port = 9933;
    private String udpHost = "127.0.0.1";
    private int udpPort = 9933;
    private boolean useBBox = true;
    private String zone;

    public String getBboxHost() {
        return this.bboxHost;
    }

    public int getBboxPollingRate() {
        return this.bboxPollingRate;
    }

    public int getBboxPort() {
        return this.bboxPort;
    }

    public String getHost() {
        return this.host;
    }

    public int getHttpPort() {
        return this.httpPort;
    }

    public int getPort() {
        return this.port;
    }

    public String getUdpHost() {
        return this.udpHost;
    }

    public int getUdpPort() {
        return this.udpPort;
    }

    public String getZone() {
        return this.zone;
    }

    public boolean isDebug() {
        return this.debug;
    }

    public boolean isUseBBox() {
        return this.useBBox;
    }

    public void setBboxHost(String str) {
        this.bboxHost = str;
    }

    public void setBboxPollingRate(int i) {
        this.bboxPollingRate = i;
    }

    public void setBboxPort(int i) {
        this.bboxPort = i;
    }

    public void setDebug(boolean z) {
        this.debug = z;
    }

    public void setHost(String str) {
        this.host = str;
    }

    public void setHttpPort(int i) {
        this.httpPort = i;
    }

    public void setPort(int i) {
        this.port = i;
    }

    public void setUdpHost(String str) {
        this.udpHost = str;
    }

    public void setUdpPort(int i) {
        this.udpPort = i;
    }

    public void setUseBBox(boolean z) {
        this.useBBox = z;
    }

    public void setZone(String str) {
        this.zone = str;
    }
}
