package sfs2x.client.util;

public class BuddyOnlineState {
    public static final int LEFT_THE_SERVER = 2;
    public static final int OFFLINE = 1;
    public static final int ONLINE = 0;
}
