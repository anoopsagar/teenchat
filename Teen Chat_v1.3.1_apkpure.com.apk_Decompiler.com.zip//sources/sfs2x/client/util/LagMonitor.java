package sfs2x.client.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import sfs2x.client.SmartFox;
import sfs2x.client.requests.PingPongRequest;

public class LagMonitor {
    private int interval;
    private volatile boolean isPollRunning;
    /* access modifiers changed from: private */
    public long lastReqTime;
    private Timer pollTimer;
    private int queueSize;
    /* access modifiers changed from: private */
    public SmartFox sfs;
    private List valueQueue;

    class PollTimerTask extends TimerTask {
        PollTimerTask() {
        }

        public void run() {
            LagMonitor.this.lastReqTime = System.currentTimeMillis();
            LagMonitor.this.sfs.send(new PingPongRequest());
        }
    }

    public LagMonitor(SmartFox smartFox) {
        this(smartFox, 4, 10);
    }

    public LagMonitor(SmartFox smartFox, int i) {
        this(smartFox, i, 10);
    }

    public LagMonitor(SmartFox smartFox, int i, int i2) {
        this.isPollRunning = false;
        i = i < 1 ? 1 : i;
        this.sfs = smartFox;
        this.valueQueue = new ArrayList();
        this.interval = i;
        this.queueSize = i2;
    }

    public int getAveragePingTime() {
        int i = 0;
        if (this.valueQueue.size() == 0) {
            return 0;
        }
        Iterator it = this.valueQueue.iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return i2 / this.valueQueue.size();
            }
            i = ((Integer) it.next()).intValue() + i2;
        }
    }

    public int getLastPingTime() {
        if (this.valueQueue.size() > 0) {
            return ((Integer) this.valueQueue.get(this.valueQueue.size() - 1)).intValue();
        }
        return 0;
    }

    public Boolean isRunning() {
        return Boolean.valueOf(this.isPollRunning);
    }

    public int onPingPong() {
        int currentTimeMillis = (int) (System.currentTimeMillis() - this.lastReqTime);
        if (this.valueQueue.size() >= this.queueSize) {
            this.valueQueue.remove(0);
        }
        this.valueQueue.add(Integer.valueOf(currentTimeMillis));
        return getAveragePingTime();
    }

    public void start() {
        if (!isRunning().booleanValue()) {
            this.pollTimer = new Timer();
            this.pollTimer.scheduleAtFixedRate(new PollTimerTask(), 0, (long) this.interval);
            this.isPollRunning = true;
        }
    }

    public void stop() {
        if (isRunning().booleanValue() && this.pollTimer != null) {
            this.pollTimer.cancel();
            this.pollTimer = null;
        }
    }
}
