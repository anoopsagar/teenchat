package sfs2x.client.util;

import java.io.File;
import java.util.HashMap;
import org.jboss.netty.handler.codec.rtsp.RtspHeaders;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sfs2x.client.core.EventDispatcher;
import sfs2x.client.core.SFSEvent;
import sfs2x.client.requests.game.CreateSFSGameRequest;

public class ConfigLoader {
    private EventDispatcher dispatcher = new EventDispatcher(this);
    private Document xmldoc;

    private void onConfigLoadFailure(String str) {
        HashMap hashMap = new HashMap();
        hashMap.put("message", str);
        this.dispatcher.dispatchEvent(new SFSEvent(SFSEvent.CONFIG_LOAD_FAILURE, hashMap));
    }

    private void tryParse() {
        Logger logger = LoggerFactory.getLogger((Class) getClass());
        ConfigData configData = new ConfigData();
        try {
            Element rootElement = this.xmldoc.getRootElement();
            if (rootElement.getChild(CreateSFSGameRequest.KEY_INVITATION_PARAMS) == null || rootElement.getChild(CreateSFSGameRequest.KEY_INVITATION_PARAMS).getText().equals("")) {
                logger.error("Required config node missing: ip");
            }
            if (rootElement.getChild(RtspHeaders.Values.PORT) == null || rootElement.getChild(RtspHeaders.Values.PORT).getText().equals("")) {
                logger.error("Required config node missing: port");
            }
            if (rootElement.getChild("udpIp") == null || rootElement.getChild("udpIp").getText().equals("")) {
                logger.error("Required config node missing: udpIp");
            }
            if (rootElement.getChild("udpPort") == null || rootElement.getChild("udpPort").getText().equals("")) {
                logger.error("Required config node missing: udpPort");
            }
            if (rootElement.getChild("zone") == null || rootElement.getChild("zone").getText().equals("")) {
                logger.error("Required config node missing: zone");
            }
            configData.setHost(rootElement.getChild(CreateSFSGameRequest.KEY_INVITATION_PARAMS).getText());
            configData.setPort(Integer.valueOf(rootElement.getChild(RtspHeaders.Values.PORT).getText()).intValue());
            configData.setUdpHost(rootElement.getChild("udpIp").getText());
            configData.setUdpPort(Integer.valueOf(rootElement.getChild("udpPort").getText()).intValue());
            configData.setZone(rootElement.getChild("zone").getText());
            if (rootElement.getChild("debug") != null && !rootElement.getChild("debug").getText().equals("")) {
                configData.setDebug(rootElement.getChild("debug").getText().toLowerCase().equals("true"));
            }
            if (rootElement.getChild("useBlueBox") != null && !rootElement.getChild("useBlueBox").getText().equals("")) {
                configData.setUseBBox(rootElement.getChild("useBlueBox").getText().toLowerCase().equals("true"));
            }
            if (rootElement.getChild("httpPort") != null && !rootElement.getChild("httpPort").getText().equals("")) {
                configData.setHttpPort(Integer.valueOf(rootElement.getChild("httpPort").getText()).intValue());
            }
            if (rootElement.getChild("blueBoxPollingRate") != null && !rootElement.getChild("blueBoxPollingRate").getText().equals("")) {
                configData.setBboxPollingRate(Integer.valueOf(rootElement.getChild("blueBoxPollingRate").getText()).intValue());
            }
            HashMap hashMap = new HashMap();
            hashMap.put("cfg", configData);
            this.dispatcher.dispatchEvent(new SFSEvent(SFSEvent.CONFIG_LOAD_SUCCESS, hashMap));
        } catch (Exception e) {
            e.printStackTrace();
            onConfigLoadFailure("Error parsing config file: " + e.getMessage() + " " + e.getStackTrace());
        }
    }

    public EventDispatcher getDispatcher() {
        return this.dispatcher;
    }

    public void loadConfig(String str) {
        try {
            this.xmldoc = new SAXBuilder(false).build(new File(str));
            tryParse();
        } catch (Exception e) {
            e.printStackTrace();
            onConfigLoadFailure("Error loading config file: " + e.getMessage());
        }
    }
}
