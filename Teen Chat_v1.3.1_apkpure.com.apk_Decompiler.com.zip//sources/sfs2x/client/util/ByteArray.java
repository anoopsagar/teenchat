package sfs2x.client.util;

import android.support.v4.view.MotionEventCompat;
import com.smartfoxserver.v2.entities.data.SFSDataType;
import com.smartfoxserver.v2.exceptions.SFSException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import org.apache.commons.lang.CharEncoding;

public class ByteArray {
    private byte[] buffer;
    private boolean compressed;
    private int position;

    public ByteArray() {
        this.position = 0;
        this.compressed = false;
        this.buffer = new byte[0];
    }

    public ByteArray(byte[] bArr) {
        this.position = 0;
        this.compressed = false;
        this.buffer = bArr;
    }

    private void checkCompressedRead() {
        if (this.compressed) {
            throw new SFSException("Only raw bytes can be read from a compressed array.");
        }
    }

    private void checkCompressedWrite() {
        if (this.compressed) {
            throw new SFSException("Only raw bytes can be written a compressed array. Call Uncompress first.");
        }
    }

    public void compress() {
        if (this.compressed) {
            throw new SFSException("Buffer is already compressed");
        }
        try {
            Deflater deflater = new Deflater();
            deflater.setLevel(9);
            deflater.setInput(this.buffer);
            deflater.finish();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[1024];
            while (!deflater.finished()) {
                byteArrayOutputStream.write(bArr, 0, deflater.deflate(bArr));
            }
            byteArrayOutputStream.close();
            this.buffer = byteArrayOutputStream.toByteArray();
            this.position = 0;
            this.compressed = true;
        } catch (IOException e) {
            throw new SFSException("Error compressing data");
        }
    }

    public byte[] getBytes() {
        return this.buffer;
    }

    public int getBytesAvailable() {
        int length = this.buffer.length - this.position;
        if (length > this.buffer.length || length < 0) {
            return 0;
        }
        return length;
    }

    public int getLength() {
        return this.buffer.length;
    }

    public int getPosition() {
        return this.position;
    }

    public boolean isCompressed() {
        return this.compressed;
    }

    public boolean readBool() {
        checkCompressedRead();
        byte[] bArr = this.buffer;
        int i = this.position;
        this.position = i + 1;
        return bArr[i] == 1;
    }

    public byte readByte() {
        checkCompressedRead();
        byte[] bArr = this.buffer;
        int i = this.position;
        this.position = i + 1;
        return bArr[i];
    }

    public byte[] readBytes(int i) {
        byte[] bArr = new byte[i];
        ByteBuffer wrap = ByteBuffer.wrap(this.buffer);
        wrap.position(this.position);
        wrap.get(bArr);
        this.position += i;
        return bArr;
    }

    public double readDouble() {
        checkCompressedRead();
        try {
            return new DataInputStream(new ByteArrayInputStream(reverseOrder(readBytes(8)))).readDouble();
        } catch (IOException e) {
            throw new SFSException("Error reading from data buffer");
        }
    }

    public float readFloat() {
        checkCompressedRead();
        try {
            return new DataInputStream(new ByteArrayInputStream(reverseOrder(readBytes(4)))).readFloat();
        } catch (IOException e) {
            throw new SFSException("Error reading from data buffer");
        }
    }

    public int readInt() {
        checkCompressedRead();
        try {
            return new DataInputStream(new ByteArrayInputStream(reverseOrder(readBytes(4)))).readInt();
        } catch (IOException e) {
            throw new SFSException("Error reading from data buffer");
        }
    }

    public long readLong() {
        checkCompressedRead();
        try {
            return new DataInputStream(new ByteArrayInputStream(reverseOrder(readBytes(8)))).readLong();
        } catch (IOException e) {
            throw new SFSException("Error reading from data buffer");
        }
    }

    public short readShort() {
        checkCompressedRead();
        try {
            return new DataInputStream(new ByteArrayInputStream(reverseOrder(readBytes(2)))).readShort();
        } catch (IOException e) {
            throw new SFSException("Error reading from data buffer");
        }
    }

    public int readUShort() {
        checkCompressedRead();
        byte[] reverseOrder = reverseOrder(readBytes(2));
        int intValue = new Integer(reverseOrder[0]).intValue();
        if (intValue < 0) {
            intValue = (reverseOrder[0] & 128) + (reverseOrder[0] & Byte.MAX_VALUE);
        }
        int intValue2 = new Integer(reverseOrder[1]).intValue();
        if (intValue2 < 0) {
            intValue2 = (reverseOrder[1] & 128) + (reverseOrder[1] & Byte.MAX_VALUE);
        }
        return (intValue * 256) + intValue2;
    }

    public String readUTF() {
        try {
            checkCompressedRead();
            return new String(readBytes(readShort()), CharEncoding.UTF_8);
        } catch (UnsupportedEncodingException e) {
            throw new SFSException("Error reading from data buffer");
        }
    }

    public byte[] reverseOrder(byte[] bArr) {
        return bArr;
    }

    public void setBuffer(byte[] bArr) {
        this.buffer = bArr;
        this.compressed = false;
    }

    public void setCompressed(boolean z) {
        this.compressed = z;
    }

    public void setPosition(int i) {
        this.position = i;
    }

    public void uncompress() {
        try {
            Inflater inflater = new Inflater();
            inflater.setInput(this.buffer);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[1024];
            while (!inflater.finished()) {
                byteArrayOutputStream.write(bArr, 0, inflater.inflate(bArr));
            }
            byteArrayOutputStream.close();
            this.buffer = byteArrayOutputStream.toByteArray();
            this.position = 0;
            this.compressed = false;
        } catch (DataFormatException e) {
            throw new SFSException("Data format exception decompressing buffer");
        } catch (IOException e2) {
            throw new SFSException("Error decompressing data");
        }
    }

    public void writeBool(boolean z) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new DataOutputStream(byteArrayOutputStream).writeByte(z ? 1 : 0);
            writeBytes(byteArrayOutputStream.toByteArray());
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeByte(byte b) {
        writeBytes(new byte[]{b});
    }

    public void writeByte(SFSDataType sFSDataType) {
        writeByte((byte) sFSDataType.getTypeID());
    }

    public void writeBytes(byte[] bArr) {
        writeBytes(bArr, bArr.length);
    }

    public void writeBytes(byte[] bArr, int i) {
        ByteBuffer allocate = ByteBuffer.allocate(this.buffer.length + i);
        allocate.put(this.buffer);
        byte[] bArr2 = new byte[i];
        ByteBuffer.wrap(bArr).get(bArr2, 0, i);
        allocate.put(bArr2);
        this.buffer = allocate.array();
    }

    public void writeDouble(double d) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new DataOutputStream(byteArrayOutputStream).writeDouble(d);
            writeBytes(reverseOrder(byteArrayOutputStream.toByteArray()));
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeFloat(float f) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new DataOutputStream(byteArrayOutputStream).writeFloat(f);
            writeBytes(reverseOrder(byteArrayOutputStream.toByteArray()));
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeInt(int i) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new DataOutputStream(byteArrayOutputStream).writeInt(i);
            writeBytes(reverseOrder(byteArrayOutputStream.toByteArray()));
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeLong(long j) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new DataOutputStream(byteArrayOutputStream).writeLong(j);
            writeBytes(reverseOrder(byteArrayOutputStream.toByteArray()));
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeShort(short s) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new DataOutputStream(byteArrayOutputStream).writeShort(s);
            writeBytes(reverseOrder(byteArrayOutputStream.toByteArray()));
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeUShort(int i) {
        checkCompressedWrite();
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
            int i2 = i & MotionEventCompat.ACTION_MASK;
            dataOutputStream.writeByte((byte) ((65280 & i) >> 8));
            dataOutputStream.writeByte((byte) i2);
            writeBytes(byteArrayOutputStream.toByteArray());
        } catch (IOException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }

    public void writeUTF(String str) {
        checkCompressedWrite();
        int i = 0;
        for (int i2 = 0; i2 < str.length(); i2++) {
            char charAt = str.charAt(i2);
            i = (charAt < 1 || charAt > 127) ? charAt > 2047 ? i + 3 : i + 2 : i + 1;
        }
        if (i > 32768) {
            throw new SFSException("String length cannot be greater then 32768 !");
        }
        try {
            writeShort((short) i);
            writeBytes(str.getBytes("UTF8"));
        } catch (UnsupportedEncodingException e) {
            throw new SFSException("Error writing to data buffer");
        }
    }
}
