package sfs2x.fsm;

import java.util.ArrayList;
import java.util.List;

public class FiniteStateMachine {
    private int currentStateName;
    private Object locker = new Object();
    private List states = new ArrayList();

    private FSMState findStateObjByName(int i) {
        for (FSMState fSMState : this.states) {
            if (i == fSMState.getStateName()) {
                return fSMState;
            }
        }
        return null;
    }

    public void addAllStates(int i) {
        for (int i2 = 0; i2 < i; i2++) {
            addState(i2);
        }
    }

    public void addState(int i) {
        FSMState fSMState = new FSMState();
        fSMState.setStateName(i);
        this.states.add(fSMState);
    }

    public void addStateTransition(int i, int i2, int i3) {
        findStateObjByName(i).addTransition(i3, i2);
    }

    public int applyTransition(int i) {
        int i2;
        synchronized (this.locker) {
            int i3 = this.currentStateName;
            this.currentStateName = findStateObjByName(this.currentStateName).applyTransition(i);
            i2 = this.currentStateName;
        }
        return i2;
    }

    public int getCurrentState() {
        int i;
        synchronized (this.locker) {
            i = this.currentStateName;
        }
        return i;
    }

    public void setCurrentState(int i) {
        this.currentStateName = i;
    }
}
