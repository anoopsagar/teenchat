package net.sf.json;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import net.sf.ezmorph.object.IdentityObjectMorpher;
import net.sf.json.processors.JsonValueProcessor;
import net.sf.json.processors.JsonVerifier;
import net.sf.json.util.JSONTokener;
import net.sf.json.util.JSONUtils;
import org.apache.commons.lang.StringUtils;

public final class JSONArray extends AbstractJSON implements Comparable, List, JSON {
    private List elements = new ArrayList();
    private boolean expandElements;

    class JSONArrayListIterator implements ListIterator {
        int currentIndex = 0;
        int lastIndex = -1;

        JSONArrayListIterator() {
        }

        JSONArrayListIterator(int i) {
            this.currentIndex = i;
        }

        public void add(Object obj) {
            try {
                JSONArray jSONArray = JSONArray.this;
                int i = this.currentIndex;
                this.currentIndex = i + 1;
                jSONArray.add(i, obj);
                this.lastIndex = -1;
            } catch (IndexOutOfBoundsException e) {
                throw new ConcurrentModificationException();
            }
        }

        public boolean hasNext() {
            return this.currentIndex != JSONArray.this.size();
        }

        public boolean hasPrevious() {
            return this.currentIndex != 0;
        }

        public Object next() {
            try {
                Object obj = JSONArray.this.get(this.currentIndex);
                int i = this.currentIndex;
                this.currentIndex = i + 1;
                this.lastIndex = i;
                return obj;
            } catch (IndexOutOfBoundsException e) {
                throw new NoSuchElementException();
            }
        }

        public int nextIndex() {
            return this.currentIndex;
        }

        public Object previous() {
            try {
                int i = this.currentIndex - 1;
                Object obj = JSONArray.this.get(i);
                this.currentIndex = i;
                this.lastIndex = i;
                return obj;
            } catch (IndexOutOfBoundsException e) {
                throw new NoSuchElementException();
            }
        }

        public int previousIndex() {
            return this.currentIndex - 1;
        }

        public void remove() {
            if (this.lastIndex == -1) {
                throw new IllegalStateException();
            }
            try {
                JSONArray.this.remove(this.lastIndex);
                if (this.lastIndex < this.currentIndex) {
                    this.currentIndex--;
                }
                this.lastIndex = -1;
            } catch (IndexOutOfBoundsException e) {
                throw new ConcurrentModificationException();
            }
        }

        public void set(Object obj) {
            if (this.lastIndex == -1) {
                throw new IllegalStateException();
            }
            try {
                JSONArray.this.set(this.lastIndex, obj);
            } catch (IndexOutOfBoundsException e) {
                throw new ConcurrentModificationException();
            }
        }
    }

    private JSONArray _addValue(Object obj, JsonConfig jsonConfig) {
        this.elements.add(_processValue(obj, jsonConfig));
        return this;
    }

    private static JSONArray _fromArray(Enum enumR, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(enumR)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(enumR);
            } catch (JSONException e) {
                removeInstance(enumR);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(enumR);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            if (enumR != null) {
                jSONArray.elements.add(enumR.toString());
                fireElementAddedEvent(0, jSONArray.get(0), jsonConfig);
                removeInstance(enumR);
                fireArrayEndEvent(jsonConfig);
                return jSONArray;
            }
            JSONException jSONException2 = new JSONException("enum value is null");
            removeInstance(enumR);
            fireErrorEvent(jSONException2, jsonConfig);
            throw jSONException2;
        }
    }

    private static JSONArray _fromArray(byte[] bArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(bArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(bArr);
            } catch (JSONException e) {
                removeInstance(bArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(bArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < bArr.length; i++) {
                Number transformNumber = JSONUtils.transformNumber(new Byte(bArr[i]));
                jSONArray.elements.add(transformNumber);
                fireElementAddedEvent(i, transformNumber, jsonConfig);
            }
            removeInstance(bArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(char[] cArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(cArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(cArr);
            } catch (JSONException e) {
                removeInstance(cArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(cArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < cArr.length; i++) {
                Character ch = new Character(cArr[i]);
                jSONArray.elements.add(ch);
                fireElementAddedEvent(i, ch, jsonConfig);
            }
            removeInstance(cArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(double[] dArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(dArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(dArr);
            } catch (JSONException e) {
                removeInstance(dArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(dArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < dArr.length) {
                try {
                    Double d = new Double(dArr[i]);
                    JSONUtils.testValidity(d);
                    jSONArray.elements.add(d);
                    fireElementAddedEvent(i, d, jsonConfig);
                    i++;
                } catch (JSONException e3) {
                    removeInstance(dArr);
                    fireErrorEvent(e3, jsonConfig);
                    throw e3;
                }
            }
            removeInstance(dArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(float[] fArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(fArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(fArr);
            } catch (JSONException e) {
                removeInstance(fArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(fArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < fArr.length) {
                try {
                    Float f = new Float(fArr[i]);
                    JSONUtils.testValidity(f);
                    jSONArray.elements.add(f);
                    fireElementAddedEvent(i, f, jsonConfig);
                    i++;
                } catch (JSONException e3) {
                    removeInstance(fArr);
                    fireErrorEvent(e3, jsonConfig);
                    throw e3;
                }
            }
            removeInstance(fArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(int[] iArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(iArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(iArr);
            } catch (JSONException e) {
                removeInstance(iArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(iArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < iArr.length; i++) {
                Integer num = new Integer(iArr[i]);
                jSONArray.elements.add(num);
                fireElementAddedEvent(i, num, jsonConfig);
            }
            removeInstance(iArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(long[] jArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(jArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(jArr);
            } catch (JSONException e) {
                removeInstance(jArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(jArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < jArr.length; i++) {
                Number transformNumber = JSONUtils.transformNumber(new Long(jArr[i]));
                jSONArray.elements.add(transformNumber);
                fireElementAddedEvent(i, transformNumber, jsonConfig);
            }
            removeInstance(jArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(Object[] objArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(objArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(objArr);
            } catch (JSONException e) {
                removeInstance(objArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(objArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            while (i < objArr.length) {
                try {
                    jSONArray.addValue(objArr[i], jsonConfig);
                    fireElementAddedEvent(i, jSONArray.get(i), jsonConfig);
                    i++;
                } catch (JSONException e3) {
                    removeInstance(objArr);
                    fireErrorEvent(e3, jsonConfig);
                    throw e3;
                } catch (RuntimeException e4) {
                    removeInstance(objArr);
                    JSONException jSONException2 = new JSONException((Throwable) e4);
                    fireErrorEvent(jSONException2, jsonConfig);
                    throw jSONException2;
                }
            }
            removeInstance(objArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(short[] sArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(sArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(sArr);
            } catch (JSONException e) {
                removeInstance(sArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(sArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < sArr.length; i++) {
                Number transformNumber = JSONUtils.transformNumber(new Short(sArr[i]));
                jSONArray.elements.add(transformNumber);
                fireElementAddedEvent(i, transformNumber, jsonConfig);
            }
            removeInstance(sArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromArray(boolean[] zArr, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(zArr)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(zArr);
            } catch (JSONException e) {
                removeInstance(zArr);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(zArr);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            for (int i = 0; i < zArr.length; i++) {
                Boolean bool = zArr[i] ? Boolean.TRUE : Boolean.FALSE;
                jSONArray.elements.add(bool);
                fireElementAddedEvent(i, bool, jsonConfig);
            }
            removeInstance(zArr);
            fireArrayEndEvent(jsonConfig);
            return jSONArray;
        }
    }

    private static JSONArray _fromCollection(Collection collection, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(collection)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(collection);
            } catch (JSONException e) {
                removeInstance(collection);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(collection);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray = new JSONArray();
            int i = 0;
            try {
                for (Object addValue : collection) {
                    jSONArray.addValue(addValue, jsonConfig);
                    int i2 = i + 1;
                    fireElementAddedEvent(i, jSONArray.get(i), jsonConfig);
                    i = i2;
                }
                removeInstance(collection);
                fireArrayEndEvent(jsonConfig);
                return jSONArray;
            } catch (JSONException e3) {
                removeInstance(collection);
                fireErrorEvent(e3, jsonConfig);
                throw e3;
            } catch (RuntimeException e4) {
                removeInstance(collection);
                JSONException jSONException2 = new JSONException((Throwable) e4);
                fireErrorEvent(jSONException2, jsonConfig);
                throw jSONException2;
            }
        }
    }

    private static JSONArray _fromJSONArray(JSONArray jSONArray, JsonConfig jsonConfig) {
        fireArrayStartEvent(jsonConfig);
        if (!addInstance(jSONArray)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(jSONArray);
            } catch (JSONException e) {
                removeInstance(jSONArray);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(jSONArray);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray jSONArray2 = new JSONArray();
            int i = 0;
            Iterator it = jSONArray.iterator();
            while (it.hasNext()) {
                Object next = it.next();
                jSONArray2.elements.add(next);
                fireElementAddedEvent(i, next, jsonConfig);
                i++;
            }
            removeInstance(jSONArray);
            fireArrayEndEvent(jsonConfig);
            return jSONArray2;
        }
    }

    private static JSONArray _fromJSONString(JSONString jSONString, JsonConfig jsonConfig) {
        return _fromJSONTokener(new JSONTokener(jSONString.toJSONString()), jsonConfig);
    }

    private static JSONArray _fromJSONTokener(JSONTokener jSONTokener, JsonConfig jsonConfig) {
        int i;
        fireArrayStartEvent(jsonConfig);
        JSONArray jSONArray = new JSONArray();
        try {
            if (jSONTokener.nextClean() != '[') {
                throw jSONTokener.syntaxError("A JSONArray text must start with '['");
            } else if (jSONTokener.nextClean() == ']') {
                fireArrayEndEvent(jsonConfig);
                return jSONArray;
            } else {
                jSONTokener.back();
                int i2 = 0;
                while (true) {
                    if (jSONTokener.nextClean() == ',') {
                        jSONTokener.back();
                        jSONArray.elements.add(JSONNull.getInstance());
                        i = i2 + 1;
                        fireElementAddedEvent(i2, jSONArray.get(i2), jsonConfig);
                    } else {
                        jSONTokener.back();
                        Object nextValue = jSONTokener.nextValue(jsonConfig);
                        if (!JSONUtils.isFunctionHeader(nextValue)) {
                            if (!(nextValue instanceof String) || !JSONUtils.mayBeJSON((String) nextValue)) {
                                jSONArray.addValue(nextValue, jsonConfig);
                            } else {
                                jSONArray.addValue(JSONUtils.DOUBLE_QUOTE + nextValue + JSONUtils.DOUBLE_QUOTE, jsonConfig);
                            }
                            i = i2 + 1;
                            fireElementAddedEvent(i2, jSONArray.get(i2), jsonConfig);
                        } else {
                            String functionParams = JSONUtils.getFunctionParams((String) nextValue);
                            StringBuffer stringBuffer = new StringBuffer();
                            int i3 = 0;
                            while (true) {
                                char next = jSONTokener.next();
                                if (next != 0) {
                                    if (next == '{') {
                                        i3++;
                                    }
                                    if (next == '}') {
                                        i3--;
                                    }
                                    stringBuffer.append(next);
                                    if (i3 == 0) {
                                    }
                                }
                            }
                            if (i3 != 0) {
                                throw jSONTokener.syntaxError("Unbalanced '{' or '}' on prop: " + nextValue);
                            }
                            String stringBuffer2 = stringBuffer.toString();
                            jSONArray.addValue(new JSONFunction(functionParams != null ? StringUtils.split(functionParams, ",") : null, stringBuffer2.substring(1, stringBuffer2.length() - 1).trim()), jsonConfig);
                            i = i2 + 1;
                            fireElementAddedEvent(i2, jSONArray.get(i2), jsonConfig);
                        }
                    }
                    switch (jSONTokener.nextClean()) {
                        case ',':
                        case ';':
                            if (jSONTokener.nextClean() == ']') {
                                fireArrayEndEvent(jsonConfig);
                                return jSONArray;
                            }
                            jSONTokener.back();
                            i2 = i;
                        case ']':
                            fireArrayEndEvent(jsonConfig);
                            return jSONArray;
                        default:
                            throw jSONTokener.syntaxError("Expected a ',' or ']'");
                    }
                }
            }
        } catch (JSONException e) {
            fireErrorEvent(e, jsonConfig);
            throw e;
        }
    }

    private static JSONArray _fromString(String str, JsonConfig jsonConfig) {
        return _fromJSONTokener(new JSONTokener(str), jsonConfig);
    }

    private Object _processValue(Object obj, JsonConfig jsonConfig) {
        if ((obj != null && Class.class.isAssignableFrom(obj.getClass())) || (obj instanceof Class)) {
            return ((Class) obj).getName();
        }
        if (JSONUtils.isFunction(obj)) {
            return obj instanceof String ? JSONFunction.parse((String) obj) : obj;
        }
        if (obj instanceof JSONString) {
            return JSONSerializer.toJSON((Object) (JSONString) obj, jsonConfig);
        }
        if (obj instanceof JSON) {
            return JSONSerializer.toJSON(obj, jsonConfig);
        }
        if (JSONUtils.isArray(obj)) {
            return fromObject(obj, jsonConfig);
        }
        if (obj instanceof JSONTokener) {
            return _fromJSONTokener((JSONTokener) obj, jsonConfig);
        }
        if (JSONUtils.isString(obj)) {
            String valueOf = String.valueOf(obj);
            if (!JSONUtils.mayBeJSON(valueOf)) {
                return valueOf;
            }
            try {
                return JSONSerializer.toJSON((Object) valueOf, jsonConfig);
            } catch (JSONException e) {
                return JSONUtils.stripQuotes(valueOf);
            }
        } else if (JSONUtils.isNumber(obj)) {
            JSONUtils.testValidity(obj);
            return JSONUtils.transformNumber((Number) obj);
        } else if (JSONUtils.isBoolean(obj)) {
            return obj;
        } else {
            if (obj instanceof Enum) {
                return String.valueOf(obj);
            }
            if ((obj instanceof Annotation) || (obj != null && obj.getClass().isAnnotation())) {
                throw new JSONException("Unsupported type");
            }
            JSONObject fromObject = JSONObject.fromObject(obj, jsonConfig);
            return fromObject.isNullObject() ? JSONNull.getInstance() : fromObject;
        }
    }

    private JSONArray addValue(Object obj, JsonConfig jsonConfig) {
        return _addValue(processValue(obj, jsonConfig), jsonConfig);
    }

    public static JSONArray fromObject(Object obj) {
        return fromObject(obj, new JsonConfig());
    }

    public static JSONArray fromObject(Object obj, JsonConfig jsonConfig) {
        if (obj instanceof JSONString) {
            return _fromJSONString((JSONString) obj, jsonConfig);
        }
        if (obj instanceof JSONArray) {
            return _fromJSONArray((JSONArray) obj, jsonConfig);
        }
        if (obj instanceof Collection) {
            return _fromCollection((Collection) obj, jsonConfig);
        }
        if (obj instanceof JSONTokener) {
            return _fromJSONTokener((JSONTokener) obj, jsonConfig);
        }
        if (obj instanceof String) {
            return _fromString((String) obj, jsonConfig);
        }
        if (obj != null && obj.getClass().isArray()) {
            Class<?> componentType = obj.getClass().getComponentType();
            if (!componentType.isPrimitive()) {
                return _fromArray((Object[]) obj, jsonConfig);
            }
            if (componentType == Boolean.TYPE) {
                return _fromArray((boolean[]) obj, jsonConfig);
            }
            if (componentType == Byte.TYPE) {
                return _fromArray((byte[]) obj, jsonConfig);
            }
            if (componentType == Short.TYPE) {
                return _fromArray((short[]) obj, jsonConfig);
            }
            if (componentType == Integer.TYPE) {
                return _fromArray((int[]) obj, jsonConfig);
            }
            if (componentType == Long.TYPE) {
                return _fromArray((long[]) obj, jsonConfig);
            }
            if (componentType == Float.TYPE) {
                return _fromArray((float[]) obj, jsonConfig);
            }
            if (componentType == Double.TYPE) {
                return _fromArray((double[]) obj, jsonConfig);
            }
            if (componentType == Character.TYPE) {
                return _fromArray((char[]) obj, jsonConfig);
            }
            throw new JSONException("Unsupported type");
        } else if (JSONUtils.isBoolean(obj) || JSONUtils.isFunction(obj) || JSONUtils.isNumber(obj) || JSONUtils.isNull(obj) || JSONUtils.isString(obj) || (obj instanceof JSON)) {
            fireArrayStartEvent(jsonConfig);
            JSONArray element = new JSONArray().element(obj, jsonConfig);
            fireElementAddedEvent(0, element.get(0), jsonConfig);
            fireArrayStartEvent(jsonConfig);
            return element;
        } else if (obj instanceof Enum) {
            return _fromArray((Enum) obj, jsonConfig);
        } else {
            if ((obj instanceof Annotation) || (obj != null && obj.getClass().isAnnotation())) {
                throw new JSONException("Unsupported type");
            } else if (JSONUtils.isObject(obj)) {
                fireArrayStartEvent(jsonConfig);
                JSONArray element2 = new JSONArray().element(JSONObject.fromObject(obj, jsonConfig));
                fireElementAddedEvent(0, element2.get(0), jsonConfig);
                fireArrayStartEvent(jsonConfig);
                return element2;
            } else {
                throw new JSONException("Unsupported type");
            }
        }
    }

    public static Class[] getCollectionType(PropertyDescriptor propertyDescriptor, boolean z) {
        Type type;
        if (z) {
            type = propertyDescriptor.getReadMethod().getGenericReturnType();
        } else {
            Method writeMethod = propertyDescriptor.getWriteMethod();
            Type[] genericParameterTypes = writeMethod.getGenericParameterTypes();
            if (1 != genericParameterTypes.length) {
                throw new JSONException("method " + writeMethod + " is not a standard setter");
            }
            type = genericParameterTypes[0];
        }
        if (!(type instanceof ParameterizedType)) {
            return null;
        }
        Type[] actualTypeArguments = ((ParameterizedType) type).getActualTypeArguments();
        Class[] clsArr = new Class[actualTypeArguments.length];
        for (int i = 0; i < clsArr.length; i++) {
            clsArr[i] = (Class) actualTypeArguments[i];
        }
        return clsArr;
    }

    public static int[] getDimensions(JSONArray jSONArray) {
        if (jSONArray == null || jSONArray.isEmpty()) {
            return new int[]{0};
        }
        ArrayList<Integer> arrayList = new ArrayList<>();
        processArrayDimensions(jSONArray, arrayList, 0);
        int[] iArr = new int[arrayList.size()];
        int i = 0;
        for (Integer intValue : arrayList) {
            iArr[i] = intValue.intValue();
            i++;
        }
        return iArr;
    }

    private static void processArrayDimensions(JSONArray jSONArray, List list, int i) {
        if (list.size() <= i) {
            list.add(new Integer(jSONArray.size()));
        } else {
            if (jSONArray.size() > ((Integer) list.get(i)).intValue()) {
                list.set(i, new Integer(jSONArray.size()));
            }
        }
        Iterator it = jSONArray.iterator();
        while (it.hasNext()) {
            Object next = it.next();
            if (next instanceof JSONArray) {
                processArrayDimensions((JSONArray) next, list, i + 1);
            }
        }
    }

    private Object processValue(Object obj, JsonConfig jsonConfig) {
        JsonValueProcessor findJsonValueProcessor;
        if (!(obj == null || (findJsonValueProcessor = jsonConfig.findJsonValueProcessor(obj.getClass())) == null)) {
            obj = findJsonValueProcessor.processArrayValue(obj, jsonConfig);
            if (!JsonVerifier.isValidJsonValue(obj)) {
                throw new JSONException("Value is not a valid JSON value. " + obj);
            }
        }
        return _processValue(obj, jsonConfig);
    }

    public static Object toArray(JSONArray jSONArray) {
        return toArray(jSONArray, new JsonConfig());
    }

    public static Object toArray(JSONArray jSONArray, Class cls) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        return toArray(jSONArray, jsonConfig);
    }

    public static Object toArray(JSONArray jSONArray, Class cls, Map map) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        jsonConfig.setClassMap(map);
        return toArray(jSONArray, jsonConfig);
    }

    public static Object toArray(JSONArray jSONArray, Object obj, JsonConfig jsonConfig) {
        Class<?> cls = obj.getClass();
        if (jSONArray.size() == 0) {
            return Array.newInstance(cls, 0);
        }
        Object newInstance = Array.newInstance(cls == null ? Object.class : cls, getDimensions(jSONArray));
        int size = jSONArray.size();
        for (int i = 0; i < size; i++) {
            Object obj2 = jSONArray.get(i);
            if (JSONUtils.isNull(obj2)) {
                Array.set(newInstance, i, (Object) null);
            } else {
                Class<?> cls2 = obj2.getClass();
                if (JSONArray.class.isAssignableFrom(cls2)) {
                    Array.set(newInstance, i, toArray((JSONArray) obj2, obj, jsonConfig));
                } else if (String.class.isAssignableFrom(cls2) || Boolean.class.isAssignableFrom(cls2) || JSONUtils.isNumber((Class) cls2) || Character.class.isAssignableFrom(cls2) || JSONFunction.class.isAssignableFrom(cls2)) {
                    if (cls != null && !cls.isAssignableFrom(cls2)) {
                        obj2 = JSONUtils.getMorpherRegistry().morph(cls, obj2);
                    }
                    Array.set(newInstance, i, obj2);
                } else {
                    try {
                        Array.set(newInstance, i, JSONObject.toBean((JSONObject) obj2, jsonConfig.getNewBeanInstanceStrategy().newInstance(obj.getClass(), (JSONObject) null), jsonConfig));
                    } catch (JSONException e) {
                        throw e;
                    } catch (Exception e2) {
                        throw new JSONException((Throwable) e2);
                    }
                }
            }
        }
        return newInstance;
    }

    public static Object toArray(JSONArray jSONArray, JsonConfig jsonConfig) {
        Class<Object> rootClass = jsonConfig.getRootClass();
        Map classMap = jsonConfig.getClassMap();
        if (jSONArray.size() == 0) {
            return Array.newInstance(rootClass == null ? Object.class : rootClass, 0);
        }
        Object newInstance = Array.newInstance(rootClass == null ? Object.class : rootClass, getDimensions(jSONArray));
        int size = jSONArray.size();
        for (int i = 0; i < size; i++) {
            Object obj = jSONArray.get(i);
            if (JSONUtils.isNull(obj)) {
                Array.set(newInstance, i, (Object) null);
            } else {
                Class<?> cls = obj.getClass();
                if (JSONArray.class.isAssignableFrom(cls)) {
                    Array.set(newInstance, i, toArray((JSONArray) obj, (Class) rootClass, classMap));
                } else if (String.class.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls) || Character.class.isAssignableFrom(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                    if (rootClass != null && !rootClass.isAssignableFrom(cls)) {
                        obj = JSONUtils.getMorpherRegistry().morph(rootClass, obj);
                    }
                    Array.set(newInstance, i, obj);
                } else if (JSONUtils.isNumber((Class) cls)) {
                    if (rootClass != null && (Byte.class.isAssignableFrom(rootClass) || Byte.TYPE.isAssignableFrom(rootClass))) {
                        Array.set(newInstance, i, Byte.valueOf(String.valueOf(obj)));
                    } else if (rootClass == null || (!Short.class.isAssignableFrom(rootClass) && !Short.TYPE.isAssignableFrom(rootClass))) {
                        Array.set(newInstance, i, obj);
                    } else {
                        Array.set(newInstance, i, Short.valueOf(String.valueOf(obj)));
                    }
                } else if (rootClass != null) {
                    JsonConfig copy = jsonConfig.copy();
                    copy.setRootClass(rootClass);
                    copy.setClassMap(classMap);
                    Array.set(newInstance, i, JSONObject.toBean((JSONObject) obj, copy));
                } else {
                    Array.set(newInstance, i, JSONObject.toBean((JSONObject) obj));
                }
            }
        }
        return newInstance;
    }

    public static Collection toCollection(JSONArray jSONArray) {
        return toCollection(jSONArray, new JsonConfig());
    }

    public static Collection toCollection(JSONArray jSONArray, Class cls) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        return toCollection(jSONArray, jsonConfig);
    }

    public static Collection toCollection(JSONArray jSONArray, JsonConfig jsonConfig) {
        ArrayList arrayList;
        Class collectionType = jsonConfig.getCollectionType();
        if (!collectionType.isInterface()) {
            try {
                arrayList = (Collection) collectionType.newInstance();
            } catch (InstantiationException e) {
                throw new JSONException((Throwable) e);
            } catch (IllegalAccessException e2) {
                throw new JSONException((Throwable) e2);
            }
        } else if (collectionType.equals(List.class)) {
            arrayList = new ArrayList();
        } else if (collectionType.equals(Set.class)) {
            arrayList = new HashSet();
        } else {
            throw new JSONException("unknown interface: " + collectionType);
        }
        Class rootClass = jsonConfig.getRootClass();
        Map classMap = jsonConfig.getClassMap();
        int size = jSONArray.size();
        for (int i = 0; i < size; i++) {
            Object obj = jSONArray.get(i);
            if (JSONUtils.isNull(obj)) {
                arrayList.add((Object) null);
            } else {
                Class<?> cls = obj.getClass();
                if (JSONArray.class.isAssignableFrom(obj.getClass())) {
                    arrayList.add(toCollection((JSONArray) obj, jsonConfig));
                } else if (String.class.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls) || JSONUtils.isNumber((Class) cls) || Character.class.isAssignableFrom(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                    if (!obj.getClass().isAssignableFrom(cls)) {
                        throw new JSONException("can't assign value " + obj + " of type " + obj.getClass() + " to Collection of type " + cls);
                    }
                    arrayList.add(obj);
                } else if (rootClass != null) {
                    JsonConfig copy = jsonConfig.copy();
                    copy.setRootClass(rootClass);
                    copy.setClassMap(classMap);
                    arrayList.add(JSONObject.toBean((JSONObject) obj, copy));
                } else {
                    arrayList.add(JSONObject.toBean((JSONObject) obj));
                }
            }
        }
        return arrayList;
    }

    public static List toList(JSONArray jSONArray) {
        return toList(jSONArray, new JsonConfig());
    }

    public static List toList(JSONArray jSONArray, Class cls) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        return toList(jSONArray, jsonConfig);
    }

    public static List toList(JSONArray jSONArray, Class cls, Map map) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        jsonConfig.setClassMap(map);
        return toList(jSONArray, jsonConfig);
    }

    public static List toList(JSONArray jSONArray, Object obj, JsonConfig jsonConfig) {
        if (jSONArray.size() == 0 || obj == null) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList();
        int size = jSONArray.size();
        for (int i = 0; i < size; i++) {
            Object obj2 = jSONArray.get(i);
            if (JSONUtils.isNull(obj2)) {
                arrayList.add((Object) null);
            } else {
                Class<?> cls = obj2.getClass();
                if (JSONArray.class.isAssignableFrom(cls)) {
                    arrayList.add(toList((JSONArray) obj2, obj, jsonConfig));
                } else if (String.class.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls) || JSONUtils.isNumber((Class) cls) || Character.class.isAssignableFrom(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                    arrayList.add(obj2);
                } else {
                    try {
                        arrayList.add(JSONObject.toBean((JSONObject) obj2, jsonConfig.getNewBeanInstanceStrategy().newInstance(obj.getClass(), (JSONObject) null), jsonConfig));
                    } catch (JSONException e) {
                        throw e;
                    } catch (Exception e2) {
                        throw new JSONException((Throwable) e2);
                    }
                }
            }
        }
        return arrayList;
    }

    public static List toList(JSONArray jSONArray, JsonConfig jsonConfig) {
        if (jSONArray.size() == 0) {
            return new ArrayList();
        }
        Class rootClass = jsonConfig.getRootClass();
        Map classMap = jsonConfig.getClassMap();
        ArrayList arrayList = new ArrayList();
        int size = jSONArray.size();
        for (int i = 0; i < size; i++) {
            Object obj = jSONArray.get(i);
            if (JSONUtils.isNull(obj)) {
                arrayList.add((Object) null);
            } else {
                Class<?> cls = obj.getClass();
                if (JSONArray.class.isAssignableFrom(cls)) {
                    arrayList.add(toList((JSONArray) obj, rootClass, classMap));
                } else if (String.class.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls) || JSONUtils.isNumber((Class) cls) || Character.class.isAssignableFrom(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                    if (rootClass != null && !rootClass.isAssignableFrom(cls)) {
                        obj = JSONUtils.getMorpherRegistry().morph(rootClass, obj);
                    }
                    arrayList.add(obj);
                } else if (rootClass != null) {
                    JsonConfig copy = jsonConfig.copy();
                    copy.setRootClass(rootClass);
                    copy.setClassMap(classMap);
                    arrayList.add(JSONObject.toBean((JSONObject) obj, copy));
                } else {
                    arrayList.add(JSONObject.toBean((JSONObject) obj));
                }
            }
        }
        return arrayList;
    }

    public void add(int i, Object obj) {
        add(i, obj, new JsonConfig());
    }

    public void add(int i, Object obj, JsonConfig jsonConfig) {
        this.elements.add(i, processValue(obj, jsonConfig));
    }

    public boolean add(Object obj) {
        return add(obj, new JsonConfig());
    }

    public boolean add(Object obj, JsonConfig jsonConfig) {
        element(obj, jsonConfig);
        return true;
    }

    public boolean addAll(int i, Collection collection) {
        return addAll(i, collection, new JsonConfig());
    }

    public boolean addAll(int i, Collection collection, JsonConfig jsonConfig) {
        int i2 = 0;
        if (collection == null || collection.size() == 0) {
            return false;
        }
        for (Object processValue : collection) {
            this.elements.add(i2 + i, processValue(processValue, jsonConfig));
            i2++;
        }
        return true;
    }

    public boolean addAll(Collection collection) {
        return addAll(collection, new JsonConfig());
    }

    public boolean addAll(Collection collection, JsonConfig jsonConfig) {
        if (collection == null || collection.size() == 0) {
            return false;
        }
        for (Object element : collection) {
            element(element, jsonConfig);
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public JSONArray addString(String str) {
        if (str != null) {
            this.elements.add(str);
        }
        return this;
    }

    public void clear() {
        this.elements.clear();
    }

    public int compareTo(Object obj) {
        JSONArray jSONArray;
        int size;
        int size2;
        if (obj == null || !(obj instanceof JSONArray) || (size = size()) < (size2 = jSONArray.size())) {
            return -1;
        }
        if (size > size2) {
            return 1;
        }
        return equals((jSONArray = (JSONArray) obj)) ? 0 : -1;
    }

    public boolean contains(Object obj) {
        return contains(obj, new JsonConfig());
    }

    public boolean contains(Object obj, JsonConfig jsonConfig) {
        return this.elements.contains(processValue(obj, jsonConfig));
    }

    public boolean containsAll(Collection collection) {
        return containsAll(collection, new JsonConfig());
    }

    public boolean containsAll(Collection collection, JsonConfig jsonConfig) {
        return this.elements.containsAll(fromObject(collection, jsonConfig));
    }

    public JSONArray discard(int i) {
        this.elements.remove(i);
        return this;
    }

    public JSONArray discard(Object obj) {
        this.elements.remove(obj);
        return this;
    }

    public JSONArray element(double d) {
        Double d2 = new Double(d);
        JSONUtils.testValidity(d2);
        return element((Object) d2);
    }

    public JSONArray element(int i) {
        return element((Object) new Integer(i));
    }

    public JSONArray element(int i, double d) {
        return element(i, (Object) new Double(d));
    }

    public JSONArray element(int i, int i2) {
        return element(i, (Object) new Integer(i2));
    }

    public JSONArray element(int i, long j) {
        return element(i, (Object) new Long(j));
    }

    public JSONArray element(int i, Object obj) {
        return element(i, obj, new JsonConfig());
    }

    public JSONArray element(int i, Object obj, JsonConfig jsonConfig) {
        JSONUtils.testValidity(obj);
        if (i < 0) {
            throw new JSONException("JSONArray[" + i + "] not found.");
        }
        if (i < size()) {
            this.elements.set(i, processValue(obj, jsonConfig));
        } else {
            while (i != size()) {
                element(JSONNull.getInstance());
            }
            element(obj, jsonConfig);
        }
        return this;
    }

    public JSONArray element(int i, String str) {
        return element(i, str, new JsonConfig());
    }

    public JSONArray element(int i, String str, JsonConfig jsonConfig) {
        if (i < 0) {
            throw new JSONException("JSONArray[" + i + "] not found.");
        }
        if (i >= size()) {
            while (i != size()) {
                element(JSONNull.getInstance());
            }
            element(str, jsonConfig);
        } else if (str == null) {
            this.elements.set(i, "");
        } else if (JSONUtils.mayBeJSON(str)) {
            try {
                this.elements.set(i, JSONSerializer.toJSON((Object) str, jsonConfig));
            } catch (JSONException e) {
                this.elements.set(i, JSONUtils.stripQuotes(str));
            }
        } else {
            this.elements.set(i, JSONUtils.stripQuotes(str));
        }
        return this;
    }

    public JSONArray element(int i, Collection collection) {
        return element(i, collection, new JsonConfig());
    }

    public JSONArray element(int i, Collection collection, JsonConfig jsonConfig) {
        if (!(collection instanceof JSONArray)) {
            return element(i, (Collection) _fromCollection(collection, jsonConfig));
        }
        if (i < 0) {
            throw new JSONException("JSONArray[" + i + "] not found.");
        } else if (i < size()) {
            this.elements.set(i, collection);
            return this;
        } else {
            while (i != size()) {
                element(JSONNull.getInstance());
            }
            element(collection, jsonConfig);
            return this;
        }
    }

    public JSONArray element(int i, Map map) {
        return element(i, map, new JsonConfig());
    }

    public JSONArray element(int i, Map map, JsonConfig jsonConfig) {
        if (!(map instanceof JSONObject)) {
            return element(i, (Map) JSONObject.fromObject(map, jsonConfig));
        }
        if (i < 0) {
            throw new JSONException("JSONArray[" + i + "] not found.");
        } else if (i < size()) {
            this.elements.set(i, map);
            return this;
        } else {
            while (i != size()) {
                element(JSONNull.getInstance());
            }
            element(map, jsonConfig);
            return this;
        }
    }

    public JSONArray element(int i, boolean z) {
        return element(i, (Object) z ? Boolean.TRUE : Boolean.FALSE);
    }

    public JSONArray element(long j) {
        return element((Object) JSONUtils.transformNumber(new Long(j)));
    }

    public JSONArray element(Object obj) {
        return element(obj, new JsonConfig());
    }

    public JSONArray element(Object obj, JsonConfig jsonConfig) {
        return addValue(obj, jsonConfig);
    }

    public JSONArray element(String str) {
        return element(str, new JsonConfig());
    }

    public JSONArray element(String str, JsonConfig jsonConfig) {
        if (str == null) {
            this.elements.add("");
        } else if (JSONUtils.mayBeJSON(str)) {
            try {
                this.elements.add(JSONSerializer.toJSON((Object) str, jsonConfig));
            } catch (JSONException e) {
                this.elements.add(JSONUtils.stripQuotes(str));
            }
        } else {
            this.elements.add(JSONUtils.stripQuotes(str));
        }
        return this;
    }

    public JSONArray element(Collection collection) {
        return element(collection, new JsonConfig());
    }

    public JSONArray element(Collection collection, JsonConfig jsonConfig) {
        if (!(collection instanceof JSONArray)) {
            return element((Collection) _fromCollection(collection, jsonConfig));
        }
        this.elements.add(collection);
        return this;
    }

    public JSONArray element(Map map) {
        return element(map, new JsonConfig());
    }

    public JSONArray element(Map map, JsonConfig jsonConfig) {
        if (!(map instanceof JSONObject)) {
            return element(JSONObject.fromObject(map, jsonConfig));
        }
        this.elements.add(map);
        return this;
    }

    public JSONArray element(JSONNull jSONNull) {
        this.elements.add(jSONNull);
        return this;
    }

    public JSONArray element(JSONObject jSONObject) {
        this.elements.add(jSONObject);
        return this;
    }

    public JSONArray element(boolean z) {
        return element((Object) z ? Boolean.TRUE : Boolean.FALSE);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof JSONArray)) {
            return false;
        }
        JSONArray jSONArray = (JSONArray) obj;
        if (jSONArray.size() != size()) {
            return false;
        }
        int size = size();
        for (int i = 0; i < size; i++) {
            Object obj2 = get(i);
            Object obj3 = jSONArray.get(i);
            if (JSONNull.getInstance().equals(obj2)) {
                if (!JSONNull.getInstance().equals(obj3)) {
                    return false;
                }
            } else if (JSONNull.getInstance().equals(obj3)) {
                return false;
            } else {
                if ((obj2 instanceof JSONArray) && (obj3 instanceof JSONArray)) {
                    if (!((JSONArray) obj3).equals((JSONArray) obj2)) {
                        return false;
                    }
                } else if (!(obj2 instanceof String) || !(obj3 instanceof JSONFunction)) {
                    if (!(obj2 instanceof JSONFunction) || !(obj3 instanceof String)) {
                        if (!(obj2 instanceof JSONObject) || !(obj3 instanceof JSONObject)) {
                            if (!(obj2 instanceof JSONArray) || !(obj3 instanceof JSONArray)) {
                                if (!(obj2 instanceof JSONFunction) || !(obj3 instanceof JSONFunction)) {
                                    if (obj2 instanceof String) {
                                        if (!obj2.equals(String.valueOf(obj3))) {
                                            return false;
                                        }
                                    } else if (!(obj3 instanceof String)) {
                                        IdentityObjectMorpher morpherFor = JSONUtils.getMorpherRegistry().getMorpherFor(obj2.getClass());
                                        IdentityObjectMorpher morpherFor2 = JSONUtils.getMorpherRegistry().getMorpherFor(obj3.getClass());
                                        if (morpherFor == null || morpherFor == IdentityObjectMorpher.getInstance()) {
                                            if (morpherFor2 == null || morpherFor2 == IdentityObjectMorpher.getInstance()) {
                                                if (!obj2.equals(obj3)) {
                                                    return false;
                                                }
                                            } else if (!JSONUtils.getMorpherRegistry().morph(obj2.getClass(), obj2).equals(obj3)) {
                                                return false;
                                            }
                                        } else if (!obj2.equals(JSONUtils.getMorpherRegistry().morph(obj2.getClass(), obj3))) {
                                            return false;
                                        }
                                    } else if (!obj3.equals(String.valueOf(obj2))) {
                                        return false;
                                    }
                                } else if (!obj2.equals(obj3)) {
                                    return false;
                                }
                            } else if (!obj2.equals(obj3)) {
                                return false;
                            }
                        } else if (!obj2.equals(obj3)) {
                            return false;
                        }
                    } else if (!obj3.equals(String.valueOf(obj2))) {
                        return false;
                    }
                } else if (!obj2.equals(String.valueOf(obj3))) {
                    return false;
                }
            }
        }
        return true;
    }

    public Object get(int i) {
        return this.elements.get(i);
    }

    public boolean getBoolean(int i) {
        Object obj = get(i);
        if (obj != null) {
            if (obj.equals(Boolean.FALSE) || ((obj instanceof String) && ((String) obj).equalsIgnoreCase("false"))) {
                return false;
            }
            if (obj.equals(Boolean.TRUE) || ((obj instanceof String) && ((String) obj).equalsIgnoreCase("true"))) {
                return true;
            }
        }
        throw new JSONException("JSONArray[" + i + "] is not a Boolean.");
    }

    public double getDouble(int i) {
        Object obj = get(i);
        if (obj != null) {
            try {
                return obj instanceof Number ? ((Number) obj).doubleValue() : Double.parseDouble((String) obj);
            } catch (Exception e) {
                throw new JSONException("JSONArray[" + i + "] is not a number.");
            }
        } else {
            throw new JSONException("JSONArray[" + i + "] is not a number.");
        }
    }

    public int getInt(int i) {
        Object obj = get(i);
        if (obj != null) {
            return obj instanceof Number ? ((Number) obj).intValue() : (int) getDouble(i);
        }
        throw new JSONException("JSONArray[" + i + "] is not a number.");
    }

    public JSONArray getJSONArray(int i) {
        Object obj = get(i);
        if (obj != null && (obj instanceof JSONArray)) {
            return (JSONArray) obj;
        }
        throw new JSONException("JSONArray[" + i + "] is not a JSONArray.");
    }

    public JSONObject getJSONObject(int i) {
        Object obj = get(i);
        if (JSONNull.getInstance().equals(obj)) {
            return new JSONObject(true);
        }
        if (obj instanceof JSONObject) {
            return (JSONObject) obj;
        }
        throw new JSONException("JSONArray[" + i + "] is not a JSONObject.");
    }

    public long getLong(int i) {
        Object obj = get(i);
        if (obj != null) {
            return obj instanceof Number ? ((Number) obj).longValue() : (long) getDouble(i);
        }
        throw new JSONException("JSONArray[" + i + "] is not a number.");
    }

    public String getString(int i) {
        Object obj = get(i);
        if (obj != null) {
            return obj.toString();
        }
        throw new JSONException("JSONArray[" + i + "] not found.");
    }

    public int hashCode() {
        int i = 29;
        for (Object hashCode : this.elements) {
            i += JSONUtils.hashCode(hashCode);
        }
        return i;
    }

    public int indexOf(Object obj) {
        return this.elements.indexOf(obj);
    }

    public boolean isArray() {
        return true;
    }

    public boolean isEmpty() {
        return this.elements.isEmpty();
    }

    public boolean isExpandElements() {
        return this.expandElements;
    }

    public Iterator iterator() {
        return new JSONArrayListIterator();
    }

    public String join(String str) {
        return join(str, false);
    }

    public String join(String str, boolean z) {
        int size = size();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                stringBuffer.append(str);
            }
            String valueToString = JSONUtils.valueToString(this.elements.get(i));
            if (z) {
                valueToString = JSONUtils.stripQuotes(valueToString);
            }
            stringBuffer.append(valueToString);
        }
        return stringBuffer.toString();
    }

    public int lastIndexOf(Object obj) {
        return this.elements.lastIndexOf(obj);
    }

    public ListIterator listIterator() {
        return listIterator(0);
    }

    public ListIterator listIterator(int i) {
        if (i >= 0 && i <= size()) {
            return new JSONArrayListIterator(i);
        }
        throw new IndexOutOfBoundsException("Index: " + i);
    }

    public Object opt(int i) {
        if (i < 0 || i >= size()) {
            return null;
        }
        return this.elements.get(i);
    }

    public boolean optBoolean(int i) {
        return optBoolean(i, false);
    }

    public boolean optBoolean(int i, boolean z) {
        try {
            return getBoolean(i);
        } catch (Exception e) {
            return z;
        }
    }

    public double optDouble(int i) {
        return optDouble(i, Double.NaN);
    }

    public double optDouble(int i, double d) {
        try {
            return getDouble(i);
        } catch (Exception e) {
            return d;
        }
    }

    public int optInt(int i) {
        return optInt(i, 0);
    }

    public int optInt(int i, int i2) {
        try {
            return getInt(i);
        } catch (Exception e) {
            return i2;
        }
    }

    public JSONArray optJSONArray(int i) {
        Object opt = opt(i);
        if (opt instanceof JSONArray) {
            return (JSONArray) opt;
        }
        return null;
    }

    public JSONObject optJSONObject(int i) {
        Object opt = opt(i);
        if (opt instanceof JSONObject) {
            return (JSONObject) opt;
        }
        return null;
    }

    public long optLong(int i) {
        return optLong(i, 0);
    }

    public long optLong(int i, long j) {
        try {
            return getLong(i);
        } catch (Exception e) {
            return j;
        }
    }

    public String optString(int i) {
        return optString(i, "");
    }

    public String optString(int i, String str) {
        Object opt = opt(i);
        return opt != null ? opt.toString() : str;
    }

    public Object remove(int i) {
        return this.elements.remove(i);
    }

    public boolean remove(Object obj) {
        return this.elements.remove(obj);
    }

    public boolean removeAll(Collection collection) {
        return removeAll(collection, new JsonConfig());
    }

    public boolean removeAll(Collection collection, JsonConfig jsonConfig) {
        return this.elements.removeAll(fromObject(collection, jsonConfig));
    }

    public boolean retainAll(Collection collection) {
        return retainAll(collection, new JsonConfig());
    }

    public boolean retainAll(Collection collection, JsonConfig jsonConfig) {
        return this.elements.retainAll(fromObject(collection, jsonConfig));
    }

    public Object set(int i, Object obj) {
        return set(i, obj, new JsonConfig());
    }

    public Object set(int i, Object obj, JsonConfig jsonConfig) {
        Object obj2 = get(i);
        element(i, obj, jsonConfig);
        return obj2;
    }

    public void setExpandElements(boolean z) {
        this.expandElements = z;
    }

    public int size() {
        return this.elements.size();
    }

    public List subList(int i, int i2) {
        return this.elements.subList(i, i2);
    }

    public Object[] toArray() {
        return this.elements.toArray();
    }

    public Object[] toArray(Object[] objArr) {
        return this.elements.toArray(objArr);
    }

    public JSONObject toJSONObject(JSONArray jSONArray) {
        if (jSONArray == null || jSONArray.size() == 0 || size() == 0) {
            return null;
        }
        JSONObject jSONObject = new JSONObject();
        for (int i = 0; i < jSONArray.size(); i++) {
            jSONObject.element(jSONArray.getString(i), opt(i));
        }
        return jSONObject;
    }

    public String toString() {
        try {
            return '[' + join(",") + ']';
        } catch (Exception e) {
            return null;
        }
    }

    public String toString(int i) {
        return i == 0 ? toString() : toString(i, 0);
    }

    public String toString(int i, int i2) {
        int size = size();
        if (size == 0) {
            return "[]";
        }
        if (i == 0) {
            return toString();
        }
        StringBuffer stringBuffer = new StringBuffer("[");
        if (size == 1) {
            stringBuffer.append(JSONUtils.valueToString(this.elements.get(0), i, i2));
        } else {
            int i3 = i2 + i;
            stringBuffer.append(10);
            for (int i4 = 0; i4 < size; i4++) {
                if (i4 > 0) {
                    stringBuffer.append(",\n");
                }
                for (int i5 = 0; i5 < i3; i5++) {
                    stringBuffer.append(' ');
                }
                stringBuffer.append(JSONUtils.valueToString(this.elements.get(i4), i, i3));
            }
            stringBuffer.append(10);
            for (int i6 = 0; i6 < i2; i6++) {
                stringBuffer.append(' ');
            }
            for (int i7 = 0; i7 < i2; i7++) {
                stringBuffer.insert(0, ' ');
            }
        }
        stringBuffer.append(']');
        return stringBuffer.toString();
    }

    public Writer write(Writer writer) {
        boolean z = false;
        try {
            int size = size();
            writer.write(91);
            int i = 0;
            while (i < size) {
                if (z) {
                    writer.write(44);
                }
                Object obj = this.elements.get(i);
                if (obj instanceof JSONObject) {
                    ((JSONObject) obj).write(writer);
                } else if (obj instanceof JSONArray) {
                    ((JSONArray) obj).write(writer);
                } else {
                    writer.write(JSONUtils.valueToString(obj));
                }
                i++;
                z = true;
            }
            writer.write(93);
            return writer;
        } catch (IOException e) {
            throw new JSONException((Throwable) e);
        }
    }
}
