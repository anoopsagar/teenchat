package net.sf.json;

import net.sf.json.util.JSONTokener;
import net.sf.json.util.JSONUtils;

public class JSONSerializer {
    public static JSON toJSON(Object obj) {
        return toJSON(obj, new JsonConfig());
    }

    public static JSON toJSON(Object obj, JsonConfig jsonConfig) {
        if (obj == null) {
            return JSONNull.getInstance();
        }
        if (obj instanceof JSONString) {
            return toJSON((JSONString) obj, jsonConfig);
        }
        if (obj instanceof String) {
            return toJSON((String) obj, jsonConfig);
        }
        if (JSONUtils.isArray(obj)) {
            return JSONArray.fromObject(obj, jsonConfig);
        }
        try {
            return JSONObject.fromObject(obj, jsonConfig);
        } catch (JSONException e) {
            if (obj instanceof JSONTokener) {
                ((JSONTokener) obj).reset();
            }
            return JSONArray.fromObject(obj, jsonConfig);
        }
    }

    private static JSON toJSON(String str, JsonConfig jsonConfig) {
        if (str.startsWith("[")) {
            return JSONArray.fromObject(str, jsonConfig);
        }
        if (str.startsWith("{")) {
            return JSONObject.fromObject(str, jsonConfig);
        }
        if ("null".equals(str)) {
            return JSONNull.getInstance();
        }
        throw new JSONException("Invalid JSON String");
    }

    private static JSON toJSON(JSONString jSONString, JsonConfig jsonConfig) {
        return toJSON(jSONString.toJSONString(), jsonConfig);
    }

    public static Object toJava(JSON json) {
        return toJava(json, new JsonConfig());
    }

    public static Object toJava(JSON json, JsonConfig jsonConfig) {
        if (JSONUtils.isNull(json)) {
            return null;
        }
        return json instanceof JSONArray ? jsonConfig.getArrayMode() == 2 ? JSONArray.toArray((JSONArray) json, jsonConfig) : JSONArray.toCollection((JSONArray) json, jsonConfig) : JSONObject.toBean((JSONObject) json, jsonConfig);
    }
}
