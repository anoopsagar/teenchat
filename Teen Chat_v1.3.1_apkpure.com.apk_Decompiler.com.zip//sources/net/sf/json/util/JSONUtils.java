package net.sf.json.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.sf.ezmorph.MorphUtils;
import net.sf.ezmorph.MorpherRegistry;
import net.sf.ezmorph.bean.MorphDynaBean;
import net.sf.ezmorph.bean.MorphDynaClass;
import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONFunction;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;
import net.sf.json.JSONString;
import net.sf.json.JsonConfig;
import net.sf.json.regexp.RegexpMatcher;
import net.sf.json.regexp.RegexpUtils;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.io.IOUtils;

public final class JSONUtils {
    public static final String DOUBLE_QUOTE = "\"";
    private static RegexpMatcher FUNCTION_BODY_MATCHER = RegexpUtils.getMatcher(FUNCTION_BODY_PATTERN);
    private static final String FUNCTION_BODY_PATTERN = "^function[ ]?\\(.*?\\)[ \n\t]*\\{(.*?)\\}$";
    private static RegexpMatcher FUNCTION_HEADER_MATCHER = RegexpUtils.getMatcher(FUNCTION_HEADER_PATTERN);
    private static final String FUNCTION_HEADER_PATTERN = "^function[ ]?\\(.*?\\)$";
    private static RegexpMatcher FUNCTION_MACTHER = RegexpUtils.getMatcher(FUNCTION_PATTERN, true);
    private static RegexpMatcher FUNCTION_PARAMS_MATCHER = RegexpUtils.getMatcher(FUNCTION_PARAMS_PATTERN);
    private static final String FUNCTION_PARAMS_PATTERN = "^function[ ]?\\((.*?)\\).*";
    private static final String FUNCTION_PATTERN = "^function[ ]?\\(.*?\\)[ \n\t]*\\{.*?\\}$";
    private static final String FUNCTION_PREFIX = "function";
    public static final String SINGLE_QUOTE = "'";
    private static final MorpherRegistry morpherRegistry = new MorpherRegistry();

    static {
        MorphUtils.registerStandardMorphers(morpherRegistry);
    }

    private JSONUtils() {
    }

    public static String convertToJavaIdentifier(String str) {
        return convertToJavaIdentifier(str, new JsonConfig());
    }

    public static String convertToJavaIdentifier(String str, JsonConfig jsonConfig) {
        try {
            return jsonConfig.getJavaIdentifierTransformer().transformToJavaIdentifier(str);
        } catch (JSONException e) {
            throw e;
        } catch (Exception e2) {
            throw new JSONException((Throwable) e2);
        }
    }

    public static String doubleToString(double d) {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            return "null";
        }
        String d2 = Double.toString(d);
        if (d2.indexOf(46) <= 0 || d2.indexOf(101) >= 0 || d2.indexOf(69) >= 0) {
            return d2;
        }
        while (d2.endsWith("0")) {
            d2 = d2.substring(0, d2.length() - 1);
        }
        return d2.endsWith(".") ? d2.substring(0, d2.length() - 1) : d2;
    }

    public static String getFunctionBody(String str) {
        return FUNCTION_BODY_MATCHER.getGroupIfMatches(str, 1);
    }

    public static String getFunctionParams(String str) {
        return FUNCTION_PARAMS_MATCHER.getGroupIfMatches(str, 1);
    }

    public static Class getInnerComponentType(Class cls) {
        return !cls.isArray() ? cls : getInnerComponentType(cls.getComponentType());
    }

    public static MorpherRegistry getMorpherRegistry() {
        return morpherRegistry;
    }

    public static Map getProperties(JSONObject jSONObject) {
        HashMap hashMap = new HashMap();
        Iterator keys = jSONObject.keys();
        while (keys.hasNext()) {
            String str = (String) keys.next();
            hashMap.put(str, getTypeClass(jSONObject.get(str)));
        }
        return hashMap;
    }

    public static Class getTypeClass(Object obj) {
        if (isNull(obj)) {
            return Object.class;
        }
        if (isArray(obj)) {
            return List.class;
        }
        if (isFunction(obj)) {
            return JSONFunction.class;
        }
        if (isBoolean(obj)) {
            return Boolean.class;
        }
        if (isNumber(obj)) {
            Number number = (Number) obj;
            if (isInteger(number)) {
                return Integer.class;
            }
            if (isLong(number)) {
                return Long.class;
            }
            if (isFloat(number)) {
                return Float.class;
            }
            if (isBigInteger(number)) {
                return BigInteger.class;
            }
            if (isBigDecimal(number)) {
                return BigDecimal.class;
            }
            if (isDouble(number)) {
                return Double.class;
            }
            throw new JSONException("Unsupported type");
        } else if (isString(obj)) {
            return String.class;
        } else {
            if (isObject(obj)) {
                return Object.class;
            }
            throw new JSONException("Unsupported type");
        }
    }

    public static int hashCode(Object obj) {
        return obj == null ? JSONNull.getInstance().hashCode() : ((obj instanceof JSON) || (obj instanceof String) || (obj instanceof JSONFunction)) ? obj.hashCode() : String.valueOf(obj).hashCode();
    }

    public static boolean isArray(Class cls) {
        return cls != null && (cls.isArray() || Collection.class.isAssignableFrom(cls) || JSONArray.class.isAssignableFrom(cls));
    }

    public static boolean isArray(Object obj) {
        return (obj != null && obj.getClass().isArray()) || (obj instanceof Collection) || (obj instanceof JSONArray);
    }

    private static boolean isBigDecimal(Number number) {
        if (number instanceof BigDecimal) {
            return true;
        }
        try {
            new BigDecimal(String.valueOf(number));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isBigInteger(Number number) {
        if (number instanceof BigInteger) {
            return true;
        }
        try {
            new BigInteger(String.valueOf(number));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isBoolean(Class cls) {
        return cls != null && (Boolean.TYPE.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls));
    }

    public static boolean isBoolean(Object obj) {
        return (obj instanceof Boolean) || (obj != null && obj.getClass() == Boolean.TYPE);
    }

    public static boolean isDouble(Class cls) {
        return cls != null && (Double.TYPE.isAssignableFrom(cls) || Double.class.isAssignableFrom(cls));
    }

    private static boolean isDouble(Number number) {
        if (number instanceof Double) {
            return true;
        }
        try {
            return !Double.isInfinite(Double.parseDouble(String.valueOf(number)));
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isFloat(Number number) {
        if (number instanceof Float) {
            return true;
        }
        try {
            return !Float.isInfinite(Float.parseFloat(String.valueOf(number)));
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isFunction(Object obj) {
        if (!(obj instanceof String)) {
            return obj instanceof JSONFunction;
        }
        String str = (String) obj;
        return str.startsWith("function") && FUNCTION_MACTHER.matches(str);
    }

    public static boolean isFunctionHeader(Object obj) {
        if (!(obj instanceof String)) {
            return false;
        }
        String str = (String) obj;
        return str.startsWith("function") && FUNCTION_HEADER_MATCHER.matches(str);
    }

    private static boolean isInteger(Number number) {
        if (number instanceof Integer) {
            return true;
        }
        try {
            Integer.parseInt(String.valueOf(number));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isJavaIdentifier(String str) {
        if (str.length() == 0 || !Character.isJavaIdentifierStart(str.charAt(0))) {
            return false;
        }
        for (int i = 1; i < str.length(); i++) {
            if (!Character.isJavaIdentifierPart(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isLong(Number number) {
        if (number instanceof Long) {
            return true;
        }
        try {
            Long.parseLong(String.valueOf(number));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isNull(Object obj) {
        return obj instanceof JSONObject ? ((JSONObject) obj).isNullObject() : JSONNull.getInstance().equals(obj);
    }

    public static boolean isNumber(Class cls) {
        return cls != null && (Byte.TYPE.isAssignableFrom(cls) || Short.TYPE.isAssignableFrom(cls) || Integer.TYPE.isAssignableFrom(cls) || Long.TYPE.isAssignableFrom(cls) || Float.TYPE.isAssignableFrom(cls) || Double.TYPE.isAssignableFrom(cls) || Number.class.isAssignableFrom(cls));
    }

    public static boolean isNumber(Object obj) {
        if ((obj == null || obj.getClass() != Byte.TYPE) && ((obj == null || obj.getClass() != Short.TYPE) && ((obj == null || obj.getClass() != Integer.TYPE) && ((obj == null || obj.getClass() != Long.TYPE) && ((obj == null || obj.getClass() != Float.TYPE) && (obj == null || obj.getClass() != Double.TYPE)))))) {
            return obj instanceof Number;
        }
        return true;
    }

    public static boolean isObject(Object obj) {
        return (!isNumber(obj) && !isString(obj) && !isBoolean(obj) && !isArray(obj) && !isFunction(obj)) || isNull(obj);
    }

    public static boolean isString(Class cls) {
        return cls != null && (String.class.isAssignableFrom(cls) || Character.TYPE.isAssignableFrom(cls) || Character.class.isAssignableFrom(cls));
    }

    public static boolean isString(Object obj) {
        return (obj instanceof String) || (obj instanceof Character) || (obj != null && (obj.getClass() == Character.TYPE || String.class.isAssignableFrom(obj.getClass())));
    }

    public static boolean mayBeJSON(String str) {
        return str != null && ("null".equals(str) || ((str.startsWith("[") && str.endsWith("]")) || (str.startsWith("{") && str.endsWith("}"))));
    }

    public static DynaBean newDynaBean(JSONObject jSONObject) {
        return newDynaBean(jSONObject, new JsonConfig());
    }

    public static DynaBean newDynaBean(JSONObject jSONObject, JsonConfig jsonConfig) {
        Map properties = getProperties(jSONObject);
        for (Map.Entry key : properties.entrySet()) {
            String str = (String) key.getKey();
            if (!isJavaIdentifier(str)) {
                String convertToJavaIdentifier = convertToJavaIdentifier(str, jsonConfig);
                if (convertToJavaIdentifier.compareTo(str) != 0) {
                    properties.put(convertToJavaIdentifier, properties.remove(str));
                }
            }
        }
        MorphDynaClass morphDynaClass = new MorphDynaClass(properties);
        try {
            MorphDynaBean newInstance = morphDynaClass.newInstance();
            newInstance.setDynaBeanClass(morphDynaClass);
            return newInstance;
        } catch (Exception e) {
            throw new JSONException((Throwable) e);
        }
    }

    public static String numberToString(Number number) {
        if (number == null) {
            throw new JSONException("Null pointer");
        }
        testValidity(number);
        String obj = number.toString();
        if (obj.indexOf(46) <= 0 || obj.indexOf(101) >= 0 || obj.indexOf(69) >= 0) {
            return obj;
        }
        while (obj.endsWith("0")) {
            obj = obj.substring(0, obj.length() - 1);
        }
        return obj.endsWith(".") ? obj.substring(0, obj.length() - 1) : obj;
    }

    public static String quote(String str) {
        if (isFunction(str)) {
            return str;
        }
        if (str == null || str.length() == 0) {
            return "\"\"";
        }
        int length = str.length();
        StringBuilder sb = new StringBuilder(length * 2);
        char[] charArray = str.toCharArray();
        char[] cArr = new char[1030];
        sb.append('\"');
        int i = 0;
        int i2 = 0;
        char c = 0;
        while (i2 < length) {
            if (i > 1024) {
                sb.append(cArr, 0, i);
                i = 0;
            }
            char c2 = charArray[i2];
            switch (c2) {
                case '\"':
                case '\\':
                    int i3 = i + 1;
                    cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                    i = i3 + 1;
                    cArr[i3] = c2;
                    break;
                case '/':
                    if (c == '<') {
                        cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                        i++;
                    }
                    cArr[i] = c2;
                    i++;
                    break;
                default:
                    if (c2 >= ' ') {
                        cArr[i] = c2;
                        i++;
                        break;
                    } else {
                        switch (c2) {
                            case 8:
                                int i4 = i + 1;
                                cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                                i = i4 + 1;
                                cArr[i4] = 'b';
                                break;
                            case 9:
                                int i5 = i + 1;
                                cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                                i = i5 + 1;
                                cArr[i5] = 't';
                                break;
                            case 10:
                                int i6 = i + 1;
                                cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                                i = i6 + 1;
                                cArr[i6] = 'n';
                                break;
                            case 12:
                                int i7 = i + 1;
                                cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                                i = i7 + 1;
                                cArr[i7] = 'f';
                                break;
                            case 13:
                                int i8 = i + 1;
                                cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                                i = i8 + 1;
                                cArr[i8] = 'r';
                                break;
                            default:
                                String str2 = "000" + Integer.toHexString(c2);
                                int length2 = str2.length();
                                int i9 = i + 1;
                                cArr[i] = IOUtils.DIR_SEPARATOR_WINDOWS;
                                int i10 = i9 + 1;
                                cArr[i9] = 'u';
                                int i11 = i10 + 1;
                                cArr[i10] = str2.charAt(length2 - 4);
                                int i12 = i11 + 1;
                                cArr[i11] = str2.charAt(length2 - 3);
                                int i13 = i12 + 1;
                                cArr[i12] = str2.charAt(length2 - 2);
                                i = i13 + 1;
                                cArr[i13] = str2.charAt(length2 - 1);
                                break;
                        }
                    }
            }
            i2++;
            c = c2;
        }
        sb.append(cArr, 0, i);
        sb.append('\"');
        return sb.toString();
    }

    public static String stripQuotes(String str) {
        return str.length() < 2 ? str : (!str.startsWith(SINGLE_QUOTE) || !str.endsWith(SINGLE_QUOTE)) ? (!str.startsWith(DOUBLE_QUOTE) || !str.endsWith(DOUBLE_QUOTE)) ? str : str.substring(1, str.length() - 1) : str.substring(1, str.length() - 1);
    }

    public static void testValidity(Object obj) {
        if (obj == null) {
            return;
        }
        if (obj instanceof Double) {
            if (((Double) obj).isInfinite() || ((Double) obj).isNaN()) {
                throw new JSONException("JSON does not allow non-finite numbers");
            }
        } else if (!(obj instanceof Float)) {
            if ((obj instanceof BigDecimal) || (obj instanceof BigInteger)) {
            }
        } else if (((Float) obj).isInfinite() || ((Float) obj).isNaN()) {
            throw new JSONException("JSON does not allow non-finite numbers.");
        }
    }

    public static Number transformNumber(Number number) {
        if (number instanceof Float) {
            return new Double(number.doubleValue());
        }
        if (number instanceof Short) {
            return new Integer(number.intValue());
        }
        if (number instanceof Byte) {
            return new Integer(number.intValue());
        }
        if (!(number instanceof Long)) {
            return number;
        }
        return (number.longValue() > new Long(2147483647L).longValue() || number.longValue() < -2147483648L) ? number : new Integer(number.intValue());
    }

    public static String valueToString(Object obj) {
        if (obj == null || isNull(obj)) {
            return "null";
        }
        if (obj instanceof JSONFunction) {
            return ((JSONFunction) obj).toString();
        }
        if (!(obj instanceof JSONString)) {
            return obj instanceof Number ? numberToString((Number) obj) : ((obj instanceof Boolean) || (obj instanceof JSONObject) || (obj instanceof JSONArray)) ? obj.toString() : quote(obj.toString());
        }
        try {
            String jSONString = ((JSONString) obj).toJSONString();
            if (jSONString instanceof String) {
                return jSONString;
            }
            throw new JSONException("Bad value from toJSONString: " + jSONString);
        } catch (Exception e) {
            throw new JSONException((Throwable) e);
        }
    }

    public static String valueToString(Object obj, int i, int i2) {
        return (obj == null || isNull(obj)) ? "null" : obj instanceof JSONFunction ? ((JSONFunction) obj).toString() : obj instanceof JSONString ? ((JSONString) obj).toJSONString() : obj instanceof Number ? numberToString((Number) obj) : obj instanceof Boolean ? obj.toString() : obj instanceof JSONObject ? ((JSONObject) obj).toString(i, i2) : obj instanceof JSONArray ? ((JSONArray) obj).toString(i, i2) : quote(obj.toString());
    }
}
