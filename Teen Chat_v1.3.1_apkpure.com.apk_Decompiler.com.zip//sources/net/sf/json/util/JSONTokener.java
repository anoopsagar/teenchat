package net.sf.json.util;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.regexp.RegexpUtils;
import org.apache.commons.lang.CharUtils;

public class JSONTokener {
    private int myIndex = 0;
    private String mySource;

    public JSONTokener(String str) {
        String trim = str != null ? str.trim() : "";
        if (trim.length() > 0) {
            char charAt = trim.charAt(0);
            char charAt2 = trim.charAt(trim.length() - 1);
            if (charAt == '[' && charAt2 != ']') {
                throw syntaxError("Found starting '[' but missing ']' at the end.");
            } else if (charAt == '{' && charAt2 != '}') {
                throw syntaxError("Found starting '{' but missing '}' at the end.");
            }
        }
        this.mySource = trim;
    }

    public static int dehexchar(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        }
        if (c >= 'A' && c <= 'F') {
            return c - '7';
        }
        if (c < 'a' || c > 'f') {
            return -1;
        }
        return c - 'W';
    }

    public void back() {
        if (this.myIndex > 0) {
            this.myIndex--;
        }
    }

    public int length() {
        if (this.mySource == null) {
            return 0;
        }
        return this.mySource.length();
    }

    public boolean matches(String str) {
        return RegexpUtils.getMatcher(str).matches(this.mySource.substring(this.myIndex));
    }

    public boolean more() {
        return this.myIndex < this.mySource.length();
    }

    public char next() {
        if (!more()) {
            return 0;
        }
        char charAt = this.mySource.charAt(this.myIndex);
        this.myIndex++;
        return charAt;
    }

    public char next(char c) {
        char next = next();
        if (next == c) {
            return next;
        }
        throw syntaxError(new StringBuffer().append("Expected '").append(c).append("' and instead saw '").append(next).append("'.").toString());
    }

    public String next(int i) {
        int i2 = this.myIndex;
        int i3 = i2 + i;
        if (i3 >= this.mySource.length()) {
            throw syntaxError("Substring bounds error");
        }
        this.myIndex += i;
        return this.mySource.substring(i2, i3);
    }

    /* JADX WARNING: CFG modification limit reached, blocks count: 142 */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0006, code lost:
        continue;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x001b, code lost:
        if (r1 == 10) goto L_0x0006;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x001d, code lost:
        if (r1 == 13) goto L_0x0006;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public char nextClean() {
        /*
            r5 = this;
            r4 = 13
            r3 = 10
            r0 = 47
        L_0x0006:
            char r1 = r5.next()
            if (r1 != r0) goto L_0x003d
            char r1 = r5.next()
            switch(r1) {
                case 42: goto L_0x0025;
                case 47: goto L_0x0017;
                default: goto L_0x0013;
            }
        L_0x0013:
            r5.back()
        L_0x0016:
            return r0
        L_0x0017:
            char r1 = r5.next()
            if (r1 == r3) goto L_0x0006
            if (r1 == r4) goto L_0x0006
            if (r1 != 0) goto L_0x0017
            goto L_0x0006
        L_0x0022:
            r5.back()
        L_0x0025:
            char r1 = r5.next()
            if (r1 != 0) goto L_0x0032
            java.lang.String r0 = "Unclosed comment."
            net.sf.json.JSONException r0 = r5.syntaxError(r0)
            throw r0
        L_0x0032:
            r2 = 42
            if (r1 != r2) goto L_0x0025
            char r1 = r5.next()
            if (r1 != r0) goto L_0x0022
            goto L_0x0006
        L_0x003d:
            r2 = 35
            if (r1 != r2) goto L_0x004c
        L_0x0041:
            char r1 = r5.next()
            if (r1 == r3) goto L_0x0006
            if (r1 == r4) goto L_0x0006
            if (r1 != 0) goto L_0x0041
            goto L_0x0006
        L_0x004c:
            if (r1 == 0) goto L_0x0052
            r2 = 32
            if (r1 <= r2) goto L_0x0006
        L_0x0052:
            r0 = r1
            goto L_0x0016
        */
        throw new UnsupportedOperationException("Method not decompiled: net.sf.json.util.JSONTokener.nextClean():char");
    }

    public String nextString(char c) {
        StringBuffer stringBuffer = new StringBuffer();
        while (true) {
            char next = next();
            switch (next) {
                case 0:
                case 10:
                case 13:
                    throw syntaxError("Unterminated string");
                case '\\':
                    char next2 = next();
                    switch (next2) {
                        case 'b':
                            stringBuffer.append(8);
                            break;
                        case 'f':
                            stringBuffer.append(12);
                            break;
                        case 'n':
                            stringBuffer.append(10);
                            break;
                        case 'r':
                            stringBuffer.append(CharUtils.CR);
                            break;
                        case 't':
                            stringBuffer.append(9);
                            break;
                        case 'u':
                            stringBuffer.append((char) Integer.parseInt(next(4), 16));
                            break;
                        case 'x':
                            stringBuffer.append((char) Integer.parseInt(next(2), 16));
                            break;
                        default:
                            stringBuffer.append(next2);
                            break;
                    }
                default:
                    if (next != c) {
                        stringBuffer.append(next);
                        break;
                    } else {
                        return stringBuffer.toString();
                    }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:9:0x0017  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String nextTo(char r4) {
        /*
            r3 = this;
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
        L_0x0005:
            char r1 = r3.next()
            if (r1 == r4) goto L_0x0015
            if (r1 == 0) goto L_0x0015
            r2 = 10
            if (r1 == r2) goto L_0x0015
            r2 = 13
            if (r1 != r2) goto L_0x0023
        L_0x0015:
            if (r1 == 0) goto L_0x001a
            r3.back()
        L_0x001a:
            java.lang.String r0 = r0.toString()
            java.lang.String r0 = r0.trim()
            return r0
        L_0x0023:
            r0.append(r1)
            goto L_0x0005
        */
        throw new UnsupportedOperationException("Method not decompiled: net.sf.json.util.JSONTokener.nextTo(char):java.lang.String");
    }

    /* JADX WARNING: Removed duplicated region for block: B:9:0x001b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String nextTo(java.lang.String r4) {
        /*
            r3 = this;
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
        L_0x0005:
            char r1 = r3.next()
            int r2 = r4.indexOf(r1)
            if (r2 >= 0) goto L_0x0019
            if (r1 == 0) goto L_0x0019
            r2 = 10
            if (r1 == r2) goto L_0x0019
            r2 = 13
            if (r1 != r2) goto L_0x0027
        L_0x0019:
            if (r1 == 0) goto L_0x001e
            r3.back()
        L_0x001e:
            java.lang.String r0 = r0.toString()
            java.lang.String r0 = r0.trim()
            return r0
        L_0x0027:
            r0.append(r1)
            goto L_0x0005
        */
        throw new UnsupportedOperationException("Method not decompiled: net.sf.json.util.JSONTokener.nextTo(java.lang.String):java.lang.String");
    }

    public Object nextValue() {
        return nextValue(new JsonConfig());
    }

    public Object nextValue(JsonConfig jsonConfig) {
        char nextClean = nextClean();
        switch (nextClean) {
            case '\"':
            case '\'':
                return nextString(nextClean);
            case '[':
                back();
                return JSONArray.fromObject(this, jsonConfig);
            case '{':
                back();
                return JSONObject.fromObject(this, jsonConfig);
            default:
                StringBuffer stringBuffer = new StringBuffer();
                char c = nextClean;
                while (c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0) {
                    stringBuffer.append(c);
                    c = next();
                }
                back();
                String trim = stringBuffer.toString().trim();
                if (trim.equals("")) {
                    throw syntaxError("Missing value.");
                } else if (trim.equalsIgnoreCase("true")) {
                    return Boolean.TRUE;
                } else {
                    if (trim.equalsIgnoreCase("false")) {
                        return Boolean.FALSE;
                    }
                    if (trim.equals("null")) {
                        return JSONNull.getInstance();
                    }
                    if ((nextClean >= '0' && nextClean <= '9') || nextClean == '.' || nextClean == '-' || nextClean == '+') {
                        if (nextClean == '0') {
                            if (trim.length() <= 2 || !(trim.charAt(1) == 'x' || trim.charAt(1) == 'X')) {
                                try {
                                    return new Integer(Integer.parseInt(trim, 8));
                                } catch (Exception e) {
                                }
                            } else {
                                try {
                                    return new Integer(Integer.parseInt(trim.substring(2), 16));
                                } catch (Exception e2) {
                                }
                            }
                        }
                        try {
                            return new Integer(trim);
                        } catch (Exception e3) {
                            try {
                                return new Long(trim);
                            } catch (Exception e4) {
                                try {
                                    return new Double(trim);
                                } catch (Exception e5) {
                                    return trim;
                                }
                            }
                        }
                    } else if (JSONUtils.isFunctionHeader(trim) || JSONUtils.isFunction(trim)) {
                        return trim;
                    } else {
                        switch (peek()) {
                            case ',':
                            case '[':
                            case ']':
                            case '{':
                            case '}':
                                throw new JSONException(new StringBuffer().append("Unquotted string '").append(trim).append(JSONUtils.SINGLE_QUOTE).toString());
                            default:
                                return trim;
                        }
                    }
                }
        }
    }

    public char peek() {
        if (more()) {
            return this.mySource.charAt(this.myIndex);
        }
        return 0;
    }

    public void reset() {
        this.myIndex = 0;
    }

    public void skipPast(String str) {
        this.myIndex = this.mySource.indexOf(str, this.myIndex);
        if (this.myIndex < 0) {
            this.myIndex = this.mySource.length();
        } else {
            this.myIndex += str.length();
        }
    }

    public char skipTo(char c) {
        char next;
        int i = this.myIndex;
        while (true) {
            next = next();
            if (next != 0) {
                if (next == c) {
                    back();
                    break;
                }
            } else {
                this.myIndex = i;
                break;
            }
        }
        return next;
    }

    public JSONException syntaxError(String str) {
        return new JSONException(new StringBuffer().append(str).append(toString()).toString());
    }

    public String toString() {
        return new StringBuffer().append(" at character ").append(this.myIndex).append(" of ").append(this.mySource).toString();
    }
}
