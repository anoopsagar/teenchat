package net.sf.json.util;

public interface PropertyFilter {
    boolean apply(Object obj, String str, Object obj2);
}
