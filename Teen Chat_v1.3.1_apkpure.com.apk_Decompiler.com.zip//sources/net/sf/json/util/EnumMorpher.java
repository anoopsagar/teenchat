package net.sf.json.util;

import net.sf.ezmorph.ObjectMorpher;

public class EnumMorpher implements ObjectMorpher {
    private Class enumClass;

    public EnumMorpher(Class cls) {
        if (cls == null) {
            throw new IllegalArgumentException("enumClass is null");
        } else if (!Enum.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("enumClass is not an Enum class");
        } else {
            this.enumClass = cls;
        }
    }

    public Object morph(Object obj) {
        return obj == null ? this.enumClass.cast((Object) null) : Enum.valueOf(this.enumClass, String.valueOf(obj));
    }

    public Class morphsTo() {
        return this.enumClass;
    }

    public boolean supports(Class cls) {
        return String.class.isAssignableFrom(cls);
    }
}
