package net.sf.json.util;

import java.util.Map;
import net.sf.json.JSONException;
import org.apache.commons.beanutils.PropertyUtils;

public abstract class PropertySetStrategy {
    public static final PropertySetStrategy DEFAULT = new DefaultPropertySetStrategy((AnonymousClass1) null);

    /* renamed from: net.sf.json.util.PropertySetStrategy$1  reason: invalid class name */
    class AnonymousClass1 {
    }

    final class DefaultPropertySetStrategy extends PropertySetStrategy {
        private DefaultPropertySetStrategy() {
        }

        DefaultPropertySetStrategy(AnonymousClass1 r1) {
            this();
        }

        public void setProperty(Object obj, String str, Object obj2) {
            if (obj instanceof Map) {
                ((Map) obj).put(str, obj2);
                return;
            }
            try {
                PropertyUtils.setSimpleProperty(obj, str, obj2);
            } catch (Exception e) {
                throw new JSONException((Throwable) e);
            }
        }
    }

    public abstract void setProperty(Object obj, String str, Object obj2);
}
