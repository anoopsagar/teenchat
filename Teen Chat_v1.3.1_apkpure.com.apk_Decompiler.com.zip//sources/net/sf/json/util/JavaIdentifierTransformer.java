package net.sf.json.util;

import net.sf.json.JSONException;
import org.apache.commons.lang.StringUtils;

public abstract class JavaIdentifierTransformer {
    public static final JavaIdentifierTransformer CAMEL_CASE = new CamelCaseJavaIdentifierTransformer((AnonymousClass1) null);
    public static final JavaIdentifierTransformer NOOP = new NoopJavaIdentifierTransformer((AnonymousClass1) null);
    public static final JavaIdentifierTransformer STRICT = new StrictJavaIdentifierTransformer((AnonymousClass1) null);
    public static final JavaIdentifierTransformer UNDERSCORE = new UnderscoreJavaIdentifierTransformer((AnonymousClass1) null);
    public static final JavaIdentifierTransformer WHITESPACE = new WhiteSpaceJavaIdentifierTransformer((AnonymousClass1) null);

    /* renamed from: net.sf.json.util.JavaIdentifierTransformer$1  reason: invalid class name */
    class AnonymousClass1 {
    }

    final class CamelCaseJavaIdentifierTransformer extends JavaIdentifierTransformer {
        private CamelCaseJavaIdentifierTransformer() {
        }

        CamelCaseJavaIdentifierTransformer(AnonymousClass1 r1) {
            this();
        }

        public String transformToJavaIdentifier(String str) {
            if (str == null) {
                return null;
            }
            char[] charArray = shaveOffNonJavaIdentifierStartChars(str).toCharArray();
            StringBuffer stringBuffer = new StringBuffer();
            boolean z = false;
            for (int i = 0; i < charArray.length; i++) {
                if (!Character.isJavaIdentifierPart(charArray[i]) || Character.isWhitespace(charArray[i])) {
                    z = true;
                } else if (z) {
                    stringBuffer.append(Character.toUpperCase(charArray[i]));
                    z = false;
                } else {
                    stringBuffer.append(charArray[i]);
                }
            }
            return stringBuffer.toString();
        }
    }

    final class NoopJavaIdentifierTransformer extends JavaIdentifierTransformer {
        private NoopJavaIdentifierTransformer() {
        }

        NoopJavaIdentifierTransformer(AnonymousClass1 r1) {
            this();
        }

        public String transformToJavaIdentifier(String str) {
            return str;
        }
    }

    final class StrictJavaIdentifierTransformer extends JavaIdentifierTransformer {
        private StrictJavaIdentifierTransformer() {
        }

        StrictJavaIdentifierTransformer(AnonymousClass1 r1) {
            this();
        }

        public String transformToJavaIdentifier(String str) {
            throw new JSONException(new StringBuffer().append(JSONUtils.SINGLE_QUOTE).append(str).append("' is not a valid Java identifier.").toString());
        }
    }

    final class UnderscoreJavaIdentifierTransformer extends JavaIdentifierTransformer {
        private UnderscoreJavaIdentifierTransformer() {
        }

        UnderscoreJavaIdentifierTransformer(AnonymousClass1 r1) {
            this();
        }

        public String transformToJavaIdentifier(String str) {
            if (str == null) {
                return null;
            }
            char[] charArray = shaveOffNonJavaIdentifierStartChars(str).toCharArray();
            StringBuffer stringBuffer = new StringBuffer();
            boolean z = false;
            for (int i = 0; i < charArray.length; i++) {
                if (!Character.isJavaIdentifierPart(charArray[i]) || Character.isWhitespace(charArray[i])) {
                    z = true;
                } else {
                    if (z) {
                        stringBuffer.append("_");
                        z = false;
                    }
                    stringBuffer.append(charArray[i]);
                }
            }
            if (stringBuffer.charAt(stringBuffer.length() - 1) == '_') {
                stringBuffer.deleteCharAt(stringBuffer.length() - 1);
            }
            return stringBuffer.toString();
        }
    }

    final class WhiteSpaceJavaIdentifierTransformer extends JavaIdentifierTransformer {
        private WhiteSpaceJavaIdentifierTransformer() {
        }

        WhiteSpaceJavaIdentifierTransformer(AnonymousClass1 r1) {
            this();
        }

        public String transformToJavaIdentifier(String str) {
            if (str == null) {
                return null;
            }
            char[] charArray = StringUtils.deleteWhitespace(shaveOffNonJavaIdentifierStartChars(str)).toCharArray();
            StringBuffer stringBuffer = new StringBuffer();
            for (int i = 0; i < charArray.length; i++) {
                if (Character.isJavaIdentifierPart(charArray[i])) {
                    stringBuffer.append(charArray[i]);
                }
            }
            return stringBuffer.toString();
        }
    }

    /* access modifiers changed from: protected */
    public final String shaveOffNonJavaIdentifierStartChars(String str) {
        boolean z = false;
        String str2 = str;
        while (!z) {
            if (!Character.isJavaIdentifierStart(str2.charAt(0))) {
                str2 = str2.substring(1);
                if (str2.length() == 0) {
                    throw new JSONException(new StringBuffer().append("Can't convert '").append(str).append("' to a valid Java identifier").toString());
                }
            } else {
                z = true;
            }
        }
        return str2;
    }

    public abstract String transformToJavaIdentifier(String str);
}
