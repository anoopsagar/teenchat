package net.sf.json.util;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

public abstract class CycleDetectionStrategy {
    public static final JSONArray IGNORE_PROPERTY_ARR = new JSONArray();
    public static final JSONObject IGNORE_PROPERTY_OBJ = new JSONObject();
    public static final CycleDetectionStrategy LENIENT = new LenientCycleDetectionStrategy((AnonymousClass1) null);
    public static final CycleDetectionStrategy NOPROP = new LenientNoRefCycleDetectionStrategy((AnonymousClass1) null);
    public static final CycleDetectionStrategy STRICT = new StrictCycleDetectionStrategy((AnonymousClass1) null);

    /* renamed from: net.sf.json.util.CycleDetectionStrategy$1  reason: invalid class name */
    class AnonymousClass1 {
    }

    final class LenientCycleDetectionStrategy extends CycleDetectionStrategy {
        private LenientCycleDetectionStrategy() {
        }

        LenientCycleDetectionStrategy(AnonymousClass1 r1) {
            this();
        }

        public JSONArray handleRepeatedReferenceAsArray(Object obj) {
            return new JSONArray();
        }

        public JSONObject handleRepeatedReferenceAsObject(Object obj) {
            return new JSONObject(true);
        }
    }

    final class LenientNoRefCycleDetectionStrategy extends CycleDetectionStrategy {
        private LenientNoRefCycleDetectionStrategy() {
        }

        LenientNoRefCycleDetectionStrategy(AnonymousClass1 r1) {
            this();
        }

        public JSONArray handleRepeatedReferenceAsArray(Object obj) {
            return CycleDetectionStrategy.IGNORE_PROPERTY_ARR;
        }

        public JSONObject handleRepeatedReferenceAsObject(Object obj) {
            return CycleDetectionStrategy.IGNORE_PROPERTY_OBJ;
        }
    }

    final class StrictCycleDetectionStrategy extends CycleDetectionStrategy {
        private StrictCycleDetectionStrategy() {
        }

        StrictCycleDetectionStrategy(AnonymousClass1 r1) {
            this();
        }

        public JSONArray handleRepeatedReferenceAsArray(Object obj) {
            throw new JSONException("There is a cycle in the hierarchy!");
        }

        public JSONObject handleRepeatedReferenceAsObject(Object obj) {
            throw new JSONException("There is a cycle in the hierarchy!");
        }
    }

    public abstract JSONArray handleRepeatedReferenceAsArray(Object obj);

    public abstract JSONObject handleRepeatedReferenceAsObject(Object obj);
}
