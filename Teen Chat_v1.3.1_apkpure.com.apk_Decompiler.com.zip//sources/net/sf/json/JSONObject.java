package net.sf.json;

import com.smartfoxserver.v2.protocol.serialization.DefaultObjectDumpFormatter;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.Writer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.ezmorph.array.ObjectArrayMorpher;
import net.sf.ezmorph.bean.BeanMorpher;
import net.sf.ezmorph.object.IdentityObjectMorpher;
import net.sf.json.processors.JsonBeanProcessor;
import net.sf.json.processors.JsonValueProcessor;
import net.sf.json.processors.JsonVerifier;
import net.sf.json.processors.PropertyNameProcessor;
import net.sf.json.regexp.RegexpUtils;
import net.sf.json.util.CycleDetectionStrategy;
import net.sf.json.util.EnumMorpher;
import net.sf.json.util.JSONTokener;
import net.sf.json.util.JSONUtils;
import net.sf.json.util.PropertyFilter;
import net.sf.json.util.PropertySetStrategy;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.map.ListOrderedMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class JSONObject extends AbstractJSON implements Comparable, Map, JSON {
    private static final Log log = LogFactory.getLog(JSONObject.class);
    private boolean nullObject;
    private Map properties;

    public JSONObject() {
        this.properties = new ListOrderedMap();
    }

    public JSONObject(boolean z) {
        this();
        this.nullObject = z;
    }

    private JSONObject _accumulate(String str, Object obj, JsonConfig jsonConfig) {
        if (isNullObject()) {
            throw new JSONException("Can't accumulate on null object");
        }
        if (!has(str)) {
            setInternal(str, obj, jsonConfig);
        } else {
            Object opt = opt(str);
            if (opt instanceof JSONArray) {
                ((JSONArray) opt).element(obj, jsonConfig);
            } else {
                setInternal(str, new JSONArray().element(opt).element(obj, jsonConfig), jsonConfig);
            }
        }
        return this;
    }

    private static JSONObject _fromBean(Object obj, JsonConfig jsonConfig) {
        fireObjectStartEvent(jsonConfig);
        if (!addInstance(obj)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(obj);
            } catch (JSONException e) {
                removeInstance(obj);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(obj);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JsonBeanProcessor findJsonBeanProcessor = jsonConfig.findJsonBeanProcessor(obj.getClass());
            if (findJsonBeanProcessor != null) {
                try {
                    JSONObject processBean = findJsonBeanProcessor.processBean(obj, jsonConfig);
                    if (processBean == null && (processBean = (JSONObject) jsonConfig.findDefaultValueProcessor(obj.getClass()).getDefaultValue(obj.getClass())) == null) {
                        processBean = new JSONObject(true);
                    }
                    removeInstance(obj);
                    fireObjectEndEvent(jsonConfig);
                    return processBean;
                } catch (JSONException e3) {
                    removeInstance(obj);
                    fireErrorEvent(e3, jsonConfig);
                    throw e3;
                } catch (RuntimeException e4) {
                    removeInstance(obj);
                    JSONException jSONException2 = new JSONException((Throwable) e4);
                    fireErrorEvent(jSONException2, jsonConfig);
                    throw jSONException2;
                }
            } else {
                Class<?> cls = obj.getClass();
                PropertyNameProcessor findJsonPropertyNameProcessor = jsonConfig.findJsonPropertyNameProcessor(cls);
                Collection mergedExcludes = jsonConfig.getMergedExcludes(cls);
                JSONObject jSONObject = new JSONObject();
                try {
                    PropertyDescriptor[] propertyDescriptors = PropertyUtils.getPropertyDescriptors(obj);
                    PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
                    for (int i = 0; i < propertyDescriptors.length; i++) {
                        String name = propertyDescriptors[i].getName();
                        if (!mergedExcludes.contains(name) && (!jsonConfig.isIgnoreTransientFields() || !isTransientField(name, cls))) {
                            Class propertyType = propertyDescriptors[i].getPropertyType();
                            if (propertyDescriptors[i].getReadMethod() != null) {
                                if (jsonConfig.isIgnoreJPATransient()) {
                                    try {
                                        if (propertyDescriptors[i].getReadMethod().getAnnotation(Class.forName("javax.persistence.Transient")) != null) {
                                            continue;
                                        }
                                    } catch (ClassNotFoundException e5) {
                                    }
                                }
                                Object property = PropertyUtils.getProperty(obj, name);
                                if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(obj, name, property)) {
                                    JsonValueProcessor findJsonValueProcessor = jsonConfig.findJsonValueProcessor(cls, propertyType, name);
                                    if (findJsonValueProcessor != null) {
                                        property = findJsonValueProcessor.processObjectValue(name, property, jsonConfig);
                                        if (!JsonVerifier.isValidJsonValue(property)) {
                                            throw new JSONException("Value is not a valid JSON value. " + property);
                                        }
                                    }
                                    if (findJsonPropertyNameProcessor != null) {
                                        name = findJsonPropertyNameProcessor.processPropertyName(cls, name);
                                    }
                                    setValue(jSONObject, name, property, propertyType, jsonConfig);
                                }
                            } else {
                                String str = "Property '" + name + "' of " + obj.getClass() + " has no read method. SKIPPED";
                                fireWarnEvent(str, jsonConfig);
                                log.warn(str);
                            }
                        }
                    }
                    removeInstance(obj);
                    fireObjectEndEvent(jsonConfig);
                    return jSONObject;
                } catch (JSONException e6) {
                    removeInstance(obj);
                    fireErrorEvent(e6, jsonConfig);
                    throw e6;
                } catch (Exception e7) {
                    removeInstance(obj);
                    JSONException jSONException3 = new JSONException((Throwable) e7);
                    fireErrorEvent(jSONException3, jsonConfig);
                    throw jSONException3;
                }
            }
        }
    }

    private static JSONObject _fromDynaBean(DynaBean dynaBean, JsonConfig jsonConfig) {
        fireObjectStartEvent(jsonConfig);
        if (dynaBean == null) {
            fireObjectEndEvent(jsonConfig);
            return new JSONObject(true);
        } else if (!addInstance(dynaBean)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(dynaBean);
            } catch (JSONException e) {
                removeInstance(dynaBean);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(dynaBean);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONObject jSONObject = new JSONObject();
            try {
                DynaProperty[] dynaProperties = dynaBean.getDynaClass().getDynaProperties();
                Collection mergedExcludes = jsonConfig.getMergedExcludes();
                PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
                for (DynaProperty dynaProperty : dynaProperties) {
                    String name = dynaProperty.getName();
                    if (!mergedExcludes.contains(name)) {
                        Class type = dynaProperty.getType();
                        Object obj = dynaBean.get(dynaProperty.getName());
                        if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(dynaBean, name, obj)) {
                            JsonValueProcessor findJsonValueProcessor = jsonConfig.findJsonValueProcessor(type, name);
                            if (findJsonValueProcessor != null) {
                                obj = findJsonValueProcessor.processObjectValue(name, obj, jsonConfig);
                                if (!JsonVerifier.isValidJsonValue(obj)) {
                                    throw new JSONException("Value is not a valid JSON value. " + obj);
                                }
                            }
                            setValue(jSONObject, name, obj, type, jsonConfig);
                        }
                    }
                }
                removeInstance(dynaBean);
                fireObjectEndEvent(jsonConfig);
                return jSONObject;
            } catch (JSONException e3) {
                removeInstance(dynaBean);
                fireErrorEvent(e3, jsonConfig);
                throw e3;
            } catch (RuntimeException e4) {
                removeInstance(dynaBean);
                JSONException jSONException2 = new JSONException((Throwable) e4);
                fireErrorEvent(jSONException2, jsonConfig);
                throw jSONException2;
            }
        }
    }

    private static JSONObject _fromJSONObject(JSONObject jSONObject, JsonConfig jsonConfig) {
        fireObjectStartEvent(jsonConfig);
        if (jSONObject == null || jSONObject.isNullObject()) {
            fireObjectEndEvent(jsonConfig);
            return new JSONObject(true);
        } else if (!addInstance(jSONObject)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(jSONObject);
            } catch (JSONException e) {
                removeInstance(jSONObject);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(jSONObject);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            JSONArray names = jSONObject.names(jsonConfig);
            Collection mergedExcludes = jsonConfig.getMergedExcludes();
            JSONObject jSONObject2 = new JSONObject();
            PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
            Iterator it = names.iterator();
            while (it.hasNext()) {
                Object next = it.next();
                if (next == null) {
                    throw new JSONException("JSON keys cannot be null.");
                } else if (!(next instanceof String)) {
                    throw new ClassCastException("JSON keys must be strings.");
                } else {
                    String valueOf = String.valueOf(next);
                    if ("null".equals(valueOf)) {
                        throw new NullPointerException("JSON keys must not be null nor the 'null' string.");
                    } else if (!mergedExcludes.contains(valueOf)) {
                        Object opt = jSONObject.opt(valueOf);
                        if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(jSONObject, valueOf, opt)) {
                            if (jSONObject2.properties.containsKey(valueOf)) {
                                jSONObject2.accumulate(valueOf, opt, jsonConfig);
                                firePropertySetEvent(valueOf, opt, true, jsonConfig);
                            } else {
                                jSONObject2._setInternal(valueOf, opt, jsonConfig);
                                firePropertySetEvent(valueOf, opt, false, jsonConfig);
                            }
                        }
                    }
                }
            }
            removeInstance(jSONObject);
            fireObjectEndEvent(jsonConfig);
            return jSONObject2;
        }
    }

    private static JSONObject _fromJSONString(JSONString jSONString, JsonConfig jsonConfig) {
        return _fromJSONTokener(new JSONTokener(jSONString.toJSONString()), jsonConfig);
    }

    private static JSONObject _fromJSONTokener(JSONTokener jSONTokener, JsonConfig jsonConfig) {
        fireObjectStartEvent(jsonConfig);
        try {
            if (!jSONTokener.matches("null.*")) {
                if (jSONTokener.nextClean() == '{') {
                    Collection mergedExcludes = jsonConfig.getMergedExcludes();
                    PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
                    JSONObject jSONObject = new JSONObject();
                    while (true) {
                        switch (jSONTokener.nextClean()) {
                            case 0:
                                throw jSONTokener.syntaxError("A JSONObject text must end with '}'");
                            case '}':
                                fireObjectEndEvent(jsonConfig);
                                return jSONObject;
                            default:
                                jSONTokener.back();
                                String obj = jSONTokener.nextValue(jsonConfig).toString();
                                char nextClean = jSONTokener.nextClean();
                                if (nextClean == '=') {
                                    if (jSONTokener.next() != '>') {
                                        jSONTokener.back();
                                    }
                                } else if (nextClean != ':') {
                                    throw jSONTokener.syntaxError("Expected a ':' after a key");
                                }
                                char peek = jSONTokener.peek();
                                boolean z = peek == '\"' || peek == '\'';
                                Object nextValue = jSONTokener.nextValue(jsonConfig);
                                if (!z && JSONUtils.isFunctionHeader(nextValue)) {
                                    String functionParams = JSONUtils.getFunctionParams((String) nextValue);
                                    StringBuffer stringBuffer = new StringBuffer();
                                    int i = 0;
                                    while (true) {
                                        char next = jSONTokener.next();
                                        if (next != 0) {
                                            if (next == '{') {
                                                i++;
                                            }
                                            if (next == '}') {
                                                i--;
                                            }
                                            stringBuffer.append(next);
                                            if (i == 0) {
                                            }
                                        }
                                    }
                                    if (i != 0) {
                                        throw jSONTokener.syntaxError("Unbalanced '{' or '}' on prop: " + nextValue);
                                    }
                                    String stringBuffer2 = stringBuffer.toString();
                                    JSONFunction jSONFunction = new JSONFunction(functionParams != null ? StringUtils.split(functionParams, ",") : null, stringBuffer2.substring(1, stringBuffer2.length() - 1).trim());
                                    if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(jSONTokener, obj, jSONFunction)) {
                                        if (jSONObject.properties.containsKey(obj)) {
                                            jSONObject.accumulate(obj, jSONFunction, jsonConfig);
                                            firePropertySetEvent(obj, jSONFunction, true, jsonConfig);
                                        } else {
                                            jSONObject.element(obj, (Object) jSONFunction, jsonConfig);
                                            firePropertySetEvent(obj, jSONFunction, false, jsonConfig);
                                        }
                                    }
                                } else if (mergedExcludes.contains(obj)) {
                                    switch (jSONTokener.nextClean()) {
                                        case ',':
                                        case ';':
                                            if (jSONTokener.nextClean() != '}') {
                                                jSONTokener.back();
                                                break;
                                            } else {
                                                fireObjectEndEvent(jsonConfig);
                                                return jSONObject;
                                            }
                                        case '}':
                                            fireObjectEndEvent(jsonConfig);
                                            return jSONObject;
                                        default:
                                            throw jSONTokener.syntaxError("Expected a ',' or '}'");
                                    }
                                } else if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(jSONTokener, obj, nextValue)) {
                                    if (z && (nextValue instanceof String) && (JSONUtils.mayBeJSON((String) nextValue) || JSONUtils.isFunction(nextValue))) {
                                        nextValue = JSONUtils.DOUBLE_QUOTE + nextValue + JSONUtils.DOUBLE_QUOTE;
                                    }
                                    if (jSONObject.properties.containsKey(obj)) {
                                        jSONObject.accumulate(obj, nextValue, jsonConfig);
                                        firePropertySetEvent(obj, nextValue, true, jsonConfig);
                                    } else {
                                        jSONObject.element(obj, nextValue, jsonConfig);
                                        firePropertySetEvent(obj, nextValue, false, jsonConfig);
                                    }
                                }
                                switch (jSONTokener.nextClean()) {
                                    case ',':
                                    case ';':
                                        if (jSONTokener.nextClean() != '}') {
                                            jSONTokener.back();
                                            break;
                                        } else {
                                            fireObjectEndEvent(jsonConfig);
                                            return jSONObject;
                                        }
                                    case '}':
                                        fireObjectEndEvent(jsonConfig);
                                        return jSONObject;
                                    default:
                                        throw jSONTokener.syntaxError("Expected a ',' or '}'");
                                }
                                break;
                        }
                    }
                } else {
                    throw jSONTokener.syntaxError("A JSONObject text must begin with '{'");
                }
            } else {
                fireObjectEndEvent(jsonConfig);
                return new JSONObject(true);
            }
        } catch (JSONException e) {
            fireErrorEvent(e, jsonConfig);
            throw e;
        }
    }

    private static JSONObject _fromMap(Map map, JsonConfig jsonConfig) {
        fireObjectStartEvent(jsonConfig);
        if (map == null) {
            fireObjectEndEvent(jsonConfig);
            return new JSONObject(true);
        } else if (!addInstance(map)) {
            try {
                return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(map);
            } catch (JSONException e) {
                removeInstance(map);
                fireErrorEvent(e, jsonConfig);
                throw e;
            } catch (RuntimeException e2) {
                removeInstance(map);
                JSONException jSONException = new JSONException((Throwable) e2);
                fireErrorEvent(jSONException, jsonConfig);
                throw jSONException;
            }
        } else {
            Collection mergedExcludes = jsonConfig.getMergedExcludes();
            JSONObject jSONObject = new JSONObject();
            PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
            try {
                for (Map.Entry entry : map.entrySet()) {
                    Object key = entry.getKey();
                    if (key == null) {
                        throw new JSONException("JSON keys cannot be null.");
                    } else if (!(key instanceof String)) {
                        throw new ClassCastException("JSON keys must be strings.");
                    } else {
                        String valueOf = String.valueOf(key);
                        if ("null".equals(valueOf)) {
                            throw new NullPointerException("JSON keys must not be null nor the 'null' string.");
                        } else if (!mergedExcludes.contains(valueOf)) {
                            Object value = entry.getValue();
                            if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(map, valueOf, value)) {
                                if (value != null) {
                                    JsonValueProcessor findJsonValueProcessor = jsonConfig.findJsonValueProcessor(value.getClass(), valueOf);
                                    if (findJsonValueProcessor != null) {
                                        value = findJsonValueProcessor.processObjectValue(valueOf, value, jsonConfig);
                                        if (!JsonVerifier.isValidJsonValue(value)) {
                                            throw new JSONException("Value is not a valid JSON value. " + value);
                                        }
                                    }
                                    setValue(jSONObject, valueOf, value, value.getClass(), jsonConfig);
                                } else if (jSONObject.properties.containsKey(valueOf)) {
                                    jSONObject.accumulate(valueOf, (Object) JSONNull.getInstance());
                                    firePropertySetEvent(valueOf, JSONNull.getInstance(), true, jsonConfig);
                                } else {
                                    jSONObject.element(valueOf, (Object) JSONNull.getInstance());
                                    firePropertySetEvent(valueOf, JSONNull.getInstance(), false, jsonConfig);
                                }
                            }
                        }
                    }
                }
                removeInstance(map);
                fireObjectEndEvent(jsonConfig);
                return jSONObject;
            } catch (JSONException e3) {
                removeInstance(map);
                fireErrorEvent(e3, jsonConfig);
                throw e3;
            } catch (RuntimeException e4) {
                removeInstance(map);
                JSONException jSONException2 = new JSONException((Throwable) e4);
                fireErrorEvent(jSONException2, jsonConfig);
                throw jSONException2;
            }
        }
    }

    private static JSONObject _fromString(String str, JsonConfig jsonConfig) {
        if (str != null && !"null".equals(str)) {
            return _fromJSONTokener(new JSONTokener(str), jsonConfig);
        }
        fireObjectStartEvent(jsonConfig);
        fireObjectEndEvent(jsonConfig);
        return new JSONObject(true);
    }

    private Object _processValue(Object obj, JsonConfig jsonConfig) {
        if ((obj != null && Class.class.isAssignableFrom(obj.getClass())) || (obj instanceof Class)) {
            return ((Class) obj).getName();
        }
        if (obj instanceof JSON) {
            return JSONSerializer.toJSON(obj, jsonConfig);
        }
        if (JSONUtils.isFunction(obj)) {
            return obj instanceof String ? JSONFunction.parse((String) obj) : obj;
        }
        if (obj instanceof JSONString) {
            return JSONSerializer.toJSON((Object) (JSONString) obj, jsonConfig);
        }
        if (JSONUtils.isArray(obj)) {
            return JSONArray.fromObject(obj, jsonConfig);
        }
        if (JSONUtils.isString(obj)) {
            String valueOf = String.valueOf(obj);
            if (JSONUtils.mayBeJSON(valueOf)) {
                try {
                    return JSONSerializer.toJSON((Object) valueOf, jsonConfig);
                } catch (JSONException e) {
                    return JSONUtils.stripQuotes(valueOf);
                }
            } else if (obj == null) {
                return "";
            } else {
                String stripQuotes = JSONUtils.stripQuotes(valueOf);
                if (!JSONUtils.mayBeJSON(stripQuotes)) {
                    stripQuotes = valueOf;
                }
                return stripQuotes;
            }
        } else if (!JSONUtils.isNumber(obj)) {
            return !JSONUtils.isBoolean(obj) ? (obj == null || !Enum.class.isAssignableFrom(obj.getClass())) ? fromObject(obj, jsonConfig) : ((Enum) obj).name() : obj;
        } else {
            JSONUtils.testValidity(obj);
            return JSONUtils.transformNumber((Number) obj);
        }
    }

    private JSONObject _setInternal(String str, Object obj, JsonConfig jsonConfig) {
        verifyIsNull();
        if (str == null) {
            throw new JSONException("Null key.");
        }
        if (!JSONUtils.isString(obj) || !JSONUtils.mayBeJSON(String.valueOf(obj))) {
            Object _processValue = _processValue(obj, jsonConfig);
            if (!(CycleDetectionStrategy.IGNORE_PROPERTY_OBJ == _processValue || CycleDetectionStrategy.IGNORE_PROPERTY_ARR == _processValue)) {
                this.properties.put(str, _processValue);
            }
        } else {
            this.properties.put(str, obj);
        }
        return this;
    }

    private static Object convertPropertyValueToArray(String str, Object obj, Class cls, JsonConfig jsonConfig, Map map) {
        Class innerComponentType = JSONUtils.getInnerComponentType(cls);
        Class findTargetClass = findTargetClass(str, map);
        if (!innerComponentType.equals(Object.class) || findTargetClass == null || findTargetClass.equals(Object.class)) {
            findTargetClass = innerComponentType;
        }
        JsonConfig copy = jsonConfig.copy();
        copy.setRootClass(findTargetClass);
        copy.setClassMap(map);
        Object array = JSONArray.toArray((JSONArray) obj, copy);
        if (findTargetClass.isPrimitive() || JSONUtils.isNumber(findTargetClass) || Boolean.class.isAssignableFrom(findTargetClass) || JSONUtils.isString(findTargetClass)) {
            return JSONUtils.getMorpherRegistry().morph(Array.newInstance(findTargetClass, 0).getClass(), array);
        }
        if (array.getClass().equals(cls) || cls.equals(Object.class)) {
            return array;
        }
        if (IdentityObjectMorpher.getInstance().equals(JSONUtils.getMorpherRegistry().getMorpherFor(Array.newInstance(findTargetClass, 0).getClass()))) {
            JSONUtils.getMorpherRegistry().registerMorpher(new ObjectArrayMorpher(new BeanMorpher(findTargetClass, JSONUtils.getMorpherRegistry())));
        }
        return JSONUtils.getMorpherRegistry().morph(Array.newInstance(findTargetClass, 0).getClass(), array);
    }

    private static Collection convertPropertyValueToCollection(String str, Object obj, JsonConfig jsonConfig, String str2, Map map, Class cls) {
        Class findTargetClass = findTargetClass(str, map);
        if (findTargetClass == null) {
            findTargetClass = findTargetClass(str2, map);
        }
        JsonConfig copy = jsonConfig.copy();
        copy.setRootClass(findTargetClass);
        copy.setClassMap(map);
        copy.setCollectionType(cls);
        return JSONArray.toCollection((JSONArray) obj, copy);
    }

    private static List convertPropertyValueToList(String str, Object obj, JsonConfig jsonConfig, String str2, Map map) {
        Class findTargetClass = findTargetClass(str, map);
        if (findTargetClass == null) {
            findTargetClass = findTargetClass(str2, map);
        }
        JsonConfig copy = jsonConfig.copy();
        copy.setRootClass(findTargetClass);
        copy.setClassMap(map);
        return (List) JSONArray.toCollection((JSONArray) obj, copy);
    }

    private static Class findTargetClass(String str, Map map) {
        Class cls = (Class) map.get(str);
        if (cls != null) {
            return cls;
        }
        for (Map.Entry entry : map.entrySet()) {
            if (RegexpUtils.getMatcher((String) entry.getKey()).matches(str)) {
                return (Class) entry.getValue();
            }
        }
        return cls;
    }

    public static JSONObject fromObject(Object obj) {
        return fromObject(obj, new JsonConfig());
    }

    public static JSONObject fromObject(Object obj, JsonConfig jsonConfig) {
        if (obj == null || JSONUtils.isNull(obj)) {
            return new JSONObject(true);
        }
        if (obj instanceof Enum) {
            throw new JSONException("'object' is an Enum. Use JSONArray instead");
        } else if ((obj instanceof Annotation) || (obj != null && obj.getClass().isAnnotation())) {
            throw new JSONException("'object' is an Annotation.");
        } else if (obj instanceof JSONObject) {
            return _fromJSONObject((JSONObject) obj, jsonConfig);
        } else {
            if (obj instanceof DynaBean) {
                return _fromDynaBean((DynaBean) obj, jsonConfig);
            }
            if (obj instanceof JSONTokener) {
                return _fromJSONTokener((JSONTokener) obj, jsonConfig);
            }
            if (obj instanceof JSONString) {
                return _fromJSONString((JSONString) obj, jsonConfig);
            }
            if (obj instanceof Map) {
                return _fromMap((Map) obj, jsonConfig);
            }
            if (obj instanceof String) {
                return _fromString((String) obj, jsonConfig);
            }
            if (JSONUtils.isNumber(obj) || JSONUtils.isBoolean(obj) || JSONUtils.isString(obj)) {
                return new JSONObject();
            }
            if (!JSONUtils.isArray(obj)) {
                return _fromBean(obj, jsonConfig);
            }
            throw new JSONException("'object' is an array. Use JSONArray instead");
        }
    }

    private static boolean isTransientField(String str, Class cls) {
        try {
            return (cls.getDeclaredField(str).getModifiers() & 128) == 128;
        } catch (Exception e) {
            return false;
        }
    }

    private static Object morphPropertyValue(String str, Object obj, Class cls, Class cls2) {
        if (IdentityObjectMorpher.getInstance().equals(JSONUtils.getMorpherRegistry().getMorpherFor(cls2))) {
            log.warn("Can't transform property '" + str + "' from " + cls.getName() + " into " + cls2.getName() + ". Will register a default Morpher");
            if (Enum.class.isAssignableFrom(cls2)) {
                JSONUtils.getMorpherRegistry().registerMorpher(new EnumMorpher(cls2));
            } else {
                JSONUtils.getMorpherRegistry().registerMorpher(new BeanMorpher(cls2, JSONUtils.getMorpherRegistry()));
            }
        }
        return JSONUtils.getMorpherRegistry().morph(cls2, obj);
    }

    private Object processValue(Object obj, JsonConfig jsonConfig) {
        JsonValueProcessor findJsonValueProcessor;
        if (!(obj == null || (findJsonValueProcessor = jsonConfig.findJsonValueProcessor(obj.getClass())) == null)) {
            obj = findJsonValueProcessor.processObjectValue((String) null, obj, jsonConfig);
            if (!JsonVerifier.isValidJsonValue(obj)) {
                throw new JSONException("Value is not a valid JSON value. " + obj);
            }
        }
        return _processValue(obj, jsonConfig);
    }

    private Object processValue(String str, Object obj, JsonConfig jsonConfig) {
        JsonValueProcessor findJsonValueProcessor;
        if (!(obj == null || (findJsonValueProcessor = jsonConfig.findJsonValueProcessor(obj.getClass(), str)) == null)) {
            obj = findJsonValueProcessor.processObjectValue((String) null, obj, jsonConfig);
            if (!JsonVerifier.isValidJsonValue(obj)) {
                throw new JSONException("Value is not a valid JSON value. " + obj);
            }
        }
        return _processValue(obj, jsonConfig);
    }

    private JSONObject setInternal(String str, Object obj, JsonConfig jsonConfig) {
        return _setInternal(str, processValue(str, obj, jsonConfig), jsonConfig);
    }

    private static void setProperty(Object obj, String str, Object obj2, JsonConfig jsonConfig) {
        (jsonConfig.getPropertySetStrategy() != null ? jsonConfig.getPropertySetStrategy() : PropertySetStrategy.DEFAULT).setProperty(obj, str, obj2);
    }

    private static void setValue(JSONObject jSONObject, String str, Object obj, Class cls, JsonConfig jsonConfig) {
        Object obj2;
        boolean z;
        if (obj == null) {
            obj2 = jsonConfig.findDefaultValueProcessor(cls).getDefaultValue(cls);
            if (!JsonVerifier.isValidJsonValue(obj2)) {
                throw new JSONException("Value is not a valid JSON value. " + obj2);
            }
        } else {
            obj2 = obj;
        }
        if (jSONObject.properties.containsKey(str)) {
            if (String.class.isAssignableFrom(cls)) {
                Object opt = jSONObject.opt(str);
                if (opt instanceof JSONArray) {
                    ((JSONArray) opt).addString((String) obj2);
                } else {
                    jSONObject.properties.put(str, new JSONArray().element(opt).addString((String) obj2));
                }
            } else {
                jSONObject.accumulate(str, obj2, jsonConfig);
            }
            z = true;
        } else if (String.class.isAssignableFrom(cls)) {
            jSONObject.properties.put(str, obj2);
            z = false;
        } else {
            jSONObject._setInternal(str, obj2, jsonConfig);
            z = false;
        }
        Object opt2 = jSONObject.opt(str);
        if (z) {
            JSONArray jSONArray = (JSONArray) opt2;
            opt2 = jSONArray.get(jSONArray.size() - 1);
        }
        firePropertySetEvent(str, opt2, z, jsonConfig);
    }

    public static Object toBean(JSONObject jSONObject) {
        if (jSONObject == null || jSONObject.isNullObject()) {
            return null;
        }
        JsonConfig jsonConfig = new JsonConfig();
        Map properties2 = JSONUtils.getProperties(jSONObject);
        DynaBean newDynaBean = JSONUtils.newDynaBean(jSONObject, jsonConfig);
        Iterator it = jSONObject.names(jsonConfig).iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            String convertToJavaIdentifier = JSONUtils.convertToJavaIdentifier(str, jsonConfig);
            Class cls = (Class) properties2.get(str);
            Object obj = jSONObject.get(str);
            try {
                if (!JSONUtils.isNull(obj)) {
                    if (obj instanceof JSONArray) {
                        newDynaBean.set(convertToJavaIdentifier, JSONArray.toCollection((JSONArray) obj));
                    } else if (String.class.isAssignableFrom(cls) || Boolean.class.isAssignableFrom(cls) || JSONUtils.isNumber(cls) || Character.class.isAssignableFrom(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                        newDynaBean.set(convertToJavaIdentifier, obj);
                    } else {
                        newDynaBean.set(convertToJavaIdentifier, toBean((JSONObject) obj));
                    }
                } else if (cls.isPrimitive()) {
                    log.warn("Tried to assign null value to " + convertToJavaIdentifier + ":" + cls.getName());
                    newDynaBean.set(convertToJavaIdentifier, JSONUtils.getMorpherRegistry().morph(cls, (Object) null));
                } else {
                    newDynaBean.set(convertToJavaIdentifier, (Object) null);
                }
            } catch (JSONException e) {
                throw e;
            } catch (Exception e2) {
                throw new JSONException("Error while setting property=" + str + " type" + cls, e2);
            }
        }
        return newDynaBean;
    }

    public static Object toBean(JSONObject jSONObject, Class cls) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        return toBean(jSONObject, jsonConfig);
    }

    public static Object toBean(JSONObject jSONObject, Class cls, Map map) {
        JsonConfig jsonConfig = new JsonConfig();
        jsonConfig.setRootClass(cls);
        jsonConfig.setClassMap(map);
        return toBean(jSONObject, jsonConfig);
    }

    public static Object toBean(JSONObject jSONObject, Object obj, JsonConfig jsonConfig) {
        if (!(jSONObject == null || jSONObject.isNullObject() || obj == null)) {
            Class<?> cls = obj.getClass();
            if (cls.isInterface()) {
                throw new JSONException("Root bean is an interface. " + cls);
            }
            Map classMap = jsonConfig.getClassMap();
            Map map = classMap == null ? Collections.EMPTY_MAP : classMap;
            Map properties2 = JSONUtils.getProperties(jSONObject);
            PropertyFilter javaPropertyFilter = jsonConfig.getJavaPropertyFilter();
            Iterator it = jSONObject.names(jsonConfig).iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                Class cls2 = (Class) properties2.get(str);
                Object obj2 = jSONObject.get(str);
                if (javaPropertyFilter == null || !javaPropertyFilter.apply(obj, str, obj2)) {
                    String convertToJavaIdentifier = JSONUtils.convertToJavaIdentifier(str, jsonConfig);
                    try {
                        PropertyDescriptor propertyDescriptor = PropertyUtils.getPropertyDescriptor(obj, convertToJavaIdentifier);
                        if (propertyDescriptor != null && propertyDescriptor.getWriteMethod() == null) {
                            log.warn("Property '" + convertToJavaIdentifier + "' of " + obj.getClass() + " has no write method. SKIPPED.");
                        } else if (!JSONUtils.isNull(obj2)) {
                            if (obj2 instanceof JSONArray) {
                                if (propertyDescriptor == null || List.class.isAssignableFrom(propertyDescriptor.getPropertyType())) {
                                    Class findTargetClass = findTargetClass(convertToJavaIdentifier, map);
                                    if (findTargetClass == null) {
                                        findTargetClass = findTargetClass(str, map);
                                    }
                                    setProperty(obj, convertToJavaIdentifier, JSONArray.toList((JSONArray) obj2, jsonConfig.getNewBeanInstanceStrategy().newInstance(findTargetClass, (JSONObject) null), jsonConfig), jsonConfig);
                                } else {
                                    Class innerComponentType = JSONUtils.getInnerComponentType(propertyDescriptor.getPropertyType());
                                    Class findTargetClass2 = findTargetClass(convertToJavaIdentifier, map);
                                    if (!innerComponentType.equals(Object.class) || findTargetClass2 == null || findTargetClass2.equals(Object.class)) {
                                        findTargetClass2 = innerComponentType;
                                    }
                                    Object array = JSONArray.toArray((JSONArray) obj2, jsonConfig.getNewBeanInstanceStrategy().newInstance(findTargetClass2, (JSONObject) null), jsonConfig);
                                    if (findTargetClass2.isPrimitive() || JSONUtils.isNumber(findTargetClass2) || Boolean.class.isAssignableFrom(findTargetClass2) || JSONUtils.isString(findTargetClass2)) {
                                        array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(findTargetClass2, 0).getClass(), array);
                                    } else if (!array.getClass().equals(propertyDescriptor.getPropertyType()) && !propertyDescriptor.getPropertyType().equals(Object.class)) {
                                        if (IdentityObjectMorpher.getInstance().equals(JSONUtils.getMorpherRegistry().getMorpherFor(Array.newInstance(findTargetClass2, 0).getClass()))) {
                                            JSONUtils.getMorpherRegistry().registerMorpher(new ObjectArrayMorpher(new BeanMorpher(findTargetClass2, JSONUtils.getMorpherRegistry())));
                                        }
                                        array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(findTargetClass2, 0).getClass(), array);
                                    }
                                    setProperty(obj, convertToJavaIdentifier, array, jsonConfig);
                                }
                            } else if (String.class.isAssignableFrom(cls2) || JSONUtils.isBoolean(cls2) || JSONUtils.isNumber(cls2) || JSONUtils.isString(cls2) || JSONFunction.class.isAssignableFrom(cls2)) {
                                if (propertyDescriptor != null) {
                                    if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(obj2)) {
                                        setProperty(obj, convertToJavaIdentifier, (Object) null, jsonConfig);
                                    } else if (!propertyDescriptor.getPropertyType().isInstance(obj2)) {
                                        if (IdentityObjectMorpher.getInstance().equals(JSONUtils.getMorpherRegistry().getMorpherFor(propertyDescriptor.getPropertyType()))) {
                                            log.warn("Can't transform property '" + convertToJavaIdentifier + "' from " + cls2.getName() + " into " + propertyDescriptor.getPropertyType().getName() + ". Will register a default BeanMorpher");
                                            JSONUtils.getMorpherRegistry().registerMorpher(new BeanMorpher(propertyDescriptor.getPropertyType(), JSONUtils.getMorpherRegistry()));
                                        }
                                        setProperty(obj, convertToJavaIdentifier, JSONUtils.getMorpherRegistry().morph(propertyDescriptor.getPropertyType(), obj2), jsonConfig);
                                    } else {
                                        setProperty(obj, convertToJavaIdentifier, obj2, jsonConfig);
                                    }
                                } else if (obj instanceof Map) {
                                    setProperty(obj, convertToJavaIdentifier, obj2, jsonConfig);
                                } else {
                                    log.warn("Tried to assign property " + convertToJavaIdentifier + ":" + cls2.getName() + " to bean of class " + obj.getClass().getName());
                                }
                            } else if (propertyDescriptor != null) {
                                Class<Object> propertyType = propertyDescriptor.getPropertyType();
                                if (jsonConfig.isHandleJettisonSingleElementArray()) {
                                    JSONArray element = new JSONArray().element(obj2, jsonConfig);
                                    Class findTargetClass3 = findTargetClass(convertToJavaIdentifier, map);
                                    if (findTargetClass3 == null) {
                                        findTargetClass3 = findTargetClass(str, map);
                                    }
                                    Object newInstance = jsonConfig.getNewBeanInstanceStrategy().newInstance(findTargetClass3, (JSONObject) null);
                                    if (propertyType.isArray()) {
                                        setProperty(obj, convertToJavaIdentifier, JSONArray.toArray(element, newInstance, jsonConfig), jsonConfig);
                                    } else if (Collection.class.isAssignableFrom(propertyType)) {
                                        setProperty(obj, convertToJavaIdentifier, JSONArray.toList(element, newInstance, jsonConfig), jsonConfig);
                                    } else if (JSONArray.class.isAssignableFrom(propertyType)) {
                                        setProperty(obj, convertToJavaIdentifier, element, jsonConfig);
                                    } else {
                                        setProperty(obj, convertToJavaIdentifier, toBean((JSONObject) obj2, newInstance, jsonConfig), jsonConfig);
                                    }
                                } else {
                                    if (propertyType == Object.class && (propertyType = findTargetClass(convertToJavaIdentifier, map)) == null) {
                                        propertyType = findTargetClass(str, map);
                                    }
                                    setProperty(obj, convertToJavaIdentifier, toBean((JSONObject) obj2, jsonConfig.getNewBeanInstanceStrategy().newInstance(propertyType, (JSONObject) null), jsonConfig), jsonConfig);
                                }
                            } else if (obj instanceof Map) {
                                Class findTargetClass4 = findTargetClass(convertToJavaIdentifier, map);
                                if (findTargetClass4 == null) {
                                    findTargetClass4 = findTargetClass(str, map);
                                }
                                setProperty(obj, convertToJavaIdentifier, toBean((JSONObject) obj2, jsonConfig.getNewBeanInstanceStrategy().newInstance(findTargetClass4, (JSONObject) null), jsonConfig), jsonConfig);
                            } else {
                                log.warn("Tried to assign property " + convertToJavaIdentifier + ":" + cls2.getName() + " to bean of class " + cls.getName());
                            }
                        } else if (cls2.isPrimitive()) {
                            log.warn("Tried to assign null value to " + convertToJavaIdentifier + ":" + cls2.getName());
                            setProperty(obj, convertToJavaIdentifier, JSONUtils.getMorpherRegistry().morph(cls2, (Object) null), jsonConfig);
                        } else {
                            setProperty(obj, convertToJavaIdentifier, (Object) null, jsonConfig);
                        }
                    } catch (JSONException e) {
                        throw e;
                    } catch (Exception e2) {
                        throw new JSONException("Error while setting property=" + str + " type " + cls2, e2);
                    }
                }
            }
        }
        return obj;
    }

    public static Object toBean(JSONObject jSONObject, JsonConfig jsonConfig) {
        HashMap newInstance;
        if (jSONObject == null || jSONObject.isNullObject()) {
            return null;
        }
        Class rootClass = jsonConfig.getRootClass();
        Map classMap = jsonConfig.getClassMap();
        if (rootClass == null) {
            return toBean(jSONObject);
        }
        if (classMap == null) {
            classMap = Collections.EMPTY_MAP;
        }
        try {
            if (!rootClass.isInterface()) {
                newInstance = jsonConfig.getNewBeanInstanceStrategy().newInstance(rootClass, jSONObject);
            } else if (!Map.class.isAssignableFrom(rootClass)) {
                throw new JSONException("beanClass is an interface. " + rootClass);
            } else {
                newInstance = new HashMap();
            }
            Map properties2 = JSONUtils.getProperties(jSONObject);
            PropertyFilter javaPropertyFilter = jsonConfig.getJavaPropertyFilter();
            Iterator it = jSONObject.names(jsonConfig).iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                Class cls = (Class) properties2.get(str);
                Object obj = jSONObject.get(str);
                if (javaPropertyFilter == null || !javaPropertyFilter.apply(newInstance, str, obj)) {
                    String convertToJavaIdentifier = (!Map.class.isAssignableFrom(rootClass) || !jsonConfig.isSkipJavaIdentifierTransformationInMapKeys()) ? JSONUtils.convertToJavaIdentifier(str, jsonConfig) : str;
                    PropertyNameProcessor findJavaPropertyNameProcessor = jsonConfig.findJavaPropertyNameProcessor(rootClass);
                    if (findJavaPropertyNameProcessor != null) {
                        convertToJavaIdentifier = findJavaPropertyNameProcessor.processPropertyName(rootClass, convertToJavaIdentifier);
                    }
                    try {
                        if (!Map.class.isAssignableFrom(rootClass)) {
                            PropertyDescriptor propertyDescriptor = PropertyUtils.getPropertyDescriptor(newInstance, convertToJavaIdentifier);
                            if (propertyDescriptor != null && propertyDescriptor.getWriteMethod() == null) {
                                log.warn("Property '" + convertToJavaIdentifier + "' of " + newInstance.getClass() + " has no write method. SKIPPED.");
                            } else if (propertyDescriptor != null) {
                                Class<Object> propertyType = propertyDescriptor.getPropertyType();
                                if (!JSONUtils.isNull(obj)) {
                                    if (obj instanceof JSONArray) {
                                        if (List.class.isAssignableFrom(propertyDescriptor.getPropertyType())) {
                                            setProperty(newInstance, convertToJavaIdentifier, convertPropertyValueToCollection(convertToJavaIdentifier, obj, jsonConfig, str, classMap, propertyDescriptor.getPropertyType()), jsonConfig);
                                        } else if (Set.class.isAssignableFrom(propertyDescriptor.getPropertyType())) {
                                            setProperty(newInstance, convertToJavaIdentifier, convertPropertyValueToCollection(convertToJavaIdentifier, obj, jsonConfig, str, classMap, propertyDescriptor.getPropertyType()), jsonConfig);
                                        } else {
                                            setProperty(newInstance, convertToJavaIdentifier, convertPropertyValueToArray(convertToJavaIdentifier, obj, propertyType, jsonConfig, classMap), jsonConfig);
                                        }
                                    } else if (String.class.isAssignableFrom(cls) || JSONUtils.isBoolean(cls) || JSONUtils.isNumber(cls) || JSONUtils.isString(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                                        if (propertyDescriptor != null) {
                                            if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(obj)) {
                                                setProperty(newInstance, convertToJavaIdentifier, (Object) null, jsonConfig);
                                            } else if (!propertyType.isInstance(obj)) {
                                                setProperty(newInstance, convertToJavaIdentifier, morphPropertyValue(convertToJavaIdentifier, obj, cls, propertyType), jsonConfig);
                                            } else {
                                                setProperty(newInstance, convertToJavaIdentifier, obj, jsonConfig);
                                            }
                                        } else if (rootClass == null || (newInstance instanceof Map)) {
                                            setProperty(newInstance, convertToJavaIdentifier, obj, jsonConfig);
                                        } else {
                                            log.warn("Tried to assign property " + convertToJavaIdentifier + ":" + cls.getName() + " to bean of class " + newInstance.getClass().getName());
                                        }
                                    } else if (jsonConfig.isHandleJettisonSingleElementArray()) {
                                        JSONArray element = new JSONArray().element(obj, jsonConfig);
                                        Class findTargetClass = findTargetClass(convertToJavaIdentifier, classMap);
                                        if (findTargetClass == null) {
                                            findTargetClass = findTargetClass(str, classMap);
                                        }
                                        JsonConfig copy = jsonConfig.copy();
                                        copy.setRootClass(findTargetClass);
                                        copy.setClassMap(classMap);
                                        if (propertyType.isArray()) {
                                            setProperty(newInstance, convertToJavaIdentifier, JSONArray.toArray(element, copy), jsonConfig);
                                        } else if (JSONArray.class.isAssignableFrom(propertyType)) {
                                            setProperty(newInstance, convertToJavaIdentifier, element, jsonConfig);
                                        } else if (List.class.isAssignableFrom(propertyType) || Set.class.isAssignableFrom(propertyType)) {
                                            copy.setCollectionType(propertyType);
                                            setProperty(newInstance, convertToJavaIdentifier, JSONArray.toCollection(element, copy), jsonConfig);
                                        } else {
                                            setProperty(newInstance, convertToJavaIdentifier, toBean((JSONObject) obj, copy), jsonConfig);
                                        }
                                    } else {
                                        if (propertyType == Object.class || propertyType.isInterface()) {
                                            Class<Object> findTargetClass2 = findTargetClass(convertToJavaIdentifier, classMap);
                                            if (findTargetClass2 == null) {
                                                findTargetClass2 = findTargetClass(str, classMap);
                                            }
                                            if (findTargetClass2 != null || !propertyType.isInterface()) {
                                                propertyType = findTargetClass2;
                                            }
                                        }
                                        JsonConfig copy2 = jsonConfig.copy();
                                        copy2.setRootClass(propertyType);
                                        copy2.setClassMap(classMap);
                                        setProperty(newInstance, convertToJavaIdentifier, toBean((JSONObject) obj, copy2), jsonConfig);
                                    }
                                } else if (cls.isPrimitive()) {
                                    log.warn("Tried to assign null value to " + convertToJavaIdentifier + ":" + cls.getName());
                                    setProperty(newInstance, convertToJavaIdentifier, JSONUtils.getMorpherRegistry().morph(cls, (Object) null), jsonConfig);
                                } else {
                                    setProperty(newInstance, convertToJavaIdentifier, (Object) null, jsonConfig);
                                }
                            } else if (!JSONUtils.isNull(obj)) {
                                if (obj instanceof JSONArray) {
                                    setProperty(newInstance, convertToJavaIdentifier, convertPropertyValueToCollection(convertToJavaIdentifier, obj, jsonConfig, str, classMap, List.class), jsonConfig);
                                } else if (String.class.isAssignableFrom(cls) || JSONUtils.isBoolean(cls) || JSONUtils.isNumber(cls) || JSONUtils.isString(cls) || JSONFunction.class.isAssignableFrom(cls)) {
                                    if (rootClass == null || (newInstance instanceof Map) || jsonConfig.getPropertySetStrategy() != null) {
                                        setProperty(newInstance, convertToJavaIdentifier, obj, jsonConfig);
                                    } else {
                                        log.warn("Tried to assign property " + convertToJavaIdentifier + ":" + cls.getName() + " to bean of class " + newInstance.getClass().getName());
                                    }
                                } else if (jsonConfig.isHandleJettisonSingleElementArray()) {
                                    Class findTargetClass3 = findTargetClass(convertToJavaIdentifier, classMap);
                                    if (findTargetClass3 == null) {
                                        findTargetClass3 = findTargetClass(str, classMap);
                                    }
                                    JsonConfig copy3 = jsonConfig.copy();
                                    copy3.setRootClass(findTargetClass3);
                                    copy3.setClassMap(classMap);
                                    setProperty(newInstance, convertToJavaIdentifier, toBean((JSONObject) obj, copy3), jsonConfig);
                                } else {
                                    setProperty(newInstance, convertToJavaIdentifier, obj, jsonConfig);
                                }
                            } else if (cls.isPrimitive()) {
                                log.warn("Tried to assign null value to " + convertToJavaIdentifier + ":" + cls.getName());
                                setProperty(newInstance, convertToJavaIdentifier, JSONUtils.getMorpherRegistry().morph(cls, (Object) null), jsonConfig);
                            } else {
                                setProperty(newInstance, convertToJavaIdentifier, (Object) null, jsonConfig);
                            }
                        } else if (JSONUtils.isNull(obj)) {
                            setProperty(newInstance, convertToJavaIdentifier, obj, jsonConfig);
                        } else if (obj instanceof JSONArray) {
                            setProperty(newInstance, convertToJavaIdentifier, convertPropertyValueToCollection(convertToJavaIdentifier, obj, jsonConfig, str, classMap, List.class), jsonConfig);
                        } else if (!String.class.isAssignableFrom(cls) && !JSONUtils.isBoolean(cls) && !JSONUtils.isNumber(cls) && !JSONUtils.isString(cls) && !JSONFunction.class.isAssignableFrom(cls)) {
                            Class findTargetClass4 = findTargetClass(convertToJavaIdentifier, classMap);
                            if (findTargetClass4 == null) {
                                findTargetClass4 = findTargetClass(str, classMap);
                            }
                            JsonConfig copy4 = jsonConfig.copy();
                            copy4.setRootClass(findTargetClass4);
                            copy4.setClassMap(classMap);
                            if (findTargetClass4 != null) {
                                setProperty(newInstance, convertToJavaIdentifier, toBean((JSONObject) obj, copy4), jsonConfig);
                            } else {
                                setProperty(newInstance, convertToJavaIdentifier, toBean((JSONObject) obj), jsonConfig);
                            }
                        } else if (!jsonConfig.isHandleJettisonEmptyElement() || !"".equals(obj)) {
                            setProperty(newInstance, convertToJavaIdentifier, obj, jsonConfig);
                        } else {
                            setProperty(newInstance, convertToJavaIdentifier, (Object) null, jsonConfig);
                        }
                    } catch (JSONException e) {
                        throw e;
                    } catch (Exception e2) {
                        throw new JSONException("Error while setting property=" + str + " type " + cls, e2);
                    }
                }
            }
            return newInstance;
        } catch (JSONException e3) {
            throw e3;
        } catch (Exception e4) {
            throw new JSONException((Throwable) e4);
        }
    }

    private void verifyIsNull() {
        if (isNullObject()) {
            throw new JSONException("null object");
        }
    }

    public JSONObject accumulate(String str, double d) {
        return _accumulate(str, Double.valueOf(d), new JsonConfig());
    }

    public JSONObject accumulate(String str, int i) {
        return _accumulate(str, Integer.valueOf(i), new JsonConfig());
    }

    public JSONObject accumulate(String str, long j) {
        return _accumulate(str, Long.valueOf(j), new JsonConfig());
    }

    public JSONObject accumulate(String str, Object obj) {
        return _accumulate(str, obj, new JsonConfig());
    }

    public JSONObject accumulate(String str, Object obj, JsonConfig jsonConfig) {
        return _accumulate(str, obj, jsonConfig);
    }

    public JSONObject accumulate(String str, boolean z) {
        return _accumulate(str, z ? Boolean.TRUE : Boolean.FALSE, new JsonConfig());
    }

    public void accumulateAll(Map map) {
        accumulateAll(map, new JsonConfig());
    }

    public void accumulateAll(Map map, JsonConfig jsonConfig) {
        if (map instanceof JSONObject) {
            for (Map.Entry entry : map.entrySet()) {
                accumulate((String) entry.getKey(), entry.getValue(), jsonConfig);
            }
            return;
        }
        for (Map.Entry entry2 : map.entrySet()) {
            accumulate(String.valueOf(entry2.getKey()), entry2.getValue(), jsonConfig);
        }
    }

    public void clear() {
        this.properties.clear();
    }

    public int compareTo(Object obj) {
        JSONObject jSONObject;
        int size;
        int size2;
        if (obj == null || !(obj instanceof JSONObject) || (size = size()) < (size2 = jSONObject.size())) {
            return -1;
        }
        if (size > size2) {
            return 1;
        }
        return equals((jSONObject = (JSONObject) obj)) ? 0 : -1;
    }

    public boolean containsKey(Object obj) {
        return this.properties.containsKey(obj);
    }

    public boolean containsValue(Object obj) {
        return containsValue(obj, new JsonConfig());
    }

    public boolean containsValue(Object obj, JsonConfig jsonConfig) {
        try {
            return this.properties.containsValue(processValue(obj, jsonConfig));
        } catch (JSONException e) {
            return false;
        }
    }

    public JSONObject discard(String str) {
        verifyIsNull();
        this.properties.remove(str);
        return this;
    }

    public JSONObject element(String str, double d) {
        verifyIsNull();
        Double d2 = new Double(d);
        JSONUtils.testValidity(d2);
        return element(str, (Object) d2);
    }

    public JSONObject element(String str, int i) {
        verifyIsNull();
        return element(str, (Object) new Integer(i));
    }

    public JSONObject element(String str, long j) {
        verifyIsNull();
        return element(str, (Object) new Long(j));
    }

    public JSONObject element(String str, Object obj) {
        return element(str, obj, new JsonConfig());
    }

    public JSONObject element(String str, Object obj, JsonConfig jsonConfig) {
        verifyIsNull();
        if (str == null) {
            throw new JSONException("Null key.");
        }
        if (obj != null) {
            _setInternal(str, processValue(str, obj, jsonConfig), jsonConfig);
        } else {
            remove(str);
        }
        return this;
    }

    public JSONObject element(String str, Collection collection) {
        return element(str, collection, new JsonConfig());
    }

    public JSONObject element(String str, Collection collection, JsonConfig jsonConfig) {
        verifyIsNull();
        return collection instanceof JSONArray ? setInternal(str, collection, jsonConfig) : element(str, (Collection) JSONArray.fromObject(collection, jsonConfig));
    }

    public JSONObject element(String str, Map map) {
        return element(str, map, new JsonConfig());
    }

    public JSONObject element(String str, Map map, JsonConfig jsonConfig) {
        verifyIsNull();
        return map instanceof JSONObject ? setInternal(str, map, jsonConfig) : element(str, (Map) fromObject(map, jsonConfig), jsonConfig);
    }

    public JSONObject element(String str, boolean z) {
        verifyIsNull();
        return element(str, (Object) z ? Boolean.TRUE : Boolean.FALSE);
    }

    public JSONObject elementOpt(String str, Object obj) {
        return elementOpt(str, obj, new JsonConfig());
    }

    public JSONObject elementOpt(String str, Object obj, JsonConfig jsonConfig) {
        verifyIsNull();
        if (!(str == null || obj == null)) {
            element(str, obj, jsonConfig);
        }
        return this;
    }

    public Set entrySet() {
        return Collections.unmodifiableSet(this.properties.entrySet());
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof JSONObject)) {
            return false;
        }
        JSONObject jSONObject = (JSONObject) obj;
        if (isNullObject()) {
            return jSONObject.isNullObject();
        }
        if (jSONObject.isNullObject()) {
            return false;
        }
        if (jSONObject.size() != size()) {
            return false;
        }
        for (String str : this.properties.keySet()) {
            if (!jSONObject.properties.containsKey(str)) {
                return false;
            }
            Object obj2 = this.properties.get(str);
            Object obj3 = jSONObject.properties.get(str);
            if (JSONNull.getInstance().equals(obj2)) {
                if (!JSONNull.getInstance().equals(obj3)) {
                    return false;
                }
            } else if (JSONNull.getInstance().equals(obj3)) {
                return false;
            } else {
                if (!(obj2 instanceof String) || !(obj3 instanceof JSONFunction)) {
                    if (!(obj2 instanceof JSONFunction) || !(obj3 instanceof String)) {
                        if (!(obj2 instanceof JSONObject) || !(obj3 instanceof JSONObject)) {
                            if (!(obj2 instanceof JSONArray) || !(obj3 instanceof JSONArray)) {
                                if (!(obj2 instanceof JSONFunction) || !(obj3 instanceof JSONFunction)) {
                                    if (obj2 instanceof String) {
                                        if (!obj2.equals(String.valueOf(obj3))) {
                                            return false;
                                        }
                                    } else if (!(obj3 instanceof String)) {
                                        IdentityObjectMorpher morpherFor = JSONUtils.getMorpherRegistry().getMorpherFor(obj2.getClass());
                                        IdentityObjectMorpher morpherFor2 = JSONUtils.getMorpherRegistry().getMorpherFor(obj3.getClass());
                                        if (morpherFor == null || morpherFor == IdentityObjectMorpher.getInstance()) {
                                            if (morpherFor2 == null || morpherFor2 == IdentityObjectMorpher.getInstance()) {
                                                if (!obj2.equals(obj3)) {
                                                    return false;
                                                }
                                            } else if (!JSONUtils.getMorpherRegistry().morph(obj2.getClass(), obj2).equals(obj3)) {
                                                return false;
                                            }
                                        } else if (!obj2.equals(JSONUtils.getMorpherRegistry().morph(obj2.getClass(), obj3))) {
                                            return false;
                                        }
                                    } else if (!obj3.equals(String.valueOf(obj2))) {
                                        return false;
                                    }
                                } else if (!obj2.equals(obj3)) {
                                    return false;
                                }
                            } else if (!obj2.equals(obj3)) {
                                return false;
                            }
                        } else if (!obj2.equals(obj3)) {
                            return false;
                        }
                    } else if (!obj3.equals(String.valueOf(obj2))) {
                        return false;
                    }
                } else if (!obj2.equals(String.valueOf(obj3))) {
                    return false;
                }
            }
        }
        return true;
    }

    public Object get(Object obj) {
        if (obj instanceof String) {
            return get((String) obj);
        }
        return null;
    }

    public Object get(String str) {
        verifyIsNull();
        return this.properties.get(str);
    }

    public boolean getBoolean(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (obj != null) {
            if (obj.equals(Boolean.FALSE) || ((obj instanceof String) && ((String) obj).equalsIgnoreCase("false"))) {
                return false;
            }
            if (obj.equals(Boolean.TRUE) || ((obj instanceof String) && ((String) obj).equalsIgnoreCase("true"))) {
                return true;
            }
        }
        throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a Boolean.");
    }

    public double getDouble(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (obj != null) {
            try {
                return obj instanceof Number ? ((Number) obj).doubleValue() : Double.parseDouble((String) obj);
            } catch (Exception e) {
                throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a number.");
            }
        } else {
            throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a number.");
        }
    }

    public int getInt(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (obj != null) {
            return obj instanceof Number ? ((Number) obj).intValue() : (int) getDouble(str);
        }
        throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a number.");
    }

    public JSONArray getJSONArray(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (obj != null && (obj instanceof JSONArray)) {
            return (JSONArray) obj;
        }
        throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a JSONArray.");
    }

    public JSONObject getJSONObject(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (JSONNull.getInstance().equals(obj)) {
            return new JSONObject(true);
        }
        if (obj instanceof JSONObject) {
            return (JSONObject) obj;
        }
        throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a JSONObject.");
    }

    public long getLong(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (obj != null) {
            return obj instanceof Number ? ((Number) obj).longValue() : (long) getDouble(str);
        }
        throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] is not a number.");
    }

    public String getString(String str) {
        verifyIsNull();
        Object obj = get(str);
        if (obj != null) {
            return obj.toString();
        }
        throw new JSONException("JSONObject[" + JSONUtils.quote(str) + "] not found.");
    }

    public boolean has(String str) {
        verifyIsNull();
        return this.properties.containsKey(str);
    }

    public int hashCode() {
        int i = 19;
        if (isNullObject()) {
            return JSONNull.getInstance().hashCode() + 19;
        }
        Iterator it = this.properties.entrySet().iterator();
        while (true) {
            int i2 = i;
            if (!it.hasNext()) {
                return i2;
            }
            Map.Entry entry = (Map.Entry) it.next();
            Object key = entry.getKey();
            Object value = entry.getValue();
            i = JSONUtils.hashCode(value) + key.hashCode() + i2;
        }
    }

    public boolean isArray() {
        return false;
    }

    public boolean isEmpty() {
        verifyIsNull();
        return this.properties.isEmpty();
    }

    public boolean isNullObject() {
        return this.nullObject;
    }

    public Set keySet() {
        return Collections.unmodifiableSet(this.properties.keySet());
    }

    public Iterator keys() {
        verifyIsNull();
        return keySet().iterator();
    }

    public JSONArray names() {
        verifyIsNull();
        JSONArray jSONArray = new JSONArray();
        Iterator keys = keys();
        while (keys.hasNext()) {
            jSONArray.element(keys.next());
        }
        return jSONArray;
    }

    public JSONArray names(JsonConfig jsonConfig) {
        verifyIsNull();
        JSONArray jSONArray = new JSONArray();
        Iterator keys = keys();
        while (keys.hasNext()) {
            jSONArray.element(keys.next(), jsonConfig);
        }
        return jSONArray;
    }

    public Object opt(String str) {
        verifyIsNull();
        if (str == null) {
            return null;
        }
        return this.properties.get(str);
    }

    public boolean optBoolean(String str) {
        verifyIsNull();
        return optBoolean(str, false);
    }

    public boolean optBoolean(String str, boolean z) {
        verifyIsNull();
        try {
            return getBoolean(str);
        } catch (Exception e) {
            return z;
        }
    }

    public double optDouble(String str) {
        verifyIsNull();
        return optDouble(str, Double.NaN);
    }

    public double optDouble(String str, double d) {
        verifyIsNull();
        try {
            Object opt = opt(str);
            return opt instanceof Number ? ((Number) opt).doubleValue() : new Double((String) opt).doubleValue();
        } catch (Exception e) {
            return d;
        }
    }

    public int optInt(String str) {
        verifyIsNull();
        return optInt(str, 0);
    }

    public int optInt(String str, int i) {
        verifyIsNull();
        try {
            return getInt(str);
        } catch (Exception e) {
            return i;
        }
    }

    public JSONArray optJSONArray(String str) {
        verifyIsNull();
        Object opt = opt(str);
        if (opt instanceof JSONArray) {
            return (JSONArray) opt;
        }
        return null;
    }

    public JSONObject optJSONObject(String str) {
        verifyIsNull();
        Object opt = opt(str);
        if (opt instanceof JSONObject) {
            return (JSONObject) opt;
        }
        return null;
    }

    public long optLong(String str) {
        verifyIsNull();
        return optLong(str, 0);
    }

    public long optLong(String str, long j) {
        verifyIsNull();
        try {
            return getLong(str);
        } catch (Exception e) {
            return j;
        }
    }

    public String optString(String str) {
        verifyIsNull();
        return optString(str, "");
    }

    public String optString(String str, String str2) {
        verifyIsNull();
        Object opt = opt(str);
        return opt != null ? opt.toString() : str2;
    }

    public Object put(Object obj, Object obj2) {
        if (obj == null) {
            throw new IllegalArgumentException("key is null.");
        }
        Object obj3 = this.properties.get(obj);
        element(String.valueOf(obj), obj2);
        return obj3;
    }

    public void putAll(Map map) {
        putAll(map, new JsonConfig());
    }

    public void putAll(Map map, JsonConfig jsonConfig) {
        if (map instanceof JSONObject) {
            for (Map.Entry entry : map.entrySet()) {
                Object value = entry.getValue();
                this.properties.put((String) entry.getKey(), value);
            }
            return;
        }
        for (Map.Entry entry2 : map.entrySet()) {
            element(String.valueOf(entry2.getKey()), entry2.getValue(), jsonConfig);
        }
    }

    public Object remove(Object obj) {
        return this.properties.remove(obj);
    }

    public Object remove(String str) {
        verifyIsNull();
        return this.properties.remove(str);
    }

    public int size() {
        verifyIsNull();
        return this.properties.size();
    }

    public JSONArray toJSONArray(JSONArray jSONArray) {
        verifyIsNull();
        if (jSONArray == null || jSONArray.size() == 0) {
            return null;
        }
        JSONArray jSONArray2 = new JSONArray();
        for (int i = 0; i < jSONArray.size(); i++) {
            jSONArray2.element(opt(jSONArray.getString(i)));
        }
        return jSONArray2;
    }

    public String toString() {
        if (isNullObject()) {
            return JSONNull.getInstance().toString();
        }
        try {
            Iterator keys = keys();
            StringBuffer stringBuffer = new StringBuffer("{");
            while (keys.hasNext()) {
                if (stringBuffer.length() > 1) {
                    stringBuffer.append(',');
                }
                Object next = keys.next();
                stringBuffer.append(JSONUtils.quote(next.toString()));
                stringBuffer.append(':');
                stringBuffer.append(JSONUtils.valueToString(this.properties.get(next)));
            }
            stringBuffer.append(DefaultObjectDumpFormatter.TOKEN_INDENT_CLOSE);
            return stringBuffer.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public String toString(int i) {
        return isNullObject() ? JSONNull.getInstance().toString() : i == 0 ? toString() : toString(i, 0);
    }

    public String toString(int i, int i2) {
        if (isNullObject()) {
            return JSONNull.getInstance().toString();
        }
        int size = size();
        if (size == 0) {
            return "{}";
        }
        if (i == 0) {
            return toString();
        }
        Iterator keys = keys();
        StringBuffer stringBuffer = new StringBuffer("{");
        int i3 = i2 + i;
        if (size == 1) {
            Object next = keys.next();
            stringBuffer.append(JSONUtils.quote(next.toString()));
            stringBuffer.append(": ");
            stringBuffer.append(JSONUtils.valueToString(this.properties.get(next), i, i2));
        } else {
            while (keys.hasNext()) {
                Object next2 = keys.next();
                if (stringBuffer.length() > 1) {
                    stringBuffer.append(",\n");
                } else {
                    stringBuffer.append(10);
                }
                for (int i4 = 0; i4 < i3; i4++) {
                    stringBuffer.append(' ');
                }
                stringBuffer.append(JSONUtils.quote(next2.toString()));
                stringBuffer.append(": ");
                stringBuffer.append(JSONUtils.valueToString(this.properties.get(next2), i, i3));
            }
            if (stringBuffer.length() > 1) {
                stringBuffer.append(10);
                for (int i5 = 0; i5 < i2; i5++) {
                    stringBuffer.append(' ');
                }
            }
            for (int i6 = 0; i6 < i2; i6++) {
                stringBuffer.insert(0, ' ');
            }
        }
        stringBuffer.append(DefaultObjectDumpFormatter.TOKEN_INDENT_CLOSE);
        return stringBuffer.toString();
    }

    public Collection values() {
        return Collections.unmodifiableCollection(this.properties.values());
    }

    public Writer write(Writer writer) {
        try {
            if (isNullObject()) {
                writer.write(JSONNull.getInstance().toString());
            } else {
                boolean z = false;
                Iterator keys = keys();
                writer.write(123);
                while (keys.hasNext()) {
                    if (z) {
                        writer.write(44);
                    }
                    Object next = keys.next();
                    writer.write(JSONUtils.quote(next.toString()));
                    writer.write(58);
                    Object obj = this.properties.get(next);
                    if (obj instanceof JSONObject) {
                        ((JSONObject) obj).write(writer);
                    } else if (obj instanceof JSONArray) {
                        ((JSONArray) obj).write(writer);
                    } else {
                        writer.write(JSONUtils.valueToString(obj));
                    }
                    z = true;
                }
                writer.write(125);
            }
            return writer;
        } catch (IOException e) {
            throw new JSONException((Throwable) e);
        }
    }
}
