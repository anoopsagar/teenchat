package net.sf.json;

import java.io.IOException;
import java.io.Writer;

public final class JSONNull implements JSON {
    private static JSONNull instance = new JSONNull();

    private JSONNull() {
    }

    public static JSONNull getInstance() {
        return instance;
    }

    public boolean equals(Object obj) {
        return obj == null || obj == this || obj == instance || ((obj instanceof JSONObject) && ((JSONObject) obj).isNullObject());
    }

    public int hashCode() {
        return "null".hashCode() + 37;
    }

    public boolean isArray() {
        return false;
    }

    public boolean isEmpty() {
        throw new JSONException("Object is null");
    }

    public int size() {
        throw new JSONException("Object is null");
    }

    public String toString() {
        return "null";
    }

    public String toString(int i) {
        return toString();
    }

    public String toString(int i, int i2) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i3 = 0; i3 < i2; i3++) {
            stringBuffer.append(' ');
        }
        stringBuffer.append(toString());
        return stringBuffer.toString();
    }

    public Writer write(Writer writer) {
        try {
            writer.write(toString());
            return writer;
        } catch (IOException e) {
            throw new JSONException((Throwable) e);
        }
    }
}
