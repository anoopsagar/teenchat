package net.sf.json.processors;

import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.util.JSONUtils;

public class DefaultDefaultValueProcessor implements DefaultValueProcessor {
    public Object getDefaultValue(Class cls) {
        return JSONUtils.isArray(cls) ? new JSONArray() : JSONUtils.isNumber(cls) ? JSONUtils.isDouble(cls) ? new Double(0.0d) : new Integer(0) : JSONUtils.isBoolean(cls) ? Boolean.FALSE : JSONUtils.isString(cls) ? "" : JSONNull.getInstance();
    }
}
