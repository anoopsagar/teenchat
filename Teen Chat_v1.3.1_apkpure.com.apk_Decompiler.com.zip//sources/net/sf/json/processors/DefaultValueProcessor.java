package net.sf.json.processors;

public interface DefaultValueProcessor {
    Object getDefaultValue(Class cls);
}
