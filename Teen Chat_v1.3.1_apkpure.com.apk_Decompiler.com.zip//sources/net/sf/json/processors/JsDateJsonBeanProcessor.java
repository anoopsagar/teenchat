package net.sf.json.processors;

import java.sql.Date;
import java.util.Calendar;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

public class JsDateJsonBeanProcessor implements JsonBeanProcessor {
    public JSONObject processBean(Object obj, JsonConfig jsonConfig) {
        Object date = obj instanceof Date ? new java.util.Date(((Date) obj).getTime()) : obj;
        if (!(date instanceof java.util.Date)) {
            return new JSONObject(true);
        }
        Calendar instance = Calendar.getInstance();
        instance.setTime((java.util.Date) date);
        return new JSONObject().element("year", instance.get(1)).element("month", instance.get(2)).element("day", instance.get(5)).element("hours", instance.get(11)).element("minutes", instance.get(12)).element("seconds", instance.get(13)).element("milliseconds", instance.get(14));
    }
}
