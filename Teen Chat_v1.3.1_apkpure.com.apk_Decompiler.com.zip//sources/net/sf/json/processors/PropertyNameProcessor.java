package net.sf.json.processors;

public interface PropertyNameProcessor {
    String processPropertyName(Class cls, String str);
}
