package net.sf.json;

public interface JSONString {
    String toJSONString();
}
