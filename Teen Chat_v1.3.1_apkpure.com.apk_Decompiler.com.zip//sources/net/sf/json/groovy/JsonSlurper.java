package net.sf.json.groovy;

import groovy.lang.GroovyObjectSupport;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import net.sf.json.JSON;
import net.sf.json.JSONSerializer;
import net.sf.json.JsonConfig;
import org.apache.commons.io.IOUtils;

public class JsonSlurper extends GroovyObjectSupport {
    private JsonConfig jsonConfig;

    public JsonSlurper() {
        this(new JsonConfig());
    }

    public JsonSlurper(JsonConfig jsonConfig2) {
        this.jsonConfig = jsonConfig2 == null ? new JsonConfig() : jsonConfig2;
    }

    public JSON parse(File file) {
        return parse((Reader) new FileReader(file));
    }

    public JSON parse(InputStream inputStream) {
        return parse((Reader) new InputStreamReader(inputStream));
    }

    public JSON parse(Reader reader) {
        StringBuffer stringBuffer = new StringBuffer();
        BufferedReader bufferedReader = new BufferedReader(reader);
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                return parseText(stringBuffer.toString());
            }
            stringBuffer.append(readLine).append(IOUtils.LINE_SEPARATOR_UNIX);
        }
    }

    public JSON parse(String str) {
        return parse(new URL(str));
    }

    public JSON parse(URL url) {
        return parse(url.openConnection().getInputStream());
    }

    public JSON parseText(String str) {
        return JSONSerializer.toJSON((Object) str, this.jsonConfig);
    }
}
