package net.sf.json;

import com.smartfoxserver.v2.protocol.serialization.DefaultObjectDumpFormatter;
import java.io.Serializable;
import net.sf.json.util.JSONUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class JSONFunction implements Serializable {
    private static final String[] EMPTY_PARAM_ARRAY = new String[0];
    private String[] params;
    private String text;

    public JSONFunction(String str) {
        this((String[]) null, str);
    }

    public JSONFunction(String[] strArr, String str) {
        this.text = str != null ? str.trim() : "";
        if (strArr == null) {
            this.params = EMPTY_PARAM_ARRAY;
        } else if (strArr.length != 1 || !strArr[0].trim().equals("")) {
            this.params = new String[strArr.length];
            System.arraycopy(strArr, 0, this.params, 0, strArr.length);
            for (int i = 0; i < strArr.length; i++) {
                this.params[i] = this.params[i].trim();
            }
        } else {
            this.params = EMPTY_PARAM_ARRAY;
        }
    }

    public static JSONFunction parse(String str) {
        if (!JSONUtils.isFunction(str)) {
            throw new JSONException(new StringBuffer().append("String is not a function. ").append(str).toString());
        }
        String functionParams = JSONUtils.getFunctionParams(str);
        String functionBody = JSONUtils.getFunctionBody(str);
        String[] split = functionParams != null ? StringUtils.split(functionParams, ",") : null;
        if (functionBody == null) {
            functionBody = "";
        }
        return new JSONFunction(split, functionBody);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof String) {
            try {
                return equals(parse((String) obj));
            } catch (JSONException e) {
                return false;
            }
        } else if (!(obj instanceof JSONFunction)) {
            return false;
        } else {
            JSONFunction jSONFunction = (JSONFunction) obj;
            if (this.params.length != jSONFunction.params.length) {
                return false;
            }
            EqualsBuilder equalsBuilder = new EqualsBuilder();
            for (int i = 0; i < this.params.length; i++) {
                equalsBuilder.append((Object) this.params[i], (Object) jSONFunction.params[i]);
            }
            equalsBuilder.append((Object) this.text, (Object) jSONFunction.text);
            return equalsBuilder.isEquals();
        }
    }

    public String[] getParams() {
        return this.params;
    }

    public String getText() {
        return this.text;
    }

    public int hashCode() {
        HashCodeBuilder hashCodeBuilder = new HashCodeBuilder();
        for (String append : this.params) {
            hashCodeBuilder.append((Object) append);
        }
        hashCodeBuilder.append((Object) this.text);
        return hashCodeBuilder.toHashCode();
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer("function(");
        if (this.params.length > 0) {
            for (int i = 0; i < this.params.length - 1; i++) {
                stringBuffer.append(this.params[i]).append(',');
            }
            stringBuffer.append(this.params[this.params.length - 1]);
        }
        stringBuffer.append("){");
        if (this.text.length() > 0) {
            stringBuffer.append(' ').append(this.text).append(' ');
        }
        stringBuffer.append(DefaultObjectDumpFormatter.TOKEN_INDENT_CLOSE);
        return stringBuffer.toString();
    }
}
